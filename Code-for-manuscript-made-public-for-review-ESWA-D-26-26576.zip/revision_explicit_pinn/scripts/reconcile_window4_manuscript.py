from pathlib import Path
import re
import pandas as pd

PACKAGE = Path(__file__).resolve().parents[3]
TEX = PACKAGE / "01_手稿" / "Manuscript_restructured.tex"
CSV = PACKAGE / "04_图表与CSV结果" / "primary_window4_20260907" / "aggregated" / "primary_window4_metrics_mean_sd.csv"

OUTPUTS = ["P_c", "n", "W_e", "T_e", "G_NOx"]
MODELS = ["lstm", "tcn", "kan", "transformer", "tk_pinn"]
LABELS = {"lstm": "LSTM", "tcn": "TCN", "kan": "KAN", "transformer": "Transformer", "tk_pinn": "TK-PINN"}
UNITS = {"P_c": r"kg$\cdot$cm$^{-2}$", "n": "rpm", "W_e": "MW", "T_e": r"$^{\circ}$C", "G_NOx": r"mg$\cdot$Nm$^{-3}$"}


def fmt(value, scientific=False):
    if pd.isna(value):
        return "--"
    value = float(value)
    if scientific or abs(value) >= 1000 or (0 < abs(value) < 0.01):
        return f"{value:.3e}"
    return f"{value:.3f}"


def make_table(df, condition, caption, label):
    frame = df[df["condition"] == condition].set_index(["output", "model"])
    lines = [
        r"\begin{table*}[pos=!htbp]", r"\centering", r"\scriptsize",
        rf"\caption{{{caption}}}", rf"\label{{{label}}}",
        r"\resizebox{\textwidth}{!}{%", r"\begin{tabular}{llccccc}",
        r"\toprule",
        "Output (unit) & Method & MSE & RMSE & MAE & $\mathrm{MAPE}_{active}$ (\%) & $F_s$ (\%) \\\\",
        r"\midrule",
    ]
    for oi, output in enumerate(OUTPUTS):
        for mi, model in enumerate(MODELS):
            row = frame.loc[(output, model)]
            output_label = f"${output}$ ({UNITS[output]})" if mi == 0 else ""
            vals = [
                rf"${fmt(row.MSE_mean, True)}\pm{fmt(row.MSE_sd, True)}$",
                rf"${fmt(row.RMSE_mean)}\pm{fmt(row.RMSE_sd)}$",
                rf"${fmt(row.MAE_mean)}\pm{fmt(row.MAE_sd)}$",
                rf"${fmt(row.MAPE_mean)}\pm{fmt(row.MAPE_sd)}$",
                rf"${fmt(row.Fs_mean)}\pm{fmt(row.Fs_sd)}$",
            ]
            lines.append(f"{output_label} & {LABELS[model]} & {' & '.join(vals)} " + r"\\")
        if oi < len(OUTPUTS) - 1:
            lines.append(r"\midrule")
    lines.extend([r"\bottomrule", r"\end{tabular}}", r"\end{table*}", ""])
    return "\n".join(lines)


def replace_labeled_table(text, label, replacement):
    label_token = rf"\\label\{{{re.escape(label)}\}}"
    match = re.search(label_token, text)
    if not match:
        raise RuntimeError(f"missing {label}")
    start = text.rfind(r"\begin{table*}", 0, match.start())
    end_marker = r"\end{table*}"
    end = text.find(end_marker, match.end())
    if start < 0 or end < 0:
        raise RuntimeError(f"invalid table bounds for {label}")
    end += len(end_marker)
    return text[:start] + replacement.rstrip() + text[end:]


def main():
    df = pd.read_csv(CSV)
    text = TEX.read_text(encoding="utf-8")
    for condition, caption, label in [
        ("startup", r"Startup one-step metrics by output and model, mean $\pm$ sample SD over five independent runs.", "tab:startup_metrics"),
        ("load_change", r"Load-change one-step metrics by output and model, mean $\pm$ sample SD over five independent runs.", "tab:load_metrics"),
        ("shutdown", r"Shutdown one-step metrics by output and model, mean $\pm$ sample SD over five independent runs.", "tab:shutdown_metrics"),
    ]:
        text = replace_labeled_table(text, label, make_table(df, condition, caption, label))
    text = text.replace("$S_l=8$", "$S_l=4$").replace("eight-row boundary", "four-row boundary")
    text = text.replace("for $S_l=8$", "for $S_l=4$").replace("eight-step input", "four-step input")
    text = text.replace("eight-row", "four-row")
    text = text.replace("common window length $S_l=8$ is then fixed", "validation-selected window length $S_l=4$ is then fixed")
    text = text.replace("the marker denotes the adopted $S_l=8$", "the markers denote the validation-selected $S_l=4$ for all five models")
    text = text.replace("Preliminary validation sensitivity", "Validation-only sensitivity")
    TEX.write_text(text, encoding="utf-8")
    print("reconciled primary tables and window references")


if __name__ == "__main__":
    main()
