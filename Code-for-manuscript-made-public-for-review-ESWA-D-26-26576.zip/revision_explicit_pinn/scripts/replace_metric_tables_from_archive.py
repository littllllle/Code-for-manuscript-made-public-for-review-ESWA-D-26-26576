"""Replace manuscript Tables 3--5 from the audited five-instance CSV."""
from pathlib import Path
import re
import pandas as pd

HERE = Path(__file__).resolve()
# scripts -> revision_explicit_pinn -> 03_代码 -> 最终版手稿0907
PACKAGE = HERE.parents[3]
TEX = PACKAGE / "01_手稿" / "Manuscript_restructured.tex"
CSV = PACKAGE / "04_图表与CSV结果" / "final_simulation_20260831" / "05_five_seed_statistics_20260902" / "tables" / "one_step_mean_std.csv"
OUTPUTS = (("P_c", r"$P_c$ (kg$\cdot$cm$^{-2}$)"), ("n", r"$n$ (rpm)"), ("W_e", r"$W_e$ (MW)"), ("T_e", r"$T_e$ ($^{\circ}$C)"), ("G_NOx", r"$G_{NOx}$ (mg$\cdot$Nm$^{-3}$)"))
MODELS = (("lstm", "LSTM"), ("tcn", "TCN"), ("kan", "KAN"), ("transformer", "Transformer"), ("pinn", "TK-PINN"))

def number(mean, sd, sci=False):
    return f"${mean:.3e}\\pm{sd:.3e}$" if sci else f"${mean:.3f}\\pm{sd:.3f}$"

def block(condition, caption, label, data):
    out = [r"\begin{table*}[pos=!htbp]", r"\centering", r"\scriptsize", f"\\caption{{{caption}}}", f"\\label{{{label}}}", r"\resizebox{\textwidth}{!}{%", r"\begin{tabular}{llccccc}", r"\toprule", r"Output (unit) & Method & MSE & RMSE & MAE & $\mathrm{MAPE}_{active}$ (\%) & $F_s$ (\%) \\", r"\midrule"]
    for oi, (output, display) in enumerate(OUTPUTS):
        part = data[(data.condition == condition) & (data.output == output)]
        if len(part) != 5: raise RuntimeError(f"bad row count for {condition}/{output}")
        for mi, (model, model_label) in enumerate(MODELS):
            row = part[part.model == model].iloc[0]
            prefix = display if mi == 0 else ""
            vals = [number(row.MSE_mean, row.MSE_std, True), number(row.RMSE_mean, row.RMSE_std), number(row.MAE_mean, row.MAE_std), number(row.MAPE_percent_mean, row.MAPE_percent_std), number(row.fit_score_percent_mean, row.fit_score_percent_std)]
            out.append(prefix + " & " + model_label + " & " + " & ".join(vals) + " " + r"\\")
        if oi < len(OUTPUTS) - 1: out.append(r"\midrule")
    out += [r"\bottomrule", r"\end{tabular}}", r"\end{table*}"]
    return "\n".join(out)

def main():
    data = pd.read_csv(CSV)
    text = TEX.read_text(encoding="utf-8")
    specs = (("startup", r"Startup one-step metrics by output and model, mean $\pm$ sample SD over five independent runs.", "tab:startup_metrics"), ("load_change", r"Load-change one-step metrics by output and model, mean $\pm$ sample SD over five independent runs.", "tab:load_metrics"), ("shutdown", r"Shutdown one-step metrics by output and model, mean $\pm$ sample SD over five independent runs.", "tab:shutdown_metrics"))
    for condition, caption, label in specs:
        # Restrict the match to the nearest table environment containing the label.
        label_pos = text.find(f"\\label{{{label}}}")
        if label_pos < 0:
            raise RuntimeError(f"could not find {label}")
        begin_pos = text.rfind("\\begin{table*}", 0, label_pos)
        end_pos = text.find("\\end{table*}", label_pos)
        if begin_pos < 0 or end_pos < 0:
            raise RuntimeError(f"malformed table environment for {label}")
        end_pos += len("\\end{table*}")
        replacement = block(condition, caption, label, data)
        text = text[:begin_pos] + replacement + text[end_pos:]
    TEX.write_text(text, encoding="utf-8")
    print("replaced Tables 3--5 from audited one_step_mean_std.csv")

if __name__ == "__main__": main()
