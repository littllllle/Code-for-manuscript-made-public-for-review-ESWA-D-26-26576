"""Explicit PG9351FA combustor mass/pressure and energy/temperature equations."""

from dataclasses import dataclass

import torch


@dataclass(frozen=True)
class CombustorParameters:
    gas_constant: float
    effective_volume: float
    specific_heat: float
    lower_heating_value: float
    combustion_efficiency: float = 0.99
    energy_coefficient: float = 1.0

    def validate(self):
        positive = {
            "gas_constant": self.gas_constant,
            "effective_volume": self.effective_volume,
            "specific_heat": self.specific_heat,
            "lower_heating_value": self.lower_heating_value,
            "combustion_efficiency": self.combustion_efficiency,
            "energy_coefficient": self.energy_coefficient,
        }
        for name, value in positive.items():
            if value <= 0:
                raise ValueError("{} must be positive".format(name))
        if self.combustion_efficiency > 1.0:
            raise ValueError("combustion_efficiency cannot exceed one")


def combustor_rhs(state, flows, enthalpies, parameters):
    """Evaluate manuscript Eqs. (2) and (3) in one differentiable graph.

    state[..., 0:2] = [P_b, T_b]
    flows[..., 0:3] = [G_ain, G_f, G_gout]
    enthalpies[..., 0:3] = [h_ain, h_fin, h_gout]
    """
    parameters.validate()
    if state.shape[-1] != 2 or flows.shape[-1] != 3 or enthalpies.shape[-1] != 3:
        raise ValueError("Expected state[...,2], flows[...,3], enthalpies[...,3]")

    pressure, temperature = state.unbind(dim=-1)
    air_in, fuel, gas_out = flows.unbind(dim=-1)
    h_air, h_fuel, h_out = enthalpies.unbind(dim=-1)
    if torch.any(pressure <= 0) or torch.any(temperature <= 0):
        raise ValueError("Combustor pressure and temperature must be positive")

    rg = parameters.gas_constant
    volume = parameters.effective_volume
    cp = parameters.specific_heat
    heating = parameters.lower_heating_value
    eta = parameters.combustion_efficiency
    k = parameters.energy_coefficient

    mass_imbalance = air_in + fuel - gas_out
    common = rg * temperature / (pressure * cp * volume)
    d_temperature = common * (
        k * fuel * (h_fuel + heating * eta)
        + k * (air_in * h_air - gas_out * h_out)
        - h_out * mass_imbalance
    )
    d_pressure = rg * temperature * mass_imbalance / volume + pressure * d_temperature / temperature
    return torch.stack([d_pressure, d_temperature], dim=-1)


def trapezoidal_residual(state_now, state_next, rhs_now, rhs_next, dt):
    """Dimensionful trapezoidal residual; scale it before forming a loss."""
    if dt <= 0:
        raise ValueError("dt must be positive")
    if not (state_now.shape == state_next.shape == rhs_now.shape == rhs_next.shape):
        raise ValueError("All state and RHS tensors must have the same shape")
    return (state_next - state_now) / dt - 0.5 * (rhs_now + rhs_next)

