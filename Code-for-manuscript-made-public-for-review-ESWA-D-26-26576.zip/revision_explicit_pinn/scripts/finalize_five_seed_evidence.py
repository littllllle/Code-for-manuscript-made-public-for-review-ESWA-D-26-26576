"""Build auditable five-seed tables, tests, and manuscript figures.

The script never edits source run directories. One-step statistics are rebuilt
from complete-test prediction CSVs. Recursive statistics are computed from the
per-lead metrics emitted by the finite-horizon evaluator.
"""
from __future__ import annotations

import argparse
import json
import math
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.stats import wilcoxon


def active_mape(truth, estimate, reference_max=None, relative_threshold=0.01):
    """Same active-MAPE definition as evaluation/mape.py (no torch import)."""
    truth = np.asarray(truth, dtype=np.float64)
    estimate = np.asarray(estimate, dtype=np.float64)
    scale = float(np.max(np.abs(truth)) if reference_max is None else reference_max)
    threshold = relative_threshold * max(scale, np.finfo(np.float64).eps)
    valid = np.abs(truth) >= threshold
    if not np.any(valid):
        return np.nan, 0.0, threshold
    return float(np.mean(np.abs(estimate[valid] - truth[valid]) / np.abs(truth[valid])) * 100.0), float(np.mean(valid)), threshold


SEEDS = (2026, 2027, 2028, 2029, 2030)
MODELS = ("lstm", "tcn", "kan", "transformer", "pinn")
MODEL_LABELS = {
    "lstm": "LSTM",
    "tcn": "TCN",
    "kan": "KAN",
    "transformer": "Transformer",
    "pinn": "TK-PINN",
}
COLORS = {
    "lstm": "#3F8F72",
    "tcn": "#6F4AA8",
    "kan": "#D18F3B",
    "transformer": "#1F5A7A",
    "pinn": "#C1121F",
}
CONDITIONS = ("startup", "load_change", "shutdown")
CONDITION_LABELS = {
    "startup": "Startup",
    "load_change": "Load change",
    "shutdown": "Shutdown",
}
OUTPUTS = ("P_c", "n", "W_e", "T_e", "G_NOx")
OUTPUT_LABELS = {
    "P_c": r"$P_c$",
    "n": r"$n$",
    "W_e": r"$W_e$",
    "T_e": r"$T_e$",
    "G_NOx": r"$G_{NOx}$",
}
HORIZONS = (10, 20, 40, 80)


def training_output_max(package: Path) -> dict[str, float]:
    """Return max absolute output values from the five training CSVs only."""
    data_dir = package / "03_代码" / "data" / "999"
    arrays = [np.loadtxt(path, delimiter=",", encoding="utf-8-sig")
              for path in sorted(data_dir.glob("data_train*.csv"))]
    if not arrays:
        raise FileNotFoundError(f"No training CSVs found under {data_dir}")
    values = np.vstack(arrays)[:, 2:]
    return {name: float(np.max(np.abs(values[:, index]))) for index, name in enumerate(OUTPUTS)}


def apply_style():
    plt.rcParams.update(
        {
            "font.family": "serif",
            "font.serif": ["Times New Roman", "Times", "Nimbus Roman", "DejaVu Serif"],
            "font.size": 11.0,
            "mathtext.fontset": "stix",
            "mathtext.default": "regular",
            "axes.labelsize": 11.0,
            "axes.titlesize": 11.5,
            "legend.fontsize": 9.5,
            "xtick.labelsize": 10.0,
            "ytick.labelsize": 10.0,
            "axes.linewidth": 1.0,
            "axes.grid": False,
            "xtick.direction": "in",
            "ytick.direction": "in",
            "xtick.major.width": 0.85,
            "ytick.major.width": 0.85,
            "legend.frameon": True,
            "legend.framealpha": 1.0,
            "legend.edgecolor": "#444444",
            "legend.fancybox": False,
            "lines.linewidth": 1.3,
            "savefig.dpi": 600,
            "figure.dpi": 150,
        }
    )


def save_figure(fig, path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path, dpi=600, bbox_inches="tight", facecolor="white")
    fig.savefig(path.with_suffix(".pdf"), bbox_inches="tight", facecolor="white")
    plt.close(fig)


def locate_one_step(root: Path, model: str, seed: int) -> Path:
    final = root / "final_simulation_20260831"
    if model in ("pinn", "transformer"):
        return final / "03_one_step_encoder_decoder" / f"{model}_seed{seed}" / "test_predictions.csv"
    baseline = root / "complete_code_tests_20260830" / "phase10_baselines"
    if model == "tcn" and seed == 2026:
        retry = baseline / "tcn_seed2026_cpu_retry" / "test_predictions.csv"
        if retry.exists():
            return retry
    return baseline / f"{model}_seed{seed}" / "test_predictions.csv"


def metrics_from_predictions(frame: pd.DataFrame, mape_reference_max: float) -> dict:
    target = frame["target"].to_numpy(dtype=float)
    prediction = frame["prediction"].to_numpy(dtype=float)
    error = prediction - target
    mse = float(np.mean(error**2))
    rmse = float(math.sqrt(mse))
    mae = float(np.mean(np.abs(error)))
    mape, mape_coverage, mape_threshold = active_mape(
        target, prediction, reference_max=mape_reference_max, relative_threshold=0.01
    )
    target_energy = float(np.sum(target**2))
    fit_score = (
        float(100.0 * (1.0 - math.sqrt(float(np.sum(error**2))) / math.sqrt(target_energy)))
        if target_energy > 0
        else float("nan")
    )
    centered = target - np.mean(target)
    denominator = float(np.sum(centered**2))
    r2 = 1.0 - float(np.sum(error**2)) / denominator if denominator > 1e-12 else float("nan")
    return {
        "MSE": mse,
        "RMSE": rmse,
        "MAE": mae,
        "MAPE_percent": mape,
        "MAPE_active_coverage": mape_coverage,
        "MAPE_active_threshold": mape_threshold,
        "fit_score_percent": fit_score,
        "R2": r2,
        "samples": int(len(frame)),
    }


def collect_one_step(results_root: Path, audit: list[dict], mape_reference_max: dict[str, float]) -> pd.DataFrame:
    rows = []
    for model in MODELS:
        for seed in SEEDS:
            path = locate_one_step(results_root, model, seed)
            if not path.exists():
                audit.append({"protocol": "one_step", "model": model, "seed": seed, "status": "missing", "path": str(path)})
                continue
            frame = pd.read_csv(path)
            required = {"condition", "output_index", "target", "prediction"}
            if not required.issubset(frame.columns):
                raise ValueError(f"Missing columns in {path}: {sorted(required - set(frame.columns))}")
            for condition in CONDITIONS:
                for index, output in enumerate(OUTPUTS):
                    subset = frame[(frame["condition"] == condition) & (frame["output_index"] == index)]
                    if subset.empty:
                        raise ValueError(f"No rows for {model}, seed={seed}, {condition}, {output}")
                    rows.append({"model": model, "model_label": MODEL_LABELS[model], "seed": seed,
                                 "condition": condition, "output": output,
                                 **metrics_from_predictions(subset, mape_reference_max[output])})
            audit.append({"protocol": "one_step", "model": model, "seed": seed, "status": "included",
                          "path": str(path), "prediction_rows": int(len(frame))})
    result = pd.DataFrame(rows)
    expected = len(MODELS) * len(SEEDS) * len(CONDITIONS) * len(OUTPUTS)
    if len(result) != expected:
        raise RuntimeError(f"One-step table has {len(result)} rows; expected {expected}")
    return result


def recursive_run_dir(recursive_root: Path, model: str, seed: int, recovery: Path | None) -> Path:
    if model == "pinn" and seed == 2026 and recovery is not None and recovery.exists():
        return recovery
    return recursive_root / f"{model}_seed{seed}"


def collect_recursive(recursive_root: Path, recovery: Path | None, audit: list[dict]) -> pd.DataFrame:
    frames = []
    for model in MODELS:
        for seed in SEEDS:
            directory = recursive_run_dir(recursive_root, model, seed, recovery)
            metrics_path = directory / "fixed_horizon_metrics.csv"
            history_path = directory / "history.json"
            config_path = directory / "run_config.json"
            artifacts = {
                "best_checkpoint": (directory / "best.pt").exists(),
                "metrics": metrics_path.exists(),
                "one_step_metrics": (directory / "test_metrics.csv").exists(),
                "recursive_predictions_h80": (directory / "recursive_predictions_h80.npz").exists(),
                "history": history_path.exists(),
                "run_config": config_path.exists(),
            }
            history_records = 0
            if history_path.exists():
                history_records = len(json.loads(history_path.read_text(encoding="utf-8")))
            status = "included" if all(artifacts.values()) and history_records == 20 else "incomplete_provenance"
            audit.append({"protocol": "recursive", "model": model, "seed": seed, "status": status,
                          "directory": str(directory), "history_records": history_records, **artifacts})
            if not metrics_path.exists():
                continue
            frame = pd.read_csv(metrics_path)
            frame = frame[
                frame["condition"].isin(CONDITIONS)
                & frame["horizon"].isin(HORIZONS)
                & frame["output"].isin(OUTPUTS)
            ].copy()
            frame["model"] = model
            frame["model_label"] = MODEL_LABELS[model]
            frame["seed"] = seed
            frame["run_directory"] = directory.name
            frames.append(frame)
    result = pd.concat(frames, ignore_index=True)
    expected = len(MODELS) * len(SEEDS) * len(CONDITIONS) * sum(HORIZONS) * len(OUTPUTS)
    if len(result) != expected:
        raise RuntimeError(f"Recursive table has {len(result)} rows; expected {expected}")
    return result


def compare_seed2026_runs(recursive_root: Path, recovery: Path | None) -> dict | None:
    if recovery is None or not (recovery / "fixed_horizon_metrics.csv").exists():
        return None
    original_path = recursive_root / "pinn_seed2026" / "fixed_horizon_metrics.csv"
    if not original_path.exists():
        return {"status": "original_metrics_missing"}
    keys = ["condition", "horizon", "lead", "output"]
    metrics = ["MSE", "RMSE", "MAE", "R2"]
    original = pd.read_csv(original_path).sort_values(keys).reset_index(drop=True)
    repeated = pd.read_csv(recovery / "fixed_horizon_metrics.csv").sort_values(keys).reset_index(drop=True)
    if len(original) != len(repeated) or not original[keys].equals(repeated[keys]):
        return {"status": "row_keys_differ", "original_rows": len(original), "recovery_rows": len(repeated)}
    differences = (original[metrics] - repeated[metrics]).abs()
    original_checkpoint = recursive_root / "pinn_seed2026" / "best.pt"
    recovery_config = json.loads((recovery / "run_config.json").read_text(encoding="utf-8"))
    return {
        "status": "compared",
        "original_directory": str(original_path.parent),
        "recovery_directory": str(recovery),
        "original_checkpoint_exists": original_checkpoint.exists(),
        "recovery_best_epoch": recovery_config.get("best_epoch"),
        "max_absolute_difference": {metric: float(differences[metric].max()) for metric in metrics},
        "mean_absolute_difference": {metric: float(differences[metric].mean()) for metric in metrics},
        "exact_metric_match": bool(np.allclose(original[metrics], repeated[metrics], rtol=0.0, atol=0.0, equal_nan=True)),
        "decision": "The complete recovery run is the formal seed-2026 source used in final statistics.",
    }


def mean_std(frame: pd.DataFrame, groups: list[str], metrics: tuple[str, ...]) -> pd.DataFrame:
    named = {}
    for metric in metrics:
        named[f"{metric}_mean"] = (metric, "mean")
        named[f"{metric}_std"] = (metric, "std")
    named["n_seeds"] = ("seed", "nunique")
    return frame.groupby(groups, as_index=False).agg(**named)


def pool_recursive_leads(recursive: pd.DataFrame) -> pd.DataFrame:
    rows = []
    groups = ["model", "model_label", "seed", "condition", "horizon", "output"]
    for keys, group in recursive.groupby(groups, sort=False):
        mse = float(group["MSE"].mean())
        rows.append(dict(zip(groups, keys), MSE=mse, RMSE=math.sqrt(mse),
                         MAE=float(group["MAE"].mean()), mean_lead_R2=float(group["R2"].mean()),
                         leads=int(group["lead"].nunique()), samples_per_lead=int(group["samples"].iloc[0])))
    return pd.DataFrame(rows)


def holm_adjust(p_values: np.ndarray) -> np.ndarray:
    order = np.argsort(p_values)
    adjusted = np.empty(len(p_values), dtype=float)
    running = 0.0
    total = len(p_values)
    for rank, index in enumerate(order):
        candidate = min(1.0, (total - rank) * float(p_values[index]))
        running = max(running, candidate)
        adjusted[index] = running
    return adjusted


def paired_tests(frame: pd.DataFrame, protocol: str, metrics: tuple[str, ...], group_fields: list[str]) -> pd.DataFrame:
    rows = []
    for keys, group in frame.groupby(group_fields, sort=False):
        key_values = dict(zip(group_fields, keys if isinstance(keys, tuple) else (keys,)))
        pivot = group.pivot(index="seed", columns="model", values=list(metrics))
        for metric in metrics:
            proposed = pivot[metric]["pinn"]
            for baseline in MODELS[:-1]:
                comparison = pd.concat([proposed, pivot[metric][baseline]], axis=1, keys=["pinn", "baseline"]).dropna()
                delta = comparison["pinn"].to_numpy() - comparison["baseline"].to_numpy()
                if len(delta) != len(SEEDS):
                    raise RuntimeError(f"Unpaired seeds for {protocol}, {key_values}, {metric}, {baseline}")
                if np.allclose(delta, 0.0):
                    statistic, p_value = 0.0, 1.0
                else:
                    test = wilcoxon(comparison["pinn"], comparison["baseline"], alternative="two-sided", mode="auto")
                    statistic, p_value = float(test.statistic), float(test.pvalue)
                rows.append({"protocol": protocol, **key_values, "metric": metric,
                             "comparison": f"TK-PINN vs {MODEL_LABELS[baseline]}", "baseline": baseline,
                             "n_pairs": len(delta), "wilcoxon_statistic": statistic, "p_raw": p_value,
                             "median_pinn_minus_baseline": float(np.median(delta)),
                             "tk_pinn_wins": int(np.sum(delta < 0)), "ties": int(np.sum(delta == 0)),
                             "lower_is_better": True})
    result = pd.DataFrame(rows)
    family = [*group_fields, "metric"]
    result["p_holm"] = np.nan
    for _, indices in result.groupby(family).groups.items():
        idx = list(indices)
        result.loc[idx, "p_holm"] = holm_adjust(result.loc[idx, "p_raw"].to_numpy())
    result["significant_0_05"] = result["p_holm"] < 0.05
    return result


def style_axis(ax):
    ax.grid(False)
    ax.tick_params(top=True, right=True, direction="in", width=0.85, length=3.0, pad=2.0)
    for spine in ax.spines.values():
        spine.set_color("#222222")
        spine.set_linewidth(0.75)


def plot_one_step(summary: pd.DataFrame, output_dir: Path):
    for condition in CONDITIONS:
        fig, axes = plt.subplots(1, 5, figsize=(11.5, 3.0), constrained_layout=True)
        for ax, output in zip(axes, OUTPUTS):
            subset = summary[(summary["condition"] == condition) & (summary["output"] == output)].set_index("model")
            x = np.arange(len(MODELS))
            means = np.asarray([subset.loc[m, "MSE_mean"] for m in MODELS])
            stds = np.asarray([subset.loc[m, "MSE_std"] for m in MODELS])
            ax.bar(x, means, yerr=stds, capsize=2.2, width=0.72,
                   color=[COLORS[m] for m in MODELS], edgecolor="black", linewidth=0.35)
            ax.set_yscale("log")
            ax.set_xticks(x, [MODEL_LABELS[m] for m in MODELS], rotation=38, ha="right")
            ax.set_title(OUTPUT_LABELS[output])
            style_axis(ax)
        axes[0].set_ylabel(r"MSE, mean $\pm$ std")
        fig.suptitle(f"Five-seed one-step prediction: {CONDITION_LABELS[condition]}", fontsize=10)
        save_figure(fig, output_dir / f"one_step_mse_mean_std_{condition}.png")


def plot_recursive(summary: pd.DataFrame, output_dir: Path):
    for condition in CONDITIONS:
        fig, axes = plt.subplots(1, 5, figsize=(11.5, 3.0), constrained_layout=True)
        for ax, output in zip(axes, OUTPUTS):
            panel = summary[(summary["condition"] == condition) & (summary["output"] == output)]
            positive_floor = float(panel.loc[panel["MSE_mean"] > 0, "MSE_mean"].min()) * 0.25
            for model in MODELS:
                subset = panel[panel["model"] == model].sort_values("horizon")
                x = subset["horizon"].to_numpy(dtype=float)
                mean = subset["MSE_mean"].to_numpy(dtype=float)
                std = subset["MSE_std"].to_numpy(dtype=float)
                # A symmetric mean +/- std interval can cross zero. Zero is
                # undefined on a log axis, so only the displayed lower band is
                # clipped to a panel-relative positive floor; source values and
                # tables remain unchanged.
                lower = np.maximum(mean - std, positive_floor)
                upper = mean + std
                ax.plot(x, mean, "-o", color=COLORS[model], markersize=2.8, label=MODEL_LABELS[model])
                ax.fill_between(x, lower, upper, color=COLORS[model], alpha=0.10, linewidth=0)
            ax.set_yscale("log")
            ax.set_xticks(HORIZONS)
            ax.set_title(OUTPUT_LABELS[output])
            ax.set_xlabel("Horizon (steps)")
            style_axis(ax)
        axes[0].set_ylabel(r"Pooled-horizon MSE, mean $\pm$ std")
        axes[-1].legend(fontsize=8, loc="best")
        fig.suptitle(f"Five-seed finite-horizon recursion: {CONDITION_LABELS[condition]}", fontsize=10)
        save_figure(fig, output_dir / f"recursive_mse_mean_std_{condition}.png")


def plot_representative_one_step(results_root: Path, output_dir: Path, seed: int = 2027):
    predictions = {model: pd.read_csv(locate_one_step(results_root, model, seed)) for model in MODELS}
    for condition in CONDITIONS:
        fig, axes = plt.subplots(5, 1, figsize=(11.5, 8.6), sharex=True, constrained_layout=True)
        for index, (ax, output) in enumerate(zip(axes, OUTPUTS)):
            reference = predictions["pinn"]
            reference = reference[(reference["condition"] == condition) & (reference["output_index"] == index)]
            x = np.arange(len(reference))
            ax.plot(x, reference["target"].to_numpy(), color="#111111", linewidth=1.15,
                    label="Measured" if index == 0 else None, zorder=5)
            for model in MODELS:
                subset = predictions[model]
                subset = subset[(subset["condition"] == condition) & (subset["output_index"] == index)]
                if len(subset) != len(reference):
                    raise RuntimeError(f"One-step curve length mismatch: {model}, {condition}, {output}")
                ax.plot(x, subset["prediction"].to_numpy(), color=COLORS[model], linewidth=0.75,
                        alpha=0.88, label=MODEL_LABELS[model] if index == 0 else None)
            ax.set_ylabel(OUTPUT_LABELS[output])
            style_axis(ax)
        axes[0].legend(ncol=3, loc="best", fontsize=8)
        axes[0].set_title(f"One-step prediction on the complete {CONDITION_LABELS[condition].lower()} test segment (seed={seed})")
        axes[-1].set_xlabel("Test sample index")
        save_figure(fig, output_dir / f"one_step_complete_fit_seed{seed}_{condition}.png")


def load_recursive_prediction(directory: Path):
    archive = np.load(directory / "recursive_predictions_h80.npz", allow_pickle=False)
    return {name: archive[name] for name in archive.files}


def plot_representative_recursive(recursive_root: Path, output_dir: Path, seed: int = 2027, lead: int = 10):
    archives = {
        model: load_recursive_prediction(recursive_root / f"{model}_seed{seed}") for model in MODELS
    }
    lead_index = lead - 1
    for condition in CONDITIONS:
        fig, axes = plt.subplots(5, 1, figsize=(11.5, 8.6), sharex=True, constrained_layout=True)
        reference = archives["pinn"]
        reference_mask = reference["condition"].astype(str) == condition
        reference_origins = reference["origin"][reference_mask]
        for output_index, (ax, output) in enumerate(zip(axes, OUTPUTS)):
            target = reference["target"][reference_mask, lead_index, output_index]
            x = np.arange(len(target))
            ax.plot(x, target, color="#111111", linewidth=1.15,
                    label="Measured" if output_index == 0 else None, zorder=5)
            for model in MODELS:
                archive = archives[model]
                mask = archive["condition"].astype(str) == condition
                if not np.array_equal(archive["origin"][mask], reference_origins):
                    raise RuntimeError(f"Recursive origin mismatch: {model}, {condition}")
                prediction = archive["prediction"][mask, lead_index, output_index]
                ax.plot(x, prediction, color=COLORS[model], linewidth=0.75, alpha=0.88,
                        label=MODEL_LABELS[model] if output_index == 0 else None)
            ax.set_ylabel(OUTPUT_LABELS[output])
            style_axis(ax)
        axes[0].legend(ncol=3, loc="best", fontsize=8)
        axes[0].set_title(
            f"{lead}-step recursive prediction on the complete {CONDITION_LABELS[condition].lower()} test segment (seed={seed})"
        )
        axes[-1].set_xlabel("Valid forecast-origin index")
        save_figure(fig, output_dir / f"recursive_h{lead}_complete_fit_seed{seed}_{condition}.png")


def plot_one_step_error_boxplots(results_root: Path, output_dir: Path):
    config_path = results_root / "final_simulation_20260831" / "03_one_step_encoder_decoder" / "pinn_seed2027" / "run_config.json"
    config = json.loads(config_path.read_text(encoding="utf-8"))
    ranges = np.asarray(config["scaler"]["maximum"], dtype=float)[2:] - np.asarray(
        config["scaler"]["minimum"], dtype=float
    )[2:]
    values = {(condition, model): [] for condition in CONDITIONS for model in MODELS}
    for model in MODELS:
        for seed in SEEDS:
            frame = pd.read_csv(locate_one_step(results_root, model, seed))
            for condition in CONDITIONS:
                subset = frame[frame["condition"] == condition]
                output_indices = subset["output_index"].to_numpy(dtype=int)
                normalized = np.abs(subset["prediction"].to_numpy() - subset["target"].to_numpy()) / ranges[output_indices]
                values[(condition, model)].append(normalized)
    fig, axes = plt.subplots(1, 3, figsize=(11.5, 3.25), constrained_layout=True)
    for ax, condition in zip(axes, CONDITIONS):
        data = [np.concatenate(values[(condition, model)]) for model in MODELS]
        box = ax.boxplot(data, labels=[MODEL_LABELS[m] for m in MODELS], showfliers=False,
                         patch_artist=True, widths=0.62, medianprops={"color": "#111111", "linewidth": 1.1})
        for patch, model in zip(box["boxes"], MODELS):
            patch.set_facecolor(COLORS[model]); patch.set_alpha(0.72); patch.set_linewidth(0.65)
        ax.set_yscale("log")
        ax.set_title(CONDITION_LABELS[condition])
        ax.tick_params(axis="x", rotation=30)
        style_axis(ax)
    axes[0].set_ylabel("Absolute error / training range")
    fig.suptitle("Five-seed one-step error distributions on complete test segments", fontsize=11.5)
    save_figure(fig, output_dir / "Fig11_one_step_normalized_error_boxplots.png")


def plot_one_step_radar(summary: pd.DataFrame, output_dir: Path):
    angles = np.linspace(0, 2 * np.pi, len(OUTPUTS), endpoint=False)
    closed_angles = np.r_[angles, angles[0]]
    fig, axes = plt.subplots(1, 3, figsize=(11.5, 3.45), subplot_kw={"projection": "polar"}, constrained_layout=True)
    for ax, condition in zip(axes, CONDITIONS):
        panel = summary[summary["condition"] == condition]
        best = panel.groupby("output")["RMSE_mean"].min()
        for model in MODELS:
            model_values = panel[panel["model"] == model].set_index("output")["RMSE_mean"]
            score = np.asarray([best[o] / model_values[o] for o in OUTPUTS], dtype=float)
            closed = np.r_[score, score[0]]
            ax.plot(closed_angles, closed, color=COLORS[model], marker="o", markersize=2.5,
                    linewidth=1.15, label=MODEL_LABELS[model])
            ax.fill(closed_angles, closed, color=COLORS[model], alpha=0.025)
        ax.set_xticks(angles, [OUTPUT_LABELS[o] for o in OUTPUTS])
        ax.set_ylim(0, 1.02)
        ax.set_yticks([0.25, 0.50, 0.75, 1.00])
        ax.set_yticklabels(["0.25", "0.50", "0.75", "1.00"], fontsize=8)
        ax.set_title(CONDITION_LABELS[condition], pad=13)
        ax.grid(color="#B7B7B7", alpha=0.35, linewidth=0.55)
    axes[-1].legend(loc="center left", bbox_to_anchor=(1.12, 0.5), fontsize=8)
    fig.suptitle("Relative one-step RMSE by output (1 = best within each task)", fontsize=11.5)
    save_figure(fig, output_dir / "Fig12_one_step_relative_rmse_radar.png")


def plot_recursive_all_conditions(summary: pd.DataFrame, output_dir: Path):
    fig, axes = plt.subplots(3, 5, figsize=(11.5, 7.0), constrained_layout=True)
    for row, condition in enumerate(CONDITIONS):
        for col, output in enumerate(OUTPUTS):
            ax = axes[row, col]
            panel = summary[(summary["condition"] == condition) & (summary["output"] == output)]
            floor = float(panel.loc[panel["MSE_mean"] > 0, "MSE_mean"].min()) * 0.25
            for model in MODELS:
                subset = panel[panel["model"] == model].sort_values("horizon")
                x = subset["horizon"].to_numpy(dtype=float)
                mean = subset["MSE_mean"].to_numpy(dtype=float)
                std = subset["MSE_std"].to_numpy(dtype=float)
                ax.plot(x, mean, "-o", color=COLORS[model], markersize=2.4, linewidth=1.0,
                        label=MODEL_LABELS[model])
                ax.fill_between(x, np.maximum(mean - std, floor), mean + std,
                                color=COLORS[model], alpha=0.08, linewidth=0)
            ax.set_yscale("log")
            ax.set_xticks(HORIZONS)
            if row == 0:
                ax.set_title(OUTPUT_LABELS[output])
            if col == 0:
                ax.set_ylabel(f"{CONDITION_LABELS[condition]}\nMSE")
            if row == 2:
                ax.set_xlabel("Horizon")
            style_axis(ax)
    axes[0, -1].legend(fontsize=7.5, loc="best")
    fig.suptitle("Five-seed finite-horizon recursive prediction", fontsize=11.5)
    save_figure(fig, output_dir / "Fig13_recursive_mse_all_conditions.png")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--package-root", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--pinn-2026-recovery-dir")
    args = parser.parse_args()
    package = Path(args.package_root)
    results_root = package / next(p.name for p in package.iterdir() if p.is_dir() and p.name.startswith("04"))
    recursive_root = results_root / "final_simulation_20260831" / "04_recursive_finite_horizon"
    output = Path(args.output_dir)
    tables = output / "tables"
    figures = output / "figures"
    audit_dir = output / "audit"
    for directory in (tables, figures, audit_dir):
        directory.mkdir(parents=True, exist_ok=True)
    recovery = Path(args.pinn_2026_recovery_dir) if args.pinn_2026_recovery_dir else None
    audit = []

    mape_reference_max = training_output_max(package)
    one_step = collect_one_step(results_root, audit, mape_reference_max)
    recursive = collect_recursive(recursive_root, recovery, audit)
    recursive_pooled = pool_recursive_leads(recursive)
    recursive_endpoint = recursive[recursive["lead"] == recursive["horizon"]].copy()

    one_step_summary = mean_std(
        one_step, ["model", "model_label", "condition", "output"],
        ("MSE", "RMSE", "MAE", "MAPE_percent", "MAPE_active_coverage", "MAPE_active_threshold", "fit_score_percent", "R2"),
    )
    recursive_lead_summary = mean_std(
        recursive, ["model", "model_label", "condition", "horizon", "lead", "output"],
        ("MSE", "RMSE", "MAE", "R2"),
    )
    recursive_pooled_summary = mean_std(
        recursive_pooled, ["model", "model_label", "condition", "horizon", "output"],
        ("MSE", "RMSE", "MAE", "mean_lead_R2"),
    )
    recursive_endpoint_summary = mean_std(
        recursive_endpoint, ["model", "model_label", "condition", "horizon", "output"],
        ("MSE", "RMSE", "MAE", "R2"),
    )

    one_step_tests = paired_tests(one_step, "one_step", ("MSE",), ["condition", "output"])
    recursive_tests = paired_tests(
        recursive_pooled, "recursive_pooled_horizon", ("MSE",), ["condition", "horizon", "output"]
    )

    outputs = {
        "one_step_seed_metrics.csv": one_step,
        "one_step_mean_std.csv": one_step_summary,
        "one_step_wilcoxon_holm.csv": one_step_tests,
        "recursive_per_lead_seed_metrics.csv": recursive,
        "recursive_per_lead_mean_std.csv": recursive_lead_summary,
        "recursive_pooled_horizon_seed_metrics.csv": recursive_pooled,
        "recursive_pooled_horizon_mean_std.csv": recursive_pooled_summary,
        "recursive_endpoint_mean_std.csv": recursive_endpoint_summary,
        "recursive_wilcoxon_holm.csv": recursive_tests,
    }
    for name, frame in outputs.items():
        frame.to_csv(tables / name, index=False, encoding="utf-8-sig")

    apply_style()
    plot_one_step(one_step_summary, figures)
    plot_recursive(recursive_pooled_summary, figures)
    plot_representative_one_step(results_root, figures)
    plot_representative_recursive(recursive_root, figures)
    plot_one_step_error_boxplots(results_root, figures)
    plot_one_step_radar(one_step_summary, figures)
    plot_recursive_all_conditions(recursive_pooled_summary, figures)

    issues = [row for row in audit if row["status"] not in ("included",)]
    audit_payload = {
        "protocol": {
            "seeds": list(SEEDS), "models": list(MODELS), "conditions": list(CONDITIONS),
            "outputs": list(OUTPUTS), "horizons": list(HORIZONS),
            "std_definition": "sample standard deviation across five seeds (ddof=1)",
            "test": "paired two-sided Wilcoxon signed-rank on seed-level MSE",
            "multiplicity": "Holm correction across the four TK-PINN-versus-baseline comparisons within each condition/output/horizon family",
            "recursive_pooled_definition": "For each seed, MSE and MAE are averaged over leads 1..H; RMSE is sqrt(pooled MSE).",
            "log_band_display": "When mean minus std is non-positive, only the plotted lower band is clipped to 0.25 times the panel's smallest positive mean; CSV values are unchanged.",
            "fit_score_definition": "100*(1-sqrt(sum(error^2))/sqrt(sum(target^2)))",
            "mape_definition": "100*mean(abs(error/target)) over |target| >= 0.01*training_max_abs(output); zero and inactive samples excluded",
            "mape_reference_max_abs_training": mape_reference_max,
        },
        "counts": {
            "one_step_seed_metric_rows": int(len(one_step)),
            "recursive_per_lead_rows": int(len(recursive)),
            "recursive_pooled_seed_metric_rows": int(len(recursive_pooled)),
            "one_step_tests": int(len(one_step_tests)),
            "recursive_tests": int(len(recursive_tests)),
        },
        "issues": issues,
        "seed2026_recovery_comparison": compare_seed2026_runs(recursive_root, recovery),
        "runs": audit,
    }
    (audit_dir / "five_seed_evidence_audit.json").write_text(
        json.dumps(audit_payload, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(json.dumps({"output": str(output), "tables": len(outputs), "figures": 15,
                      "audit_issues": len(issues)}, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
