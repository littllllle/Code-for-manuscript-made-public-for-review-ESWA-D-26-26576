"""Create paper-ready figures and tables from completed experiment archives."""
import argparse
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from revision_explicit_pinn.plotting.paper_style import apply_paper_style, save_figure, style_axes


def read_csv(path):
    return pd.read_csv(str(path))


def save_table(df, path, title):
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(str(path.with_suffix(".csv")), index=False, encoding="utf-8-sig")
    with path.open("w", encoding="utf-8") as f:
        f.write("# {}\n\n".format(title))
        columns = [str(c) for c in df.columns]
        f.write("| " + " | ".join(columns) + " |\n")
        f.write("| " + " | ".join(["---"] * len(columns)) + " |\n")
        for row in df.itertuples(index=False, name=None):
            values = ["" if pd.isna(v) else str(v) for v in row]
            f.write("| " + " | ".join(values) + " |\n")
        f.write("\n")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--archive", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    archive, out = Path(args.archive), Path(args.output)
    out.mkdir(parents=True, exist_ok=True)
    figdir, tabdir = out / "figures", out / "tables"
    figdir.mkdir(exist_ok=True); tabdir.mkdir(exist_ok=True)
    apply_paper_style()

    # 105-run grid: mean validation loss by batch size and window.
    grid = read_csv(archive / "grid" / "grid_progress.csv")
    grid_mean = grid.groupby(["batch_size", "window"], as_index=False)["validation_data_loss"].mean()
    pivot = grid_mean.pivot(index="batch_size", columns="window", values="validation_data_loss")
    save_table(grid_mean, tabdir / "grid_validation_summary.md", "Grid-search validation summary")
    fig, ax = plt.subplots(figsize=(7.0, 4.8), constrained_layout=True)
    im = ax.imshow(pivot.values, aspect="auto", cmap="viridis")
    ax.set_xticks(range(len(pivot.columns))); ax.set_xticklabels(pivot.columns)
    ax.set_yticks(range(len(pivot.index))); ax.set_yticklabels(pivot.index)
    ax.set_xlabel("Window length"); ax.set_ylabel("Batch size")
    ax.set_title("105-run grid search: mean validation loss")
    fig.colorbar(im, ax=ax, label="Validation loss")
    save_figure(fig, figdir / "grid_validation_heatmap.png")

    # Ablation and baselines, averaged over seeds.
    abl = read_csv(archive / "ablation" / "ablation_results.csv")
    abl["label"] = abl["variant"].astype(str) + " / " + abl["weighting"].astype(str)
    agg = abl.groupby(["variant", "weighting"], as_index=False).agg(
        mean_validation_loss=("best_validation_data_loss", "mean"),
        std_validation_loss=("best_validation_data_loss", "std"),
        seeds=("seed", "nunique"),
    )
    save_table(agg, tabdir / "ablation_summary.md", "Ablation and baseline summary")
    plot_agg = agg.sort_values("mean_validation_loss")
    fig, ax = plt.subplots(figsize=(8.0, 4.8), constrained_layout=True)
    ax.bar(np.arange(len(plot_agg)), plot_agg.mean_validation_loss,
           yerr=plot_agg.std_validation_loss.fillna(0), color="#1f77b4", alpha=0.85, capsize=3)
    ax.set_xticks(np.arange(len(plot_agg)))
    ax.set_xticklabels(["{} / {}".format(a, b) for a, b in zip(plot_agg.variant, plot_agg.weighting)], rotation=45, ha="right")
    ax.set_ylabel("Mean best validation loss"); ax.set_title("Ablation and baseline comparison")
    style_axes(ax)
    save_figure(fig, figdir / "ablation_validation_bar.png")

    # First-unit one-step and rollout summaries for all frozen models.
    eval_rows = []
    eval_root = archive / "selected_evaluation"
    for model_dir in sorted(eval_root.iterdir()):
        for mode, filename in (("one_step", "first_unit_one_step_by_condition.csv"), ("rollout", "first_unit_rollout_by_condition.csv")):
            path = model_dir / filename
            if path.exists():
                frame = read_csv(path); frame["model"] = model_dir.name; frame["mode"] = mode; eval_rows.append(frame)
    evaluation = pd.concat(eval_rows, ignore_index=True)
    eval_summary = evaluation.groupby(["model", "mode", "output"], as_index=False).agg(
        RMSE=("RMSE", "mean"), MAE=("MAE", "mean"), R2=("R2", "mean"), MAPE_percent=("MAPE_percent", "mean")
    )
    save_table(eval_summary, tabdir / "first_unit_evaluation_summary.md", "First-unit evaluation summary")
    metric = eval_summary[eval_summary["output"] == "P_c"]
    models = metric["model"].unique()
    labels = [m.replace("_", " ") for m in models]
    x = np.arange(len(labels)); width = 0.38
    fig, ax = plt.subplots(figsize=(7.2, 4.6), constrained_layout=True)
    one = metric[metric["mode"] == "one_step"].set_index("model").reindex(models)
    roll = metric[metric["mode"] == "rollout"].set_index("model").reindex(models)
    ax.bar(x - width/2, one.RMSE.values, width, label="One-step", color="#1f77b4")
    ax.bar(x + width/2, roll.RMSE.values, width, label="Rollout", color="#d62728")
    ax.set_xticks(x); ax.set_xticklabels(labels, rotation=20, ha="right"); ax.set_ylabel("Pressure RMSE")
    ax.set_title("First-unit one-step versus free-running evaluation"); ax.legend(); style_axes(ax)
    save_figure(fig, figdir / "first_unit_one_step_vs_rollout.png")

    # Noise robustness: mean RMSE across outputs and conditions.
    noise_rows = []
    for model_dir in sorted((archive / "noise").iterdir()):
        path = model_dir / "noise_metrics_by_condition.csv"
        if path.exists():
            frame = read_csv(path); frame["model"] = model_dir.name; noise_rows.append(frame)
    noise = pd.concat(noise_rows, ignore_index=True)
    noise_summary = noise.groupby(["model", "noise_level"], as_index=False).agg(mean_RMSE=("RMSE", "mean"), mean_MAE=("MAE", "mean"))
    save_table(noise_summary, tabdir / "noise_robustness_summary.md", "Noise robustness summary")
    fig, ax = plt.subplots(figsize=(7.2, 4.6), constrained_layout=True)
    for model, frame in noise_summary.groupby("model"):
        frame = frame.sort_values("noise_level")
        ax.plot(frame.noise_level * 100, frame.mean_RMSE, marker="o", label=model.replace("_", " "))
    ax.set_xlabel("Input noise (% of column range)"); ax.set_ylabel("Mean RMSE"); ax.set_title("Noise robustness")
    ax.legend(); style_axes(ax); save_figure(fig, figdir / "noise_robustness.png")

    # Second-unit zero-shot comparison.
    second_rows = []
    for model_dir in sorted(eval_root.iterdir()):
        for mode, filename in (("one_step", "second_unit_zero_shot_one_step.csv"), ("rollout", "second_unit_zero_shot_rollout.csv")):
            path = model_dir / filename
            if path.exists():
                frame = read_csv(path); frame["model"] = model_dir.name; frame["mode"] = mode; second_rows.append(frame)
    if second_rows:
        second = pd.concat(second_rows, ignore_index=True)
        second_summary = second.groupby(["model", "mode", "output"], as_index=False).agg(RMSE=("RMSE", "mean"), MAE=("MAE", "mean"), R2=("R2", "mean"))
        save_table(second_summary, tabdir / "second_unit_zero_shot_summary.md", "Second-unit zero-shot summary")
        metric = second_summary[second_summary["output"] == "P_c"]
        fig, ax = plt.subplots(figsize=(7.2, 4.6), constrained_layout=True)
        for mode, style in (("one_step", "-o"), ("rollout", "--s")):
            frame = metric[metric["mode"] == mode]
            ax.plot(frame.model, frame.RMSE, style, label=mode.replace("_", " "))
        ax.set_ylabel("Pressure RMSE"); ax.set_title("Second-unit zero-shot evaluation")
        ax.tick_params(axis="x", rotation=20); ax.legend(); style_axes(ax)
        save_figure(fig, figdir / "second_unit_zero_shot.png")

    print("Generated figures and tables in {}".format(out))


if __name__ == "__main__":
    main()
