import csv
import json
from pathlib import Path


def collect_runs(root):
    rows = []
    for summary_path in Path(root).glob("*/summary.json"):
        run_dir = summary_path.parent
        with summary_path.open("r", encoding="utf-8") as handle:
            summary = json.load(handle)
        config_path = run_dir / "run_config.json"
        with config_path.open("r", encoding="utf-8") as handle:
            config = json.load(handle)
        summary.update(
            {
                "run_id": run_dir.name,
                "window": config["data"]["window"],
                "batch_size": config["train"]["batch_size"],
                "seed": config["train"]["seed"],
                "weighting": config["train"]["weighting"],
            }
        )
        rows.append(summary)
    return rows


def write_long_form(rows, path):
    if not rows:
        raise ValueError("No completed runs found")
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = sorted({key for row in rows for key in row})
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)
