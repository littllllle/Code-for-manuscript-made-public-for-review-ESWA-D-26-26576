"""Run and archive the final five-instance window-4 ablation suite.

The full TK-PINN rows are copied from the audited primary suite.  Every other
variant is trained through the same train.py entry point and evaluated on the
complete test trajectories.  The manifest is updated after each run so an
interruption can be resumed without mixing historical directories.
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
from pathlib import Path


HERE = Path(__file__).resolve()
PACKAGE = HERE.parents[3]
CODE = PACKAGE / "03_代码"
RESULTS = PACKAGE / "04_图表与CSV结果"
DATA = Path(r"D:\PythonProjects\PINN_code+tex\data\999")
PYTHON = Path(r"D:\Anaconda\envs\PINN-KAN\python.exe")
TRAIN = CODE / "revision_explicit_pinn" / "scripts" / "train.py"
PRIMARY = RESULTS / "primary_window4_20260907"
OUT = RESULTS / "ablation_window4_20260908"
SEEDS = (2026, 2027, 2028, 2029, 2030)

VARIANTS = {
    "full_tk_pinn": {"source": "primary", "label": "Full TK-PINN"},
    "no_physics": {"closure": "kan", "weighting": "kendall", "no_physics": True,
                    "label": "No physics residual"},
    "no_kan": {"closure": "fixed", "weighting": "kendall", "label": "No KAN closure"},
    "equal_weighting": {"closure": "kan", "weighting": "equal", "label": "Equal weighting"},
    "fixed_weighting": {"closure": "kan", "weighting": "static", "static_mass_weight": 0.5,
                        "static_energy_weight": 0.5, "label": "Fixed weighting"},
    "separate_scalar": {"closure": "kan", "weighting": "kendall",
                         "head_factorization": "separate_scalar", "label": "Separate scalar heads"},
}


def env():
    value = os.environ.copy()
    value["PYTHONPATH"] = str(CODE) + os.pathsep + value.get("PYTHONPATH", "")
    root = PYTHON.parent
    value["PATH"] = os.pathsep.join([str(root), str(root / "Scripts"), str(root / "Library" / "bin"), value.get("PATH", "")])
    return value


def complete(run_dir: Path) -> bool:
    required = ("best.pt", "history.json", "run_config.json", "summary.json",
                "test_metrics.csv", "test_predictions.csv", "test_predictions.npz")
    return all((run_dir / name).exists() for name in required)


def copy_full(seed: int, destination: Path):
    source = PRIMARY / f"tk_pinn_seed{seed}"
    if not complete(source):
        raise FileNotFoundError(f"audited primary run is incomplete: {source}")
    if destination.exists() and not complete(destination):
        shutil.rmtree(destination)
    if not destination.exists():
        shutil.copytree(source, destination)
    config_path = destination / "run_config.json"
    config = json.loads(config_path.read_text(encoding="utf-8"))
    config.setdefault("provenance", {})
    config["provenance"].update({"suite": "ablation_window4_20260908", "variant": "full_tk_pinn",
                                  "source_run": str(source)})
    config["model"].setdefault("head_factorization", "joint_vector")
    # The primary checkpoints were trained with this explicit runtime setting;
    # serialize it here so the unified ablation archive is self-contained.
    config["physics_runtime"] = {
        "gas_constant": 287.0, "effective_volume": 20.0, "specific_heat": 753.869,
        "lower_heating_value": 4.95e7, "combustion_efficiency": 1.0,
        "pressure_retention": 0.98, "turbine_efficiency": 0.90, "gamma": 1.33,
        "exhaust_back_pressure_pa": 101350.0, "ambient_pressure_pa": 101350.0,
        "compressor_inlet_temperature_k": 288.0, "dt": 1.0,
    }
    config_path.write_text(json.dumps(config, indent=2), encoding="utf-8")


def train_variant(variant: str, spec: dict, seed: int, destination: Path):
    command = [str(PYTHON), str(TRAIN), "--data-dir", str(DATA), "--output-dir", str(destination),
               "--window", "4", "--batch-size", "32", "--epochs", "50", "--patience", "50",
               "--learning-rate", "0.0001", "--seed", str(seed), "--d-model", "64", "--layers", "2",
               "--decoder-layers", "2", "--nhead", "4", "--feedforward", "128", "--device", "cuda",
               "--model-type", "transformer", "--closure", spec.get("closure", "kan"),
               "--weighting", spec.get("weighting", "kendall"), "--head-factorization",
               spec.get("head_factorization", "joint_vector")]
    if spec.get("no_physics"):
        command.append("--no-physics")
    if spec.get("weighting") == "static":
        command += ["--static-mass-weight", str(spec.get("static_mass_weight", 0.5)),
                    "--static-energy-weight", str(spec.get("static_energy_weight", 0.5))]
    log_path = destination.parent / f"{destination.name}.log"
    destination.parent.mkdir(parents=True, exist_ok=True)
    with log_path.open("a", encoding="utf-8") as log:
        log.write("COMMAND: " + " ".join(command) + "\n")
        log.flush()
        completed_process = subprocess.run(command, env=env(), stdout=log, stderr=subprocess.STDOUT)
    if completed_process.returncode != 0 or not complete(destination):
        raise RuntimeError(f"failed or incomplete run: {variant} seed {seed}; see {log_path}")


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    manifest_path = OUT / "ablation_manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8")) if manifest_path.exists() else []
    known = {(row.get("variant"), int(row.get("seed"))): row for row in manifest}
    total = len(VARIANTS) * len(SEEDS)
    counter = 0
    for variant, spec in VARIANTS.items():
        for seed in SEEDS:
            counter += 1
            run_dir = OUT / f"{variant}_seed{seed}"
            key = (variant, seed)
            if complete(run_dir):
                if spec.get("source") == "primary":
                    copy_full(seed, run_dir)
                print(f"[{counter}/{total}] already complete {variant} seed {seed}", flush=True)
                known[key] = {"variant": variant, "seed": seed, "status": "complete", "output": str(run_dir)}
                continue
            print(f"[{counter}/{total}] start {variant} seed {seed}", flush=True)
            if spec.get("source") == "primary":
                copy_full(seed, run_dir)
            else:
                train_variant(variant, spec, seed, run_dir)
            known[key] = {"variant": variant, "seed": seed, "status": "complete", "output": str(run_dir),
                          "label": spec["label"], "window": 4, "epochs": 50}
            manifest_path.write_text(json.dumps(list(known.values()), indent=2), encoding="utf-8")
    manifest_path.write_text(json.dumps(list(known.values()), indent=2), encoding="utf-8")
    print("final window-4 ablation suite complete", flush=True)


if __name__ == "__main__":
    main()
