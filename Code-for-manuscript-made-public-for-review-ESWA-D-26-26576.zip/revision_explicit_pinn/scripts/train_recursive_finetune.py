"""Fine-tune the existing model with multi-step recursive loss and scheduled sampling."""

from __future__ import annotations

import argparse
import csv
import copy
import json
import random
import sys
import time
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import DataLoader, Subset

# Support direct execution via ``python scripts/train_recursive_finetune.py``.
PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from revision_explicit_pinn.data import build_preshifted_datasets
from revision_explicit_pinn.evaluation import metric_table, one_step_predictions
from revision_explicit_pinn.losses import KendallTaskWeighting, StaticTaskWeighting
from revision_explicit_pinn.models import BaselineConfig, BaselinePredictor, ExplicitPhysicsPINN, ModelConfig
from revision_explicit_pinn.scripts.train_preshifted_horizon import (
    HORIZONS,
    fixed_horizon_rollout,
    horizon_metrics,
)
from revision_explicit_pinn.training import TrainConfig, Trainer, set_seed


OUTPUT_NAMES = ("P_c", "n", "W_e", "T_e", "G_NOx")


def write_rows(path, rows):
    with Path(path).open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def sampling_probability(epoch: int, epochs: int) -> float:
    """Probability of feeding the model prediction into the next step."""
    progress = (epoch - 1) / max(epochs - 1, 1)
    return float(np.interp(progress, [0.0, 0.25, 0.5, 0.75, 1.0], [0.10, 0.30, 0.50, 0.70, 1.0]))


def rollout_batch(
    model,
    features,
    future_targets,
    future_controls,
    physics,
    weighting,
    loss_scales,
    use_physics,
    kan_regularization,
    prediction_probability,
    training,
):
    windows = features
    data_terms, mass_terms, energy_terms = [], [], []
    for step in range(future_targets.shape[1]):
        output = model(windows)
        data_terms.append(torch.mean((output["prediction"] - future_targets[:, step]) ** 2))
        if use_physics:
            physical = physics(
                windows,
                output["prediction"],
                output["flows"],
                output["previous_flows"],
                output.get("latent_delta"),
            )
            mass_terms.append(physical["mass_loss"])
            energy_terms.append(physical["energy_loss"])
        if step + 1 < future_targets.shape[1]:
            if training:
                use_prediction = torch.rand((len(features), 1), device=features.device) < prediction_probability
                next_output = torch.where(use_prediction, output["prediction"], future_targets[:, step])
            else:
                next_output = output["prediction"]
            next_tokens = torch.cat([future_controls[:, step], next_output], dim=-1).unsqueeze(1)
            windows = torch.cat([windows[:, 1:], next_tokens], dim=1)
    data_loss = torch.stack(data_terms).mean()
    if use_physics:
        mass_loss = torch.stack(mass_terms).mean()
        energy_loss = torch.stack(energy_terms).mean()
        scaled_data = data_loss / loss_scales["data"]
        scaled_mass = mass_loss / loss_scales["mass"]
        scaled_energy = energy_loss / loss_scales["energy"]
        total, weights = weighting(scaled_data, scaled_mass, scaled_energy)
    else:
        mass_loss = torch.zeros_like(data_loss)
        energy_loss = torch.zeros_like(data_loss)
        scaled_data, scaled_mass, scaled_energy = data_loss, mass_loss, energy_loss
        total = data_loss
        weights = {"data": 1.0, "mass": 0.0, "energy": 0.0}
    kan_loss = model.flow_closure.regularization_loss()
    objective = total + kan_regularization * kan_loss
    return objective, {
        "total": objective,
        "data": data_loss,
        "mass": mass_loss,
        "energy": energy_loss,
        "kan": kan_loss,
        "scaled_data": scaled_data,
        "scaled_mass": scaled_mass,
        "scaled_energy": scaled_energy,
        "weights": weights,
    }


def valid_indices(dataset, segments, horizon):
    lengths = {segment.source: len(segment.values) for segment in segments}
    starts = {segment.source: segment.start for segment in segments}
    indices = []
    for index, (_, _, metadata) in enumerate(dataset.samples):
        local_target = metadata["target_storage_row"] - starts[metadata["source"]]
        if local_target + horizon < lengths[metadata["source"]]:
            indices.append(index)
    return indices


def make_future_arrays(metadata, segments, scaler, horizon):
    by_source = {segment.source: segment for segment in segments}
    targets, controls = [], []
    # PyTorch's default collate turns a list of metadata dictionaries into a
    # dictionary whose values are batch-sized lists/tensors.
    if isinstance(metadata, dict):
        metadata = [
            {
                "source": metadata["source"][index],
                "target_storage_row": metadata["target_storage_row"][index],
            }
            for index in range(len(metadata["source"]))
        ]
    for item in metadata:
        segment = by_source[item["source"]]
        local_target = int(item["target_storage_row"]) - segment.start
        normalized = scaler.transform(segment.values).astype(np.float32)
        rows = normalized[local_target : local_target + horizon]
        targets.append(rows[:, 2:])
        controls.append(rows[:-1, :2])
    return np.asarray(targets, dtype=np.float32), np.asarray(controls, dtype=np.float32)


def epoch(model, loader, segments, scaler, trainer, horizon, probability, training, optimizer, max_steps=0):
    model.train(training)
    trainer.weighting.train(training)
    totals = {key: 0.0 for key in ("total", "data", "mass", "energy", "kan")}
    count = 0
    context = torch.enable_grad() if training else torch.no_grad()
    with context:
        for step, (features, _, metadata) in enumerate(loader, start=1):
            features = features.to(trainer.device)
            target_np, control_np = make_future_arrays(metadata, segments, scaler, horizon)
            future_targets = torch.as_tensor(target_np, device=trainer.device)
            future_controls = torch.as_tensor(control_np, device=trainer.device)
            objective, values = rollout_batch(
                model,
                features,
                future_targets,
                future_controls,
                trainer.physics,
                trainer.weighting,
                trainer.loss_scales,
                trainer.config.use_physics,
                trainer.config.kan_regularization,
                probability,
                training,
            )
            if training:
                optimizer.zero_grad()
                objective.backward()
                torch.nn.utils.clip_grad_norm_(
                    list(model.parameters()) + list(trainer.weighting.parameters()),
                    trainer.config.gradient_clip,
                )
                optimizer.step()
            batch_count = len(features)
            for key in totals:
                totals[key] += float(values[key].detach()) * batch_count
            count += batch_count
            if max_steps > 0 and step >= max_steps:
                break
    return {key: value / max(count, 1) for key, value in totals.items()}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", required=True)
    parser.add_argument("--base-dir", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument(
        "--model-name",
        choices=("pinn", "transformer", "lstm", "tcn", "kan"),
        required=True,
    )
    parser.add_argument("--window", type=int, default=8)
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--epochs", type=int, default=20)
    parser.add_argument("--fine-tune-horizon", type=int, default=16)
    parser.add_argument("--seed", type=int, default=2026)
    parser.add_argument("--evaluate-only", action="store_true")
    parser.add_argument("--resume", action="store_true", help="resume from output-dir/best.pt and history.json")
    parser.add_argument("--from-scratch", action="store_true", help="start recursive training without a base checkpoint")
    args = parser.parse_args()
    set_seed(args.seed)
    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)
    bundle = build_preshifted_datasets(args.data_dir, window=args.window, include_test=True)
    audits = bundle.train.audit() + bundle.validation.audit() + bundle.test.audit()
    if audits:
        raise RuntimeError("Pre-shifted causal audit failed: {}".format(audits[:3]))

    use_physics = args.model_name == "pinn"
    base_config = json.loads((Path(args.base_dir) / "run_config.json").read_text(encoding="utf-8"))
    if args.model_name in ("pinn", "transformer"):
        model_config = ModelConfig(
            d_model=base_config["model"]["d_model"],
            nhead=base_config["model"]["nhead"],
            encoder_layers=base_config["model"]["encoder_layers"],
            decoder_layers=base_config["model"].get("decoder_layers", 2),
            feedforward_dim=base_config["model"]["feedforward_dim"],
            max_window=base_config["model"]["max_window"],
            closure="kan" if use_physics else "fixed",
        )
        model = ExplicitPhysicsPINN(model_config)
    else:
        model_config = BaselineConfig(
            model_type=args.model_name,
            input_dim=base_config["model"].get("input_dim", 7),
            output_dim=base_config["model"].get("output_dim", 5),
            hidden_dim=base_config["model"].get("hidden_dim", base_config["model"].get("d_model", 64)),
            layers=base_config["model"].get("layers", base_config["model"].get("encoder_layers", 2)),
            dropout=base_config["model"].get("dropout", 0.1),
            max_window=base_config["model"].get("max_window", 30),
        )
        model = BaselinePredictor(model_config)
    train_config = TrainConfig(
        epochs=args.epochs,
        batch_size=args.batch_size,
        patience=args.epochs,
        learning_rate=5e-5,
        weighting="kendall" if use_physics else "equal",
        seed=args.seed,
        use_physics=use_physics,
    )
    trainer = Trainer(model, bundle, output, train_config)
    checkpoint_path = Path(args.base_dir) / "best.pt"
    if not args.from_scratch:
        checkpoint = torch.load(checkpoint_path, map_location=trainer.device)
        try:
            model.load_state_dict(checkpoint["model"])
            if use_physics and "weighting" in checkpoint:
                trainer.weighting.load_state_dict(checkpoint["weighting"])
        except (RuntimeError, KeyError) as exc:
            raise RuntimeError("Base checkpoint is incompatible with the selected model; use --from-scratch or a matching checkpoint") from exc
    optimizer = torch.optim.Adam(
        list(model.parameters()) + list(trainer.weighting.parameters()), lr=train_config.learning_rate
    )

    train_indices = valid_indices(bundle.train, bundle.segments["train"], args.fine_tune_horizon)
    validation_indices = valid_indices(bundle.validation, bundle.segments["validation"], args.fine_tune_horizon)
    train_loader = DataLoader(
        Subset(bundle.train, train_indices), batch_size=args.batch_size, shuffle=True, drop_last=True
    )
    validation_loader = DataLoader(
        Subset(bundle.validation, validation_indices), batch_size=args.batch_size, shuffle=False, drop_last=False
    )
    started = time.time()
    history = []
    start_epoch = 1
    if args.evaluate_only:
        best_state = torch.load(output / "best.pt", map_location=trainer.device)
    elif args.resume:
        history_path = output / "history.json"
        resume_path = output / "best.pt"
        if not history_path.exists() or not resume_path.exists():
            raise FileNotFoundError("--resume requires output-dir/history.json and output-dir/best.pt")
        history = json.loads(history_path.read_text(encoding="utf-8"))
        if not history:
            raise RuntimeError("Cannot resume from an empty history")
        best_state = torch.load(resume_path, map_location=trainer.device)
        model.load_state_dict(best_state["model"])
        trainer.weighting.load_state_dict(best_state["weighting"])
        start_epoch = int(history[-1]["epoch"]) + 1
        best_validation = float(best_state["validation_recursive_data_loss"])
        print(
            f"[recursive] resuming at epoch={start_epoch} from best epoch={best_state['epoch']} "
            f"validation_data={best_validation:.6g}",
            flush=True,
        )
    else:
        best_state = None
        best_validation = float("inf")
    if not args.evaluate_only:
        for current_epoch in range(start_epoch, args.epochs + 1):
            probability = sampling_probability(current_epoch, args.epochs)
            train_metrics = epoch(
                model, train_loader, bundle.segments["train"], bundle.scaler, trainer,
                args.fine_tune_horizon, probability, True, optimizer
            )
            validation_metrics = epoch(
                model, validation_loader, bundle.segments["validation"], bundle.scaler, trainer,
                args.fine_tune_horizon, 1.0, False, optimizer
            )
            row = {
                "epoch": current_epoch,
                "prediction_probability": probability,
                **{"train_" + key: value for key, value in train_metrics.items()},
                **{"validation_" + key: value for key, value in validation_metrics.items()},
            }
            history.append(row)
            # Persist after every epoch so a long recursive run remains
            # auditable even if the later full-test evaluation is interrupted.
            (output / "history.json").write_text(json.dumps(history, indent=2), encoding="utf-8")
            print(
                f"[recursive] epoch={current_epoch} p={probability:.2f} "
                f"train_data={train_metrics['data']:.6g} validation_data={validation_metrics['data']:.6g}",
                flush=True,
            )
            if validation_metrics["data"] < best_validation:
                best_validation = validation_metrics["data"]
                best_state = {
                    "model": copy.deepcopy(model.state_dict()),
                    "weighting": copy.deepcopy(trainer.weighting.state_dict()),
                    "epoch": current_epoch,
                    "validation_recursive_data_loss": best_validation,
                }
                torch.save(best_state, output / "best.pt")
    if best_state is None:
        raise RuntimeError("Recursive fine-tuning produced no checkpoint")
    model.load_state_dict(best_state["model"])
    trainer.weighting.load_state_dict(best_state["weighting"])
    if args.evaluate_only and not (output / "history.json").exists():
        (output / "history.json").write_text(json.dumps([], indent=2), encoding="utf-8")
    (output / "run_config.json").write_text(
        json.dumps(
            {
                "base_dir": str(Path(args.base_dir).resolve()),
                "model": model_config.__dict__,
                "training_mechanism": "multi_step_recursive_loss_plus_scheduled_sampling",
                "fine_tune_horizon": args.fine_tune_horizon,
                "epochs": args.epochs,
                "best_epoch": best_state["epoch"],
                "evaluation_only": args.evaluate_only,
                "resumed": args.resume,
                "resume_optimizer_policy": "Adam reinitialized at the declared learning rate; model and Kendall states restored from best.pt" if args.resume else "not_applicable",
                "batch_size": args.batch_size,
                "learning_rate": train_config.learning_rate,
                "seed": args.seed,
                "window_semantics": "pre-shifted CSV rows are consumed directly; recursive block feeds model predictions",
                "data": {"window": args.window},
                "scaler": bundle.scaler.state_dict(),
                "device": str(trainer.device),
                "elapsed_seconds": time.time() - started,
            },
            indent=2,
        ),
        encoding="utf-8",
    )

    target_norm, prediction_norm = one_step_predictions(model, bundle.test, trainer.device, batch_size=256)
    target = target_norm * bundle.scaler.scale[2:] + bundle.scaler.minimum[2:]
    prediction = prediction_norm * bundle.scaler.scale[2:] + bundle.scaler.minimum[2:]
    write_rows(output / "test_metrics.csv", metric_table(target, prediction))
    np.savez_compressed(output / "test_predictions.npz", target=target, prediction=prediction)
    all_rows = []
    for horizon in HORIZONS:
        horizon_target, horizon_prediction, conditions, origins = [], [], [], []
        for segment in bundle.segments["test"]:
            segment_origins, truth, pred = fixed_horizon_rollout(
                model, segment, bundle.scaler, args.window, horizon, trainer.device
            )
            truth = truth * bundle.scaler.scale[2:] + bundle.scaler.minimum[2:]
            pred = pred * bundle.scaler.scale[2:] + bundle.scaler.minimum[2:]
            horizon_target.append(truth); horizon_prediction.append(pred)
            conditions.extend([segment.condition] * len(segment_origins)); origins.extend(segment_origins.tolist())
            all_rows.extend(horizon_metrics(truth, pred, horizon, segment.condition, args.model_name, OUTPUT_NAMES))
        target_h = np.concatenate(horizon_target, axis=0)
        prediction_h = np.concatenate(horizon_prediction, axis=0)
        all_rows.extend(horizon_metrics(target_h, prediction_h, horizon, "all_test", args.model_name, OUTPUT_NAMES))
        if horizon == max(HORIZONS):
            np.savez_compressed(output / "recursive_predictions_h80.npz", target=target_h, prediction=prediction_h, condition=np.asarray(conditions), origin=np.asarray(origins))
    write_rows(output / "fixed_horizon_metrics.csv", all_rows)
    print(json.dumps({"model": args.model_name, "best_epoch": best_state["epoch"], "train_samples": len(train_indices), "validation_samples": len(validation_indices)}, indent=2), flush=True)


if __name__ == "__main__":
    main()
