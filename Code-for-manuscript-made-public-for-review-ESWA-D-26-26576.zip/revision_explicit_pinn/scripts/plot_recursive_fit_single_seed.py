"""Plot representative finite-horizon recursive fits for one seed."""
import argparse
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from revision_explicit_pinn.data.schema import OUTPUT_NAMES, UNITS
from revision_explicit_pinn.plotting.paper_style import apply_paper_style, save_figure


ROOT = Path(r"D:\PythonProjects\PINN_code+tex\ESWA返修\返修交付包_统一参数框架_20260831\04_图表与CSV结果\final_simulation_20260831\04_recursive_finite_horizon")
MODELS = {
    "lstm": ("LSTM", "#2ca02c"),
    "tcn": ("TCN", "#9467bd"),
    "kan": ("KAN", "#ff7f0e"),
    "transformer": ("Transformer", "#1f77b4"),
    "pinn": ("TK-PINN", "#d62728"),
}
CONDITIONS = ("startup", "load_change", "shutdown")
LABELS = {"startup": "Test 1: Startup", "load_change": "Test 2: Load change", "shutdown": "Test 3: Shutdown"}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--seed", type=int, default=2026)
    parser.add_argument("--horizon", type=int, default=80)
    parser.add_argument("--origin-index", type=int, default=0)
    parser.add_argument("--output-dir", default=str(ROOT / "summary_figures" / "single_seed"))
    args = parser.parse_args()
    out = Path(args.output_dir); out.mkdir(parents=True, exist_ok=True)
    apply_paper_style(font_size=9)
    loaded = {}
    for model, style in MODELS.items():
        path = ROOT / ("{}_seed{}".format(model, args.seed)) / ("recursive_predictions_h{}.npz".format(args.horizon))
        if path.exists():
            data = np.load(str(path), allow_pickle=True)
            loaded[model] = (style, data["target"], data["prediction"], data["condition"])
    if not loaded:
        raise FileNotFoundError("No recursive prediction file found for seed {}".format(args.seed))
    first = next(iter(loaded.values()))
    conditions = np.asarray(first[3]).astype(str)
    for condition in CONDITIONS:
        indices = np.flatnonzero(conditions == condition)
        if len(indices) == 0:
            continue
        row_index = int(indices[min(args.origin_index, len(indices) - 1)])
        fig, axes = plt.subplots(5, 1, figsize=(8.0, 9.2), sharex=True, constrained_layout=True)
        x = np.arange(1, args.horizon + 1)
        target = first[1][row_index]
        for j, (ax, name) in enumerate(zip(axes, OUTPUT_NAMES)):
            ax.plot(x, target[:, j], color="#555555", linestyle="--", linewidth=1.0, label="Measured" if j == 0 else None)
            for model, (style, target_arr, prediction_arr, cond_arr) in loaded.items():
                cond_mask = np.asarray(cond_arr).astype(str) == condition
                cond_indices = np.flatnonzero(cond_mask)
                if row_index not in cond_indices:
                    continue
                pred = prediction_arr[row_index]
                label, color = style
                ax.plot(x, pred[:, j], color=color, linewidth=0.9, label=label if j == 0 else None)
            ax.set_ylabel("{}\n({})".format(name, UNITS[name]))
            ax.grid(alpha=0.2, linewidth=0.6)
            ax.tick_params(direction="in")
        axes[0].set_title("{} | seed={} | origin={} | horizon={} steps".format(LABELS[condition], args.seed, row_index, args.horizon))
        axes[0].legend(loc="best", ncol=3, frameon=False)
        axes[-1].set_xlabel("Recursive lead (steps)")
        save_figure(fig, out / "{}_seed{}_horizon{}_fit.png".format(condition, args.seed, args.horizon), dpi=300)
        plt.close(fig)
    print("Generated single-seed recursive fit figures in {}".format(out))


if __name__ == "__main__":
    main()
