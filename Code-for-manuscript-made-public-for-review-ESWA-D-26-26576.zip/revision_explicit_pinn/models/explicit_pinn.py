from dataclasses import dataclass

import torch

from .kan import FlowClosureKAN


@dataclass(frozen=True)
class ModelConfig:
    input_dim: int = 7
    output_dim: int = 5
    d_model: int = 64
    nhead: int = 4
    encoder_layers: int = 2
    decoder_layers: int = 2
    feedforward_dim: int = 128
    dropout: float = 0.1
    max_window: int = 30
    closure: str = "kan"
    head_factorization: str = "joint_vector"
    architecture: str = "transformer_encoder_decoder"


class FixedFlowClosure(torch.nn.Module):
    def __init__(self, rated_flow=621.58):
        super().__init__()
        self.register_buffer("rated_flow", torch.tensor(float(rated_flow)))

    def forward(self, features):
        air = torch.full_like(features[..., 0], self.rated_flow)
        accumulation = torch.zeros_like(air)
        return torch.stack([air, accumulation], dim=-1)

    def regularization_loss(self):
        return self.rated_flow * 0.0


class ExplicitPhysicsPINN(torch.nn.Module):
    """Causal Transformer encoder-decoder with a separate KAN flow closure.

    The encoder consumes the complete pre-shifted row [u(k), y(k-1)].  The
    decoder consumes only the five lagged-output columns already stored in the
    same input window.  Targets are deliberately absent from this interface.
    """

    def __init__(self, config=None):
        super().__init__()
        self.config = config or ModelConfig()
        cfg = self.config
        if cfg.architecture != "transformer_encoder_decoder":
            raise ValueError("Unsupported architecture {}".format(cfg.architecture))
        self.input_projection = torch.nn.Linear(cfg.input_dim, cfg.d_model)
        self.decoder_input_projection = torch.nn.Linear(cfg.output_dim, cfg.d_model)
        self.encoder_position = torch.nn.Parameter(torch.zeros(1, cfg.max_window, cfg.d_model))
        self.decoder_position = torch.nn.Parameter(torch.zeros(1, cfg.max_window, cfg.d_model))
        encoder_layer = torch.nn.TransformerEncoderLayer(
            d_model=cfg.d_model,
            nhead=cfg.nhead,
            dim_feedforward=cfg.feedforward_dim,
            dropout=cfg.dropout,
            activation="gelu",
            batch_first=True,
            norm_first=False,
        )
        self.encoder = torch.nn.TransformerEncoder(encoder_layer, num_layers=cfg.encoder_layers)
        decoder_layer = torch.nn.TransformerDecoderLayer(
            d_model=cfg.d_model,
            nhead=cfg.nhead,
            dim_feedforward=cfg.feedforward_dim,
            dropout=cfg.dropout,
            activation="gelu",
            batch_first=True,
            norm_first=False,
        )
        self.decoder = torch.nn.TransformerDecoder(decoder_layer, num_layers=cfg.decoder_layers)
        causal_mask = torch.full((cfg.max_window, cfg.max_window), float("-inf"))
        causal_mask = torch.triu(causal_mask, diagonal=1)
        self.register_buffer("decoder_causal_mask", causal_mask, persistent=False)
        if cfg.head_factorization == "joint_vector":
            self.output_head = torch.nn.Sequential(
                torch.nn.LayerNorm(cfg.d_model),
                torch.nn.Linear(cfg.d_model, cfg.output_dim),
            )
        elif cfg.head_factorization == "separate_scalar":
            self.output_head = torch.nn.ModuleList([
                torch.nn.Sequential(torch.nn.LayerNorm(cfg.d_model), torch.nn.Linear(cfg.d_model, 1))
                for _ in range(cfg.output_dim)
            ])
        else:
            raise ValueError("Unknown head factorization {}".format(cfg.head_factorization))
        self.latent_state_head = torch.nn.Sequential(
            torch.nn.LayerNorm(cfg.d_model),
            torch.nn.Linear(cfg.d_model, 2),
        )
        if cfg.closure == "kan":
            self.flow_closure = FlowClosureKAN(input_dim=cfg.input_dim)
        elif cfg.closure == "fixed":
            self.flow_closure = FixedFlowClosure()
        else:
            raise ValueError("Unknown closure {}".format(cfg.closure))
        torch.nn.init.normal_(self.encoder_position, mean=0.0, std=0.02)
        torch.nn.init.normal_(self.decoder_position, mean=0.0, std=0.02)

    def forward(self, features):
        if features.ndim != 3 or features.shape[-1] != self.config.input_dim:
            raise ValueError("Expected features with shape [batch, window, 7]")
        if features.shape[1] > self.config.max_window:
            raise ValueError("Window exceeds configured positional capacity")
        sequence_length = features.shape[1]
        encoder_tokens = self.input_projection(features) + self.encoder_position[:, :sequence_length]
        memory = self.encoder(encoder_tokens)
        # Columns 2: are y(k-1) already shifted in the CSV.  No target tensor
        # and no second time shift is introduced here.
        decoder_tokens = self.decoder_input_projection(features[..., 2:])
        decoder_tokens = decoder_tokens + self.decoder_position[:, :sequence_length]
        decoded = self.decoder(
            tgt=decoder_tokens,
            memory=memory,
            tgt_mask=self.decoder_causal_mask[:sequence_length, :sequence_length],
        )
        last = decoded[:, -1]
        # Predict observable increments. This stabilizes startup/shutdown and
        # makes the causal state transition explicit.
        if self.config.head_factorization == "joint_vector":
            raw_delta = self.output_head(last)
        else:
            raw_delta = torch.cat([head(last) for head in self.output_head], dim=-1)
        delta = 0.25 * torch.tanh(raw_delta)
        prediction = features[:, -1, 2:] + delta
        latent_delta = torch.stack(
            [1.0e5 * torch.tanh(self.latent_state_head(last)[:, 0]),
             100.0 * torch.tanh(self.latent_state_head(last)[:, 1])], dim=-1
        )
        current_flows = self.flow_closure(features[:, -1])
        previous_features = features[:, -2] if features.shape[1] > 1 else features[:, -1]
        previous_flows = self.flow_closure(previous_features)
        return {
            "prediction": prediction,
            "flows": current_flows,
            "previous_flows": previous_flows,
            "latent_delta": latent_delta,
        }
