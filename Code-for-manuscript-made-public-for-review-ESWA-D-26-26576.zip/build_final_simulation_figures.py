"""Build the final simulation-only figures for the ESWA revision.

All plots are derived from frozen result artifacts.  The script never edits
training outputs and emits both a 600-dpi PNG and a vector PDF for Fig. 6--22.
"""
from __future__ import annotations

import json
import hashlib
import math
import re
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.colors import TwoSlopeNorm
from matplotlib.lines import Line2D
import numpy as np
import pandas as pd


HERE = Path(__file__).resolve()
PACKAGE = HERE.parents[1]
RESULTS = PACKAGE / "04_图表与CSV结果"
COMPLETE = RESULTS / "complete_code_tests_20260830"
FINAL = RESULTS / "final_simulation_20260831"
STATS = FINAL / "05_five_seed_statistics_20260902"
EVIDENCE = RESULTS / "final_reviewer_evidence_20260829"
OUT = RESULTS / "replot_20260831" / "figures"
OUT.mkdir(parents=True, exist_ok=True)
TABLE_OUT = RESULTS / "replot_20260831" / "tables"
TABLE_OUT.mkdir(parents=True, exist_ok=True)

REFERENCE_STYLE = PACKAGE / "03_代码" / "plotting_参照"
sys.path.insert(0, str(REFERENCE_STYLE))
from paper_plot_style import apply_paper_style, format_axis, panel_label  # noqa: E402


SEEDS = (2026, 2027, 2028, 2029, 2030)
INSTANCE_BY_SEED = dict(zip(SEEDS, "ABCDE"))
MODELS = ("lstm", "tcn", "kan", "transformer", "pinn")
REQUIRED_EXTERNAL_MODELS = frozenset(MODELS)
LABELS = {"lstm": "LSTM", "tcn": "TCN", "kan": "KAN", "transformer": "Transformer", "pinn": "TK-PINN"}
COLORS = {"lstm": "#3F8F72", "tcn": "#6F4AA8", "kan": "#D18F3B", "transformer": "#1F5A7A", "pinn": "#C1121F"}
LINESTYLES = {
    "lstm": (0, (5.0, 2.2)),
    "tcn": (0, (1.2, 1.7)),
    "kan": (0, (7.0, 2.0, 1.4, 2.0)),
    "transformer": (0, (3.0, 1.5)),
    "pinn": (0, (6.0, 1.25)),
}
CONDITIONS = ("startup", "load_change", "shutdown")
CONDITION_LABELS = {"startup": "Startup", "load_change": "Load change", "shutdown": "Shutdown"}
OUTPUTS = ("P_c", "n", "W_e", "T_e", "G_NOx")
OUTPUT_LABELS = (r"$P_c$ (kg$\cdot$cm$^{-2}$)", r"$n$ (r$\cdot$min$^{-1}$)", r"$W_e$ (MW)", r"$T_e$ ($^{\circ}$C)", r"$G_{NOx}$ (mg$\!\cdot\!$Nm$^{-3}$)")
OUTPUT_SHORT = (r"$P_c$", r"$n$", r"$W_e$", r"$T_e$", r"$G_{NOx}$")
HORIZONS = (10, 20, 40, 80)
MEASURED_COLOR = "#202020"
MEASURED_STYLE = "-"
MEASURED_WIDTH = 0.72
BASELINE_WIDTH = 0.78
PINN_WIDTH = 1.18
# Single-column trajectory figures should use the available column width while
# remaining vertically compact enough to avoid dominating a manuscript page.
SINGLE_TRAJECTORY_SIZE = (3.55, 5.35)
OUTPUT_HEAD_ROOT = COMPLETE / "phase9_mimo_miso"
MANIFEST: list[dict] = []


def require_all_external_models(available, figure_number: int) -> None:
    """Reject an external TK-PINN comparison unless every baseline is present."""
    available_models = set(available)
    missing = REQUIRED_EXTERNAL_MODELS - available_models
    extra = available_models - REQUIRED_EXTERNAL_MODELS
    if missing or extra:
        raise RuntimeError(
            f"Fig. {figure_number} external-comparison model set is invalid; "
            f"missing={sorted(missing)}, extra={sorted(extra)}"
        )


def save(fig: plt.Figure, number: int, stem: str, sources: list[Path], note: str = "") -> None:
    png = OUT / f"Fig{number:02d}_{stem}.png"
    pdf = png.with_suffix(".pdf")
    fig.savefig(png, dpi=600, bbox_inches="tight", facecolor="white")
    fig.savefig(pdf, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    missing = [str(path) for path in sources if not path.exists()]
    if missing:
        raise FileNotFoundError(f"Fig. {number} missing sources: {missing}")
    MANIFEST.append({"figure": number, "stem": stem, "png": str(png), "pdf": str(pdf),
                     "sources": [str(path) for path in sources], "note": note})


def style_axes(axes) -> None:
    for axis in np.asarray(axes, dtype=object).ravel():
        format_axis(axis)
        axis.grid(False)


def one_step_path(model: str, seed: int) -> Path:
    if model in {"pinn", "transformer"}:
        return FINAL / "03_one_step_encoder_decoder" / f"{model}_seed{seed}" / "test_predictions.csv"
    suffix = "tcn_seed2026_cpu_retry" if model == "tcn" and seed == 2026 else f"{model}_seed{seed}"
    return COMPLETE / "phase10_baselines" / suffix / "test_predictions.csv"


def recursive_dir(model: str, seed: int) -> Path:
    if model == "pinn" and seed == 2026:
        recovered = FINAL / "04_recursive_finite_horizon" / "pinn_seed2026_recovery_20260902"
        if recovered.exists():
            return recovered
    return FINAL / "04_recursive_finite_horizon" / f"{model}_seed{seed}"


def training_ranges() -> np.ndarray:
    config = FINAL / "03_one_step_encoder_decoder" / "pinn_seed2027" / "run_config.json"
    data = json.loads(config.read_text(encoding="utf-8"))
    return np.asarray(data["scaler"]["maximum"], float)[2:] - np.asarray(data["scaler"]["minimum"], float)[2:]


def model_legend(include_measured: bool = True):
    handles = []
    if include_measured:
        handles.append(Line2D([0], [0], color=MEASURED_COLOR, ls=MEASURED_STYLE,
                              lw=MEASURED_WIDTH, alpha=0.78, label="Measured"))
    handles.extend(Line2D([0], [0], color=COLORS[m], ls=LINESTYLES[m],
                          lw=PINN_WIDTH if m == "pinn" else BASELINE_WIDTH,
                          alpha=1.0 if m == "pinn" else 0.82, label=LABELS[m]) for m in MODELS)
    return handles


def plot_trajectory_axis(axis, x, measured, predictions, bands=None) -> None:
    """Draw dense trajectories without allowing the reference to hide predictions."""
    axis.plot(x, measured, color=MEASURED_COLOR, ls=MEASURED_STYLE,
              lw=MEASURED_WIDTH, alpha=0.76, zorder=1)
    if bands:
        for model in MODELS:
            if model in bands:
                lower, upper = bands[model]
                axis.fill_between(x, lower, upper, color=COLORS[model], alpha=0.045,
                                  linewidth=0, zorder=2)
    for layer, model in enumerate(MODELS, start=3):
        axis.plot(x, predictions[model], color=COLORS[model], ls=LINESTYLES[model],
                  lw=PINN_WIDTH if model == "pinn" else BASELINE_WIDTH,
                  alpha=1.0 if model == "pinn" else 0.80,
                  zorder=9 if model == "pinn" else layer)
    final_index = max(int(len(x) - 1), 1)
    axis.set_xlim(0, final_index)
    # Use evenly spaced integer-second ticks beginning at zero.  The terminal
    # sample is labelled only when it lies exactly on the selected interval.
    raw_step = max(final_index / 4.0, 1.0)
    magnitude = 10.0 ** math.floor(math.log10(raw_step))
    normalized = raw_step / magnitude
    multiplier = next(value for value in (1.0, 2.0, 5.0, 10.0) if normalized <= value)
    tick_step = max(int(multiplier * magnitude), 1)
    axis.set_xticks(np.arange(0, final_index + 1, tick_step, dtype=int))
    axis.margins(x=0)


def plot_validation_sensitivity() -> None:
    root = COMPLETE / "phase6_window"
    rows = []
    sources = []
    for directory in sorted(root.iterdir()):
        summary = directory / "summary.json"
        if not summary.exists():
            continue
        sources.append(summary)
        value = json.loads(summary.read_text(encoding="utf-8"))["best_validation_data_loss"]
        rows.append({"model": "pinn" if directory.name.startswith("pinn") else "transformer",
                     "window": int(re.search(r"w(\d+)", directory.name).group(1)), "mse": value})
    frame = pd.DataFrame(rows)
    fig, axis = plt.subplots(figsize=(3.45, 2.65))
    for model in ("transformer", "pinn"):
        part = frame[frame.model == model].sort_values("window")
        axis.plot(part.window, part.mse, marker="o", ms=3.5,
                  color=COLORS[model], lw=1.1,
                  label="Historical " + LABELS[model])
    axis.axvline(8, color="#555555", lw=0.8, ls=":")
    axis.text(8.5, 0.96, r"Common $S_l=8$", transform=axis.get_xaxis_transform(),
              va="top", fontsize=7.5)
    axis.set_xlabel("Window length")
    axis.set_ylabel("Normalized validation MSE")
    axis.legend(fontsize=7.2, loc="best")
    axis.ticklabel_format(axis="y", style="sci", scilimits=(-2, 2))
    style_axes([axis])
    save(fig, 6, "validation_window_sensitivity", sources,
         "Historical encoder-only 10-epoch diagnostic; no final encoder-decoder point is mixed into this curve.")



def plot_kan_interpretability() -> None:
    final_kan = RESULTS / "submission_audit_20260906" / "kan_final"
    kan_root = final_kan / "kan"
    curves_path = kan_root / "seed2027" / "kan_edge_curves.json"
    importance_path = final_kan / "tables" / "kan_input_importance_mean_std.csv"
    edge_path = final_kan / "tables" / "kan_edge_importance_mean_std.csv"
    pruning_path = final_kan / "tables" / "kan_pruning_validation_mean_std.csv"
    curves = json.loads(curves_path.read_text(encoding="utf-8"))["curves"]
    input_imp = pd.read_csv(importance_path)
    edge_imp = pd.read_csv(edge_path)
    pruning = pd.read_csv(pruning_path)
    fig, axes = plt.subplots(2, 2, figsize=(7.2, 5.15))
    feature_labels = {
        "G_f": r"$G_f(k)$",
        "O_IGV": r"$O_{\mathrm{IGV}}(k)$",
        "prev_P_c": r"$P_c(k-1)$",
        "prev_n": r"$n(k-1)$",
        "prev_W_e": r"$W_e(k-1)$",
        "prev_T_e": r"$T_e(k-1)$",
        "prev_G_NOx": r"$G_{\mathrm{NOx}}(k-1)$",
    }
    # Show the strongest edge for each measured feature so the diagnostic is
    # not dominated by several hidden-unit edges of the same input.
    selected = []
    for input_name, group in pd.DataFrame(curves).groupby("input_name"):
        selected.append(max(group.to_dict("records"), key=lambda item: item["importance_rms"]))
    for curve in sorted(selected, key=lambda item: item["importance_rms"], reverse=True):
        input_name = feature_labels.get(curve.get("input_name", "input"), curve.get("input_name", "input"))
        axes[0, 0].plot(curve["x"], curve["y"], lw=1.15,
                        label=rf"{input_name} $\rightarrow h_{{{curve['output_index'] + 1}}}$")
    axes[0, 0].set_xlabel("Normalized input")
    axes[0, 0].set_ylabel("Learned edge response")
    axes[0, 0].legend(ncol=2, fontsize=8.0)
    names = input_imp.feature.astype(str).map(lambda value: feature_labels.get(value, value))
    order = np.argsort(input_imp.air_mean.to_numpy())[-7:]
    y = np.arange(len(order))
    axes[0, 1].barh(y - 0.17, input_imp.air_mean.to_numpy()[order], 0.33,
                    xerr=input_imp.air_std.to_numpy()[order], color="#D18F3B", alpha=0.86, capsize=2, label="Air-flow closure")
    axes[0, 1].barh(y + 0.17, input_imp.accumulation_mean.to_numpy()[order], 0.33,
                    xerr=input_imp.accumulation_std.to_numpy()[order], color="#3F8F72", alpha=0.86, capsize=2, label="Accumulation closure")
    axes[0, 1].set_yticks(y, names.to_numpy()[order])
    axes[0, 1].set_xlabel("Permutation importance")
    axes[0, 1].legend(fontsize=7.5)
    edge_mean_col = next(c for c in edge_imp.columns if c.endswith("mean"))
    values = np.sort(edge_imp[edge_mean_col].to_numpy(float))[::-1]
    axes[1, 0].plot(np.arange(1, len(values) + 1), values, color="#6F4AA8")
    axes[1, 0].fill_between(np.arange(1, len(values) + 1), 0, values, color="#6F4AA8", alpha=0.14)
    axes[1, 0].set_xlabel("Edge importance rank")
    axes[1, 0].set_ylabel("RMS importance")
    axes[1, 1].errorbar(pruning.pruned_percentile, pruning.mass_ratio_mean, yerr=pruning.mass_ratio_std,
                        marker="o", ms=4, capsize=2.5, color="#6F4AA8", label="Mass residual")
    axes[1, 1].errorbar(pruning.pruned_percentile, pruning.energy_ratio_mean, yerr=pruning.energy_ratio_std,
                        marker="s", ms=3.8, capsize=2.5, color="#3F8F72", label="Energy residual")
    axes[1, 1].axhline(1.0, color="#666666", lw=0.7, ls=":")
    axes[1, 1].set_xlabel("Pruned edges (%)")
    axes[1, 1].set_ylabel("Residual ratio to unpruned KAN")
    axes[1, 1].legend(fontsize=7.6)
    style_axes(axes)
    for i, axis in enumerate(axes.ravel()):
        panel_label(axis, i, y=-0.27)
    fig.subplots_adjust(left=0.09, right=0.985, bottom=0.12, top=0.98, wspace=0.38, hspace=0.52)
    save(fig, 7, "kan_interpretability", [curves_path, importance_path, edge_path, pruning_path])


def plot_one_step_trajectory(number: int, condition: str) -> None:
    require_all_external_models(MODELS, number)
    sources = [one_step_path(model, 2027) for model in MODELS]
    frames = {model: pd.read_csv(path) for model, path in zip(MODELS, sources)}
    fig, axes = plt.subplots(5, 1, figsize=SINGLE_TRAJECTORY_SIZE, sharex=True)
    for output_index, axis in enumerate(axes):
        reference = frames["pinn"]
        part = reference[(reference.condition == condition) & (reference.output_index == output_index)]
        x = np.arange(len(part))
        predictions = {}
        for model in MODELS:
            subset = frames[model][(frames[model].condition == condition) & (frames[model].output_index == output_index)]
            if len(subset) != len(part):
                raise RuntimeError(f"Fig. {number}: unequal trajectory lengths for {model}, output {output_index}")
            predictions[model] = subset.prediction.to_numpy()
        plot_trajectory_axis(axis, x, part.target.to_numpy(), predictions)
        axis.set_ylabel(OUTPUT_LABELS[output_index])
        if output_index < 4:
            axis.tick_params(labelbottom=False)
    axes[-1].set_xlabel("Time (s)")
    style_axes(axes)
    fig.legend(handles=model_legend(), loc="upper center", ncol=3, bbox_to_anchor=(0.5, 0.998),
               fontsize=6.9, handlelength=2.4, columnspacing=0.85, handletextpad=0.35)
    fig.subplots_adjust(left=0.205, right=0.985, bottom=0.078, top=0.905, hspace=0.13)
    save(fig, number, f"one_step_{condition}", sources, "Complete test segment; representative seed 2027.")


def plot_error_boxplots() -> None:
    require_all_external_models(MODELS, 11)
    ranges = training_ranges()
    sources = [one_step_path(model, seed) for model in MODELS for seed in SEEDS]
    values = {(condition, model): [] for condition in CONDITIONS for model in MODELS}
    for model in MODELS:
        for seed in SEEDS:
            frame = pd.read_csv(one_step_path(model, seed))
            for condition in CONDITIONS:
                for oi in range(5):
                    part = frame[(frame.condition == condition) & (frame.output_index == oi)]
                    values[(condition, model)].extend((np.abs(part.prediction - part.target) / ranges[oi]).tolist())
    fig, axes = plt.subplots(1, 3, figsize=(7.2, 2.85), sharey=True)
    for ci, (condition, axis) in enumerate(zip(CONDITIONS, axes)):
        data = [np.asarray(values[(condition, model)]) * 100 for model in MODELS]
        box = axis.boxplot(data, showfliers=False, whis=(5, 95), patch_artist=True,
                           medianprops={"color": "#111111", "linewidth": 0.9})
        for patch, model in zip(box["boxes"], MODELS):
            patch.set_facecolor(COLORS[model]); patch.set_alpha(0.78); patch.set_edgecolor("#333333")
        axis.set_xticks(range(1, 6), [LABELS[m] for m in MODELS], rotation=32, ha="right")
        # Place the operating-condition label below the tick labels and above
        # the subfigure marker, matching the manuscript's lower-label layout.
        axis.set_title("")
        axis.text(0.5, -0.47, CONDITION_LABELS[condition], transform=axis.transAxes,
                  ha="center", va="top", fontsize=11.5)
        panel_label(axis, ci, y=-0.68)
    axes[0].set_ylabel("Normalized absolute error (%)")
    style_axes(axes)
    fig.subplots_adjust(left=0.09, right=0.99, bottom=0.39, top=0.98, wspace=0.18)
    save(fig, 11, "one_step_error_boxplots", sources,
         "Absolute errors normalized by the corresponding training-only output range; whiskers are 5th--95th percentiles.")


def plot_radar() -> None:
    require_all_external_models(MODELS, 12)
    source = STATS / "tables" / "one_step_mean_std.csv"
    frame = pd.read_csv(source)
    angles = np.linspace(0, 2 * np.pi, 5, endpoint=False)
    closed = np.r_[angles, angles[0]]
    fig, axes = plt.subplots(1, 3, figsize=(7.2, 2.75), subplot_kw={"projection": "polar"})
    for ci, (condition, axis) in enumerate(zip(CONDITIONS, axes)):
        part = frame[frame.condition == condition]
        best = part.groupby("output").RMSE_mean.min()
        for model in MODELS:
            model_part = part[part.model == model].set_index("output")
            scores = np.array([best[o] / model_part.loc[o, "RMSE_mean"] for o in OUTPUTS])
            axis.plot(closed, np.r_[scores, scores[0]], color=COLORS[model], ls=LINESTYLES[model], lw=1.05)
        axis.set_xticks(angles, OUTPUT_SHORT)
        axis.set_ylim(0, 1.04)
        axis.set_yticks((0.25, 0.5, 0.75, 1.0), ("", "0.50", "", "1.00"), fontsize=7.5)
        axis.set_title("")
        panel_label(axis, ci, y=-0.34)
    fig.legend(handles=model_legend(False), loc="upper center", ncol=5, bbox_to_anchor=(0.5, 1.02), fontsize=8.3)
    fig.subplots_adjust(left=0.035, right=0.97, bottom=0.24, top=0.79, wspace=0.45)
    save(fig, 12, "one_step_relative_rmse_radar", [source], "Score = best task RMSE / model task RMSE; higher is better.")


def plot_recursive_summary() -> None:
    require_all_external_models(MODELS, 13)
    source = STATS / "tables" / "recursive_pooled_horizon_mean_std.csv"
    frame = pd.read_csv(source)
    fig, axes = plt.subplots(5, 3, figsize=(7.20, 7.75), sharex=True)
    for oi, output in enumerate(OUTPUTS):
        for ci, condition in enumerate(CONDITIONS):
            axis = axes[oi, ci]
            for model in MODELS:
                part = frame[(frame.output == output) & (frame.condition == condition) & (frame.model == model)].sort_values("horizon")
                axis.errorbar(part.horizon, part.MSE_mean, yerr=part.MSE_std, color=COLORS[model],
                              ls=LINESTYLES[model], marker="o", ms=2.8, capsize=1.8, lw=0.9)
            axis.set_yscale("log")
            if oi == 0:
                axis.set_title(CONDITION_LABELS[condition])
            if ci == 0:
                axis.set_ylabel(f"{OUTPUT_SHORT[oi]} MSE")
            if oi == 4:
                axis.set_xlabel("Prediction horizon")
                axis.set_xticks(HORIZONS)
    style_axes(axes)
    fig.legend(handles=model_legend(False), loc="upper center", ncol=5, bbox_to_anchor=(0.5, 0.998), fontsize=8.4)
    fig.subplots_adjust(left=0.11, right=0.985, bottom=0.072, top=0.935, wspace=0.30, hspace=0.18)
    save(fig, 13, "finite_horizon_summary", [source], "Five-seed mean +/- sample standard deviation.")


def plot_recursive_trajectory(number: int, condition: str, lead: int = 10) -> None:
    require_all_external_models(MODELS, number)
    sources = [recursive_dir(model, 2027) / "recursive_predictions_h80.npz" for model in MODELS]
    arrays = {model: np.load(path) for model, path in zip(MODELS, sources)}
    fig, axes = plt.subplots(5, 1, figsize=SINGLE_TRAJECTORY_SIZE, sharex=True)
    for oi, axis in enumerate(axes):
        ref = arrays["pinn"]
        mask = ref["condition"] == condition
        x = np.arange(int(mask.sum()))
        predictions = {}
        for model in MODELS:
            data = arrays[model]
            model_mask = data["condition"] == condition
            values = data["prediction"][model_mask, lead - 1, oi]
            if len(values) != len(x):
                raise RuntimeError(f"Fig. {number}: unequal recursive lengths for {model}, output {oi}")
            predictions[model] = values
        plot_trajectory_axis(axis, x, ref["target"][mask, lead - 1, oi], predictions)
        axis.set_ylabel(OUTPUT_LABELS[oi])
        if oi < 4:
            axis.tick_params(labelbottom=False)
    axes[-1].set_xlabel("Time (s)")
    style_axes(axes)
    fig.legend(handles=model_legend(), loc="upper center", ncol=3, bbox_to_anchor=(0.5, 0.998),
               fontsize=6.9, handlelength=2.4, columnspacing=0.85, handletextpad=0.35)
    fig.subplots_adjust(left=0.205, right=0.985, bottom=0.078, top=0.905, hspace=0.13)
    save(fig, number, f"recursive_h{lead}_{condition}", sources,
         f"All valid origins in the complete test segment; representative seed 2027; lead={lead}.")


def metric_from_prediction(path: Path, ranges: np.ndarray) -> pd.DataFrame:
    frame = pd.read_csv(path)
    rows = []
    for condition in CONDITIONS:
        for oi, output in enumerate(OUTPUTS):
            part = frame[(frame.condition == condition) & (frame.output_index == oi)]
            rows.append({"condition": condition, "output": output,
                         "nrmse": math.sqrt(float(np.mean((part.prediction - part.target) ** 2))) / ranges[oi]})
    return pd.DataFrame(rows)


def ablation_sources(phase: str, variants: dict):
    """Promote A-C only after checkpoint and full-test validation has passed."""
    manifest_path = RESULTS / "final_simulation_20260906_ablation" / "validated_five_instances.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8")) if manifest_path.exists() else None
    seeds = SEEDS if manifest else (2029, 2030)
    tag = "five_instances" if manifest else "two_audited_instances"
    runs = {(r["variant"], r["identifier"]): r for r in manifest["runs"]} if manifest else {}
    paths = {}
    for label, prefix in variants.items():
        for seed in seeds:
            if manifest:
                record = runs[(prefix or "pinn", seed)]
                path = PACKAGE / record["prediction_path"]
                if hashlib.sha256(path.read_bytes()).hexdigest() != record["prediction_sha256"]:
                    raise ValueError(f"Prediction changed after validation: {path}")
            else:
                path = (one_step_path("pinn", seed) if prefix is None else
                        COMPLETE / phase / f"{prefix}_seed{seed}" / "test_predictions.csv")
            paths[(label, seed)] = path
    return seeds, tag, paths


def plot_component_ablation() -> None:
    ranges = training_ranges()
    variants = {"Full TK-PINN": None, "Without physics": "kan", "Without KAN": "physics"}
    colors = {"Full TK-PINN": "#C1121F", "Without physics": "#D18F3B", "Without KAN": "#7D8790"}
    records, sources = [], []
    seeds, tag, paths = ablation_sources("phase4_component_ablation", variants)
    for label, directory_prefix in variants.items():
        for seed in seeds:
            path = paths[(label, seed)]
            sources.append(path)
            values = metric_from_prediction(path, ranges)
            values["variant"], values["seed"] = label, seed
            records.append(values)
    frame = pd.concat(records)
    instance_frame = frame.groupby(["variant", "seed", "output"], as_index=False).nrmse.mean()
    summary = instance_frame.groupby(["variant", "output"], as_index=False).nrmse.agg(["mean", "std"]).reset_index()
    export_frame = frame.rename(columns={"seed": "initialization_id"})
    export_frame.insert(2, "instance", export_frame.initialization_id.map(INSTANCE_BY_SEED))
    export_frame.to_csv(TABLE_OUT / f"Fig17a_component_nrmse_{tag}.csv", index=False)
    instance_export = instance_frame.rename(columns={"seed": "initialization_id"})
    instance_export.insert(2, "instance", instance_export.initialization_id.map(INSTANCE_BY_SEED))
    instance_export.to_csv(TABLE_OUT / "Fig17a_component_nrmse_by_instance.csv", index=False)
    summary.to_csv(TABLE_OUT / f"Fig17a_component_nrmse_mean_std_{tag}.csv", index=False)
    residual_path = RESULTS / "submission_audit_20260906" / "physics_residuals_final.csv"
    residual = pd.read_csv(residual_path)
    residual_export = residual[residual.model == "pinn"].rename(columns={"seed": "initialization_id"}).copy()
    residual_export.insert(2, "instance", residual_export.initialization_id.map(INSTANCE_BY_SEED))
    residual_export.to_csv(TABLE_OUT / "Fig17b_physics_residuals_five_instances.csv", index=False)
    fig, axes = plt.subplots(2, 1, figsize=(3.55, 4.55))
    x = np.arange(5)
    for vi, label in enumerate(variants):
        part = summary[summary.variant == label].set_index("output").loc[list(OUTPUTS)]
        axes[0].bar(x + (vi - 1) * 0.24, part["mean"] * 100, 0.23, yerr=part["std"] * 100,
                    color=colors[label], alpha=0.86, capsize=2, label=label, edgecolor="#333333", linewidth=0.3)
    axes[0].set_xticks(x, OUTPUT_SHORT)
    axes[0].set_ylabel("NRMSE (%)")
    axes[0].legend(fontsize=7.0, loc="lower center", bbox_to_anchor=(0.5, 1.01), ncol=2, frameon=False)
    part = residual[residual.model == "pinn"].groupby(["condition", "residual"]).rmse.agg(["mean", "std"])
    for ri, residual_name in enumerate(("mass", "energy")):
        vals = [float(part.loc[(condition, residual_name), "mean"]) for condition in CONDITIONS]
        deviations = [float(part.loc[(condition, residual_name), "std"]) for condition in CONDITIONS]
        axes[1].bar(np.arange(3) + (ri - 0.5) * 0.32, vals, 0.31, yerr=deviations, capsize=2,
                    color=("#6F4AA8" if residual_name == "mass" else "#3F8F72"), alpha=0.86, label=residual_name.capitalize())
    axes[1].set_xticks(np.arange(3), ("Startup", "Load change", "Shutdown"), rotation=18, ha="right")
    axes[1].set_ylabel("Balance-residual RMSE")
    axes[1].set_yscale("log")
    axes[1].legend(fontsize=8.0)
    style_axes(axes)
    for i, axis in enumerate(axes): panel_label(axis, i, y=-0.29)
    fig.subplots_adjust(left=0.20, right=0.98, bottom=0.11, top=0.94, hspace=0.48)
    save(fig, 17, "physics_kan_ablation", sources + [residual_path], f"Panel a: {len(seeds)} architecture-validated instances; panel b: final Instances A--E. Early-stopping policies differ; not an isolated causal ablation.")


def plot_kendall_weighting() -> None:
    ranges = training_ranges()
    history_sources = [FINAL / "03_one_step_encoder_decoder" / f"pinn_seed{seed}" / "history.json" for seed in SEEDS]
    fig, axes = plt.subplots(2, 1, figsize=(3.55, 4.55))
    weight_keys = (("effective_weight_data", "Data", "#C1121F"), ("effective_weight_mass", "Mass", "#6F4AA8"), ("effective_weight_energy", "Energy", "#3F8F72"))
    histories = [pd.DataFrame(json.loads(path.read_text(encoding="utf-8"))) for path in history_sources]
    epochs = histories[0].epoch.to_numpy()
    weight_records = []
    for key, label, color in weight_keys:
        matrix = np.vstack([history[key].to_numpy() for history in histories])
        for row_index, seed in enumerate(SEEDS):
            for epoch, value in zip(epochs, matrix[row_index]):
                weight_records.append({"instance": INSTANCE_BY_SEED[seed], "initialization_id": seed,
                                       "epoch": int(epoch), "task": label.lower(), "effective_weight": float(value)})
        axes[0].plot(epochs, matrix.mean(0), color=color, label=label)
        axes[0].fill_between(epochs, matrix.mean(0) - matrix.std(0, ddof=1), matrix.mean(0) + matrix.std(0, ddof=1), color=color, alpha=0.13)
    pd.DataFrame(weight_records).to_csv(TABLE_OUT / "Fig18a_kendall_weights_five_instances.csv", index=False)
    axes[0].set_xlabel("Epoch")
    axes[0].set_ylabel("Effective Kendall weight")
    axes[0].set_yscale("log")
    axes[0].legend(fontsize=8.0)
    variants = {"Equal": "equal", "Static": "static", "Kendall": None}
    records, sources = [], list(history_sources)
    seeds, tag, paths = ablation_sources("phase5_weighting", variants)
    for label, prefix in variants.items():
        for seed in seeds:
            path = paths[(label, seed)]
            sources.append(path)
            metric = metric_from_prediction(path, ranges)
            records.append({"variant": label, "seed": seed, "nrmse": metric.nrmse.mean() * 100})
    score = pd.DataFrame(records).groupby("variant").nrmse.agg(["mean", "std"]).loc[list(variants)]
    weighting_export = pd.DataFrame(records).rename(columns={"seed": "initialization_id"})
    weighting_export.insert(2, "instance", weighting_export.initialization_id.map(INSTANCE_BY_SEED))
    weighting_export.to_csv(TABLE_OUT / f"Fig18b_weighting_nrmse_{tag}.csv", index=False)
    score.rename_axis("weighting").reset_index().to_csv(
        TABLE_OUT / f"Fig18b_weighting_nrmse_mean_std_{tag}.csv", index=False)
    axes[1].bar(np.arange(3), score["mean"], yerr=score["std"], capsize=3,
                color=("#7D8790", "#D18F3B", "#C1121F"), alpha=0.86, edgecolor="#333333", linewidth=0.3)
    axes[1].set_xticks(np.arange(3), score.index)
    axes[1].set_ylabel("Mean NRMSE (%)")
    style_axes(axes)
    for i, axis in enumerate(axes): panel_label(axis, i, y=-0.29)
    fig.subplots_adjust(left=0.20, right=0.98, bottom=0.11, top=0.94, hspace=0.48)
    save(fig, 18, "kendall_weighting", sources, f"Weights: five final runs; comparison: {len(seeds)} architecture-validated instances, different scaling and early stopping.")


def plot_mimo_miso() -> None:
    # This controlled study changes only the final output organization.  The
    # so-called MISO-head variant still shares one Transformer trunk; it is not
    # equivalent to deploying five independently trained MISO networks.
    source = OUTPUT_HEAD_ROOT / "mimo_miso_run_summary_five_instances.csv"
    complexity_path = OUTPUT_HEAD_ROOT / "output_head_resource_metrics_five_instances.csv"
    frame = pd.read_csv(source)
    complexity = pd.read_csv(complexity_path).set_index("model")
    mode_paths = {}
    sources = [source, complexity_path]
    for instance, seed in zip("ABCDE", SEEDS):
        seed_root = OUTPUT_HEAD_ROOT / f"instance{instance}"
        for mode in ("mimo", "miso"):
            directory = seed_root / mode
            mode_paths[(seed, mode)] = directory
            sources.extend((directory / "test_predictions.npz", directory / "fixed_horizon_metrics.csv"))

    fig, axes = plt.subplots(2, 2, figsize=(7.2, 5.25))
    mode_colors = {"mimo": "#1F5A7A", "miso": "#C1121F"}
    mode_labels = {"mimo": "Joint vector head", "miso": "Separate scalar heads"}

    # (a) Paired validation results preserve seed pairing and show variability.
    pivot = frame.pivot(index="instance", columns="head_mode", values="validation_one_step_mse").sort_index()
    pivot.reset_index().to_csv(TABLE_OUT / "Fig19a_validation_mse_by_instance.csv", index=False)
    for _, row in pivot.iterrows():
        axes[0, 0].plot((0, 1), (row["mimo"], row["miso"]), color="#9B9B9B", lw=0.7, zorder=1)
    for xi, mode in enumerate(("mimo", "miso")):
        values = pivot[mode].to_numpy(float)
        jitter = np.linspace(-0.035, 0.035, len(values))
        axes[0, 0].scatter(np.full(len(values), xi) + jitter, values, s=24,
                           color=mode_colors[mode], edgecolor="white", linewidth=0.45, zorder=4)
        axes[0, 0].errorbar(xi, values.mean(), yerr=values.std(ddof=1), color="#111111",
                            marker="D", mfc="white", ms=4.2, capsize=2.5, lw=0.8, zorder=5)
    axes[0, 0].set_xticks((0, 1), tuple(mode_labels[m] for m in ("mimo", "miso")))
    axes[0, 0].set_ylabel("Validation MSE (normalized)")
    axes[0, 0].ticklabel_format(axis="y", style="sci", scilimits=(-2, 2))

    # (b) Output-resolved one-step test errors, normalized by training range.
    ranges = training_ranges()
    one_step = {mode: [] for mode in ("mimo", "miso")}
    for mode in one_step:
        for seed in SEEDS:
            data = np.load(mode_paths[(seed, mode)] / "test_predictions.npz")
            rmse = np.sqrt(np.mean((data["prediction"] - data["target"]) ** 2, axis=0)) / ranges
            one_step[mode].append(rmse * 100)
    one_step_rows = []
    one_step_instance_rows = []
    for mode, matrices in one_step.items():
        matrix = np.vstack(matrices)
        for row_index, seed in enumerate(SEEDS):
            for oi, output in enumerate(OUTPUTS):
                one_step_instance_rows.append({"head_organization": mode,
                                               "instance": INSTANCE_BY_SEED[seed],
                                               "initialization_id": seed,
                                               "output": output,
                                               "NRMSE_percent_range": matrix[row_index, oi]})
        for oi, output in enumerate(OUTPUTS):
            one_step_rows.append({"head_organization": mode, "output": output,
                                  "NRMSE_mean_percent_range": matrix[:, oi].mean(),
                                  "NRMSE_std_percent_range": matrix[:, oi].std(ddof=1), "independent_runs": len(SEEDS)})
    pd.DataFrame(one_step_rows).to_csv(TABLE_OUT / "Fig19b_one_step_nrmse_by_output.csv", index=False)
    pd.DataFrame(one_step_instance_rows).to_csv(
        TABLE_OUT / "Fig19b_one_step_nrmse_by_instance.csv", index=False)
    x = np.arange(5)
    for offset, mode in zip((-0.16, 0.16), ("mimo", "miso")):
        matrix = np.vstack(one_step[mode])
        axes[0, 1].bar(x + offset, matrix.mean(0), 0.31, yerr=matrix.std(0, ddof=1),
                       color=mode_colors[mode], alpha=0.84, capsize=2, linewidth=0,
                       label=mode_labels[mode])
    axes[0, 1].set_xticks(x, OUTPUT_SHORT)
    axes[0, 1].set_ylabel("One-step NRMSE (% range)")

    # (c) Condition/output-resolved lead-10 recursive ratio.  Positive values
    # mean that separate scalar heads have larger error than the vector head.
    log_ratios = np.zeros((len(CONDITIONS), len(OUTPUTS)))
    ratio_instance_rows = []
    for ci, condition in enumerate(CONDITIONS):
        for oi, output in enumerate(OUTPUTS):
            paired = []
            for seed in SEEDS:
                values = {}
                for mode in ("mimo", "miso"):
                    metrics = pd.read_csv(mode_paths[(seed, mode)] / "fixed_horizon_metrics.csv")
                    row = metrics[(metrics.condition == condition) & (metrics.horizon == 10) &
                                  (metrics.lead == 10) & (metrics.output == output)]
                    if len(row) != 1:
                        raise RuntimeError(f"Missing unique H=10 lead-10 row: {seed}, {mode}, {condition}, {output}")
                    values[mode] = float(row.iloc[0].MSE)
                log_ratio = np.log10(values["miso"] / values["mimo"])
                paired.append(log_ratio)
                ratio_instance_rows.append({"condition": condition,
                                            "output": output,
                                            "instance": INSTANCE_BY_SEED[seed],
                                            "initialization_id": seed,
                                            "scalar_to_vector_mse_ratio": float(10 ** log_ratio),
                                            "log10_mse_ratio": float(log_ratio)})
            log_ratios[ci, oi] = float(np.mean(paired))
    limit = max(0.15, float(np.max(np.abs(log_ratios))))
    pd.DataFrame(log_ratios, index=CONDITIONS, columns=OUTPUTS).rename_axis("condition").reset_index().to_csv(
        TABLE_OUT / "Fig19c_recursive_lead10_log10_mse_ratio.csv", index=False)
    pd.DataFrame(ratio_instance_rows).to_csv(
        TABLE_OUT / "Fig19c_recursive_lead10_ratio_by_instance.csv", index=False)
    image = axes[1, 0].imshow(log_ratios, cmap="RdBu_r", norm=TwoSlopeNorm(vmin=-limit, vcenter=0, vmax=limit),
                              aspect="auto", interpolation="nearest")
    axes[1, 0].set_xticks(np.arange(5), OUTPUT_SHORT)
    axes[1, 0].set_yticks(np.arange(3), tuple(CONDITION_LABELS[c] for c in CONDITIONS))
    for ci in range(3):
        for oi in range(5):
            ratio = 10 ** log_ratios[ci, oi]
            axes[1, 0].text(oi, ci, f"{ratio:.2f}x", ha="center", va="center", fontsize=7.0,
                            color="white" if abs(log_ratios[ci, oi]) > 0.55 * limit else "#202020")
    colorbar = fig.colorbar(image, ax=axes[1, 0], fraction=0.046, pad=0.035)
    colorbar.set_label(r"$\log_{10}\rho_{\mathrm{S/V}}$", fontsize=7.5)
    colorbar.ax.tick_params(labelsize=7)

    # (d) Actual footprint of the two saved shared-trunk implementations.
    resource_rows = complexity.loc[["joint_vector_head", "separate_scalar_heads"]]
    resource_values = np.column_stack((resource_rows.parameters.to_numpy(float),
                                       resource_rows.checkpoint_bytes.to_numpy(float),
                                       resource_rows.latency_mean_ms.to_numpy(float)))
    relative = resource_values / resource_values[0]
    pd.DataFrame(resource_values, index=("joint_vector_head", "separate_scalar_heads"),
                 columns=("parameters", "checkpoint_bytes", "latency_mean_ms")).rename_axis(
                     "head_organization").reset_index().to_csv(TABLE_OUT / "Fig19d_resource_metrics.csv", index=False)
    rx = np.arange(3)
    axes[1, 1].bar(rx - 0.16, relative[0], 0.31, color=mode_colors["mimo"], alpha=0.84,
                   label=mode_labels["mimo"])
    axes[1, 1].bar(rx + 0.16, relative[1], 0.31, color=mode_colors["miso"], alpha=0.84,
                   label=mode_labels["miso"])
    axes[1, 1].axhline(1.0, color="#666666", lw=0.65, ls=":", zorder=1)
    axes[1, 1].set_xticks(rx, ("Parameters", "Checkpoint", "Latency"))
    axes[1, 1].set_ylabel("Relative to joint vector head")
    axes[1, 1].set_ylim(0, max(1.16, float(relative.max()) * 1.10))
    fig.legend(
        handles=[Line2D([0], [0], color=mode_colors[mode], lw=5.0, label=mode_labels[mode])
                 for mode in ("mimo", "miso")],
        loc="upper center", ncol=2, bbox_to_anchor=(0.5, 0.995),
        fontsize=8.0, frameon=False, columnspacing=1.5,
    )

    style_axes(axes)
    for i, axis in enumerate(axes.ravel()):
        panel_label(axis, i, y=-0.18 if i < 2 else -0.20)
    fig.subplots_adjust(left=0.09, right=0.98, bottom=0.09, top=0.91, wspace=0.45, hspace=0.34)
    save(fig, 19, "mimo_miso_tradeoff", sources,
         "Controlled output-head study: shared trunk with a joint vector head versus separate scalar heads; "
         "five paired independent runs, complete test set, and H=10 lead-10 recursion. This is not five independent MISO deployments.")


def plot_noise_robustness() -> None:
    require_all_external_models(MODELS, 20)
    auxiliary = FINAL / "06_five_model_auxiliary"
    records, sources = [], []
    for model in MODELS:
        for seed in SEEDS:
            path = auxiliary / f"{model}_seed{seed}" / "noise_metrics_by_condition.csv"
            sources.append(path)
            frame = pd.read_csv(path)
            for condition in CONDITIONS:
                condition_frame = frame[frame.condition == condition]
                clean = condition_frame[condition_frame.noise_level == 0].set_index("output").loc[list(OUTPUTS)].RMSE.to_numpy()
                for level, group in condition_frame.groupby("noise_level"):
                    noisy = group.set_index("output").loc[list(OUTPUTS)].RMSE.to_numpy()
                    records.append({"model": model, "seed": seed, "condition": condition, "noise": level,
                                    "relative_rmse": float(np.mean(noisy / clean))})
    data = pd.DataFrame(records)
    summary = data.groupby(["model", "condition", "noise"]).relative_rmse.agg(["mean", "std"]).reset_index()
    fig, axes = plt.subplots(1, 3, figsize=(7.2, 2.85), sharey=True)
    for ci, (condition, axis) in enumerate(zip(CONDITIONS, axes)):
        for model in MODELS:
            part = summary[(summary.condition == condition) & (summary.model == model)].sort_values("noise")
            x = part.noise.to_numpy() * 100
            axis.plot(x, part["mean"], marker="o", ms=3.5, color=COLORS[model], ls=LINESTYLES[model], label=LABELS[model])
            axis.fill_between(x, part["mean"] - part["std"], part["mean"] + part["std"], color=COLORS[model], alpha=0.14)
        axis.set_title(CONDITION_LABELS[condition], fontweight="normal")
        axis.set_xlabel("Input noise (% range)")
        panel_label(axis, ci, y=-0.31)
    axes[0].set_ylabel("RMSE ratio to clean input")
    style_axes(axes)
    fig.legend(handles=model_legend(False), loc="upper center", ncol=5, bbox_to_anchor=(0.5, 1.01), fontsize=8.2)
    fig.subplots_adjust(left=0.09, right=0.99, bottom=0.22, top=0.82, wspace=0.18)
    save(fig, 20, "noise_robustness", sources, "Five-seed mean +/- sample standard deviation; normalized before output averaging.")


def plot_second_unit(number: int, condition: str) -> None:
    require_all_external_models(MODELS, number)
    auxiliary = FINAL / "06_five_model_auxiliary"
    paths = {(model, seed): auxiliary / f"{model}_seed{seed}" / "second_unit_predictions.npz"
             for model in MODELS for seed in SEEDS}
    arrays = {key: np.load(path) for key, path in paths.items()}
    ref = arrays[("pinn", 2027)]
    mask = ref["condition"] == condition
    fig, axes = plt.subplots(5, 1, figsize=SINGLE_TRAJECTORY_SIZE, sharex=True)
    x = np.arange(int(mask.sum()))
    for oi, axis in enumerate(axes):
        predictions, bands = {}, {}
        for model in MODELS:
            seed_predictions = []
            for seed in SEEDS:
                data = arrays[(model, seed)]
                model_mask = data["condition"] == condition
                seed_predictions.append(data["prediction"][model_mask, oi])
            matrix = np.vstack(seed_predictions)
            mean, std = matrix.mean(axis=0), matrix.std(axis=0, ddof=1)
            predictions[model] = mean
            bands[model] = (mean - std, mean + std)
        plot_trajectory_axis(axis, x, ref["target"][mask, oi], predictions, bands)
        axis.set_ylabel(OUTPUT_LABELS[oi])
        if oi < 4: axis.tick_params(labelbottom=False)
    axes[-1].set_xlabel("Time (s)")
    style_axes(axes)
    fig.legend(handles=model_legend(), loc="upper center", ncol=3, bbox_to_anchor=(0.5, 0.998),
               fontsize=6.9, handlelength=2.4, columnspacing=0.85, handletextpad=0.35)
    fig.subplots_adjust(left=0.205, right=0.985, bottom=0.078, top=0.905, hspace=0.13)
    stem = "load_increase" if condition == "load_increase" else "load_decrease"
    save(fig, number, f"second_unit_{stem}", list(paths.values()),
         "Five-seed mean and sample-standard-deviation bands; zero-shot transfer with source-unit scaler; no fine-tuning.")


def main() -> None:
    apply_paper_style()
    # Force both text and math labels to the manuscript's Times family.
    plt.rcParams.update({
        "font.family": "Times New Roman",
        "font.serif": ["Times New Roman"],
        "mathtext.fontset": "custom",
        "mathtext.rm": "Times New Roman",
        "mathtext.it": "Times New Roman:italic",
        "mathtext.bf": "Times New Roman:bold",
    })
    plt.rcParams.update({"figure.dpi": 150, "pdf.fonttype": 42, "ps.fonttype": 42,
                         "axes.titleweight": "bold", "axes.titlepad": 5.0})
    plot_validation_sensitivity()
    plot_kan_interpretability()
    plot_one_step_trajectory(8, "startup")
    plot_one_step_trajectory(9, "load_change")
    plot_one_step_trajectory(10, "shutdown")
    plot_error_boxplots()
    plot_radar()
    plot_recursive_summary()
    plot_recursive_trajectory(14, "startup")
    plot_recursive_trajectory(15, "load_change")
    plot_recursive_trajectory(16, "shutdown")
    plot_component_ablation()
    plot_kendall_weighting()
    plot_mimo_miso()
    plot_noise_robustness()
    plot_second_unit(21, "load_increase")
    plot_second_unit(22, "load_decrease")
    manifest = RESULTS / "replot_20260831" / "final_simulation_figure_manifest.json"
    manifest.write_text(json.dumps({"status": "complete", "figures": MANIFEST}, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"Generated {len(MANIFEST)} final figure groups in {OUT}")


if __name__ == "__main__":
    main()
