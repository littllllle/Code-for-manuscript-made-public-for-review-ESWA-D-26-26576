import argparse
import csv
import json
from pathlib import Path

# Load PyTorch before NumPy/Matplotlib in the legacy PINN-KAN environment so
# the process uses one consistent OpenMP runtime.
import torch
import numpy as np

from revision_explicit_pinn.data import build_preshifted_datasets
from revision_explicit_pinn.evaluation import metric_table, one_step_predictions_with_metadata, rollout_predictions
from revision_explicit_pinn.models import BaselineConfig, BaselinePredictor, ExplicitPhysicsPINN, ModelConfig
from revision_explicit_pinn.training import TrainConfig, Trainer, set_seed


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", default="data/999")
    parser.add_argument("--output-dir", default="outputs/pilot")
    parser.add_argument("--window", type=int, default=2)
    parser.add_argument("--batch-size", type=int, default=16)
    parser.add_argument("--epochs", type=int, default=100)
    parser.add_argument("--patience", type=int, default=15)
    parser.add_argument("--learning-rate", type=float, default=1e-4)
    parser.add_argument("--weighting", choices=("equal", "static", "kendall"), default="kendall")
    parser.add_argument("--seed", type=int, default=2026)
    parser.add_argument("--d-model", type=int, default=64)
    parser.add_argument("--layers", type=int, default=2)
    parser.add_argument("--decoder-layers", type=int, default=2)
    parser.add_argument("--nhead", type=int, default=4)
    parser.add_argument("--feedforward", type=int, default=128)
    parser.add_argument("--head-factorization", choices=("joint_vector", "separate_scalar"), default="joint_vector")
    parser.add_argument("--max-eval-samples", type=int, default=3000)
    parser.add_argument("--rollout", action="store_true")
    parser.add_argument("--selection-only", action="store_true")
    parser.add_argument("--model-type", choices=("transformer", "mlp", "gru", "lstm", "tcn", "kan"), default="transformer")
    parser.add_argument("--closure", choices=("kan", "fixed"), default="kan")
    parser.add_argument("--no-physics", action="store_true")
    parser.add_argument("--static-mass-weight", type=float, default=1.0)
    parser.add_argument("--static-energy-weight", type=float, default=1.0)
    parser.add_argument("--device", choices=("auto", "cpu", "cuda"), default="auto")
    return parser.parse_args()


def main():
    args = parse_args()
    print("[stage] arguments parsed", flush=True)
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    print("[stage] output directory ready", flush=True)
    bundle = build_preshifted_datasets(args.data_dir, window=args.window, include_test=not args.selection_only)
    print("[stage] datasets built", flush=True)
    if bundle.train.audit() or bundle.validation.audit() or (bundle.test is not None and bundle.test.audit()):
        raise RuntimeError("Causal-window audit failed")
    set_seed(args.seed)
    if args.model_type == "transformer":
        model = ExplicitPhysicsPINN(
            ModelConfig(
                d_model=args.d_model,
                nhead=args.nhead,
                encoder_layers=args.layers,
                decoder_layers=args.decoder_layers,
                feedforward_dim=args.feedforward,
                max_window=max(30, args.window),
                closure=args.closure,
                head_factorization=args.head_factorization,
            )
        )
    else:
        model = BaselinePredictor(
            BaselineConfig(
                model_type=args.model_type,
                hidden_dim=args.d_model,
                layers=args.layers,
                max_window=max(30, args.window),
            )
        )
    requested_device = None if args.device == "auto" else args.device
    trainer = Trainer(
        model,
        bundle,
        output_dir,
        TrainConfig(
            epochs=args.epochs,
            batch_size=args.batch_size,
            learning_rate=args.learning_rate,
            patience=args.patience,
            weighting=args.weighting,
            seed=args.seed,
            use_physics=not args.no_physics,
            static_mass_weight=args.static_mass_weight,
            static_energy_weight=args.static_energy_weight,
        ),
        device=requested_device,
    )
    print("[stage] trainer initialized on {}".format(trainer.device), flush=True)
    checkpoint = trainer.fit()
    print("[stage] training complete", flush=True)
    if args.selection_only:
        summary = {
            "best_epoch": checkpoint["epoch"],
            "best_validation_data_loss": checkpoint["validation_data_loss"],
            "train_samples": len(bundle.train),
            "validation_samples": len(bundle.validation),
            "test_evaluated": False,
            "window_audit_violations": 0,
            "device": str(trainer.device),
        }
        with (output_dir / "summary.json").open("w", encoding="utf-8") as handle:
            json.dump(summary, handle, indent=2)
        print(json.dumps(summary, indent=2))
        return
    target_norm, prediction_norm, source_ids, condition_ids = one_step_predictions_with_metadata(
        model, bundle.test, trainer.device, batch_size=max(args.batch_size, 128)
    )
    print("[stage] test prediction complete", flush=True)
    target = target_norm * bundle.scaler.scale[2:] + bundle.scaler.minimum[2:]
    prediction = prediction_norm * bundle.scaler.scale[2:] + bundle.scaler.minimum[2:]
    rows = metric_table(target, prediction)
    with (output_dir / "test_metrics.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    # Final evaluation always stores the complete test set.  max_eval_samples is
    # retained only for backwards-compatible CLI parsing and is never applied to
    # final evidence outputs.
    np.savez_compressed(
        str(output_dir / "test_predictions.npz"),
        target=target,
        prediction=prediction,
        source=source_ids,
        condition=condition_ids,
    )
    with (output_dir / "test_predictions.csv").open("w", newline="", encoding="utf-8") as handle:
        fieldnames = ["sample_index", "source", "condition", "output_index", "target", "prediction", "error"]
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        sample_count, output_count = target.shape
        for sample_index in range(sample_count):
            for output_index in range(output_count):
                value = float(target[sample_index, output_index])
                estimate = float(prediction[sample_index, output_index])
                writer.writerow({
                    "sample_index": sample_index,
                    "source": source_ids[sample_index],
                    "condition": condition_ids[sample_index],
                    "output_index": output_index,
                    "target": value,
                    "prediction": estimate,
                    "error": estimate - value,
                })
    if args.rollout:
        rollout_target_norm, rollout_prediction_norm, source_ids, condition_ids = rollout_predictions(
            model, bundle.segments["test"], bundle.scaler, args.window, trainer.device
        )
        rollout_target = rollout_target_norm * bundle.scaler.scale[2:] + bundle.scaler.minimum[2:]
        rollout_prediction = rollout_prediction_norm * bundle.scaler.scale[2:] + bundle.scaler.minimum[2:]
        rollout_rows = metric_table(rollout_target, rollout_prediction)
        with (output_dir / "rollout_metrics.csv").open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=list(rollout_rows[0]))
            writer.writeheader()
            writer.writerows(rollout_rows)
        np.savez_compressed(
            str(output_dir / "rollout_predictions.npz"),
            target=rollout_target,
            prediction=rollout_prediction,
            source=source_ids,
            condition=condition_ids,
        )
    summary = {
        "best_epoch": checkpoint["epoch"],
        "best_validation_data_loss": checkpoint["validation_data_loss"],
        "train_samples": len(bundle.train),
        "validation_samples": len(bundle.validation),
        "test_samples": len(bundle.test),
        "window_audit_violations": 0,
        "device": str(trainer.device),
    }
    with (output_dir / "summary.json").open("w", encoding="utf-8") as handle:
        json.dump(summary, handle, indent=2)
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
