"""Data pipeline for CSV rows already stored as [u(k), y(k-1)]."""

from pathlib import Path

import numpy as np
import torch
from torch.utils.data import Dataset

from .pipeline import (
    DatasetBundle,
    MinMaxScaler,
    chronological_train_validation_segments,
    complete_test_segments,
)


class PreShiftedWindowedGasTurbineDataset(Dataset):
    """Use pre-shifted CSV rows directly and predict the next stored output."""

    def __init__(self, segments, scaler, window):
        if int(window) < 1:
            raise ValueError("window must be positive")
        self.window = int(window)
        self.scaler = scaler
        self.samples = []
        for segment in segments:
            normalized = scaler.transform(segment.values).astype(np.float32)
            for end_local in range(self.window - 1, len(normalized) - 1):
                token_rows = np.arange(end_local - self.window + 1, end_local + 1)
                target_storage_row = end_local + 1
                features = normalized[token_rows]
                target = normalized[target_storage_row, 2:]
                metadata = {
                    "source": segment.source,
                    "condition": segment.condition,
                    "split": segment.split,
                    "semantic_target_row": segment.start + end_local,
                    "target_storage_row": segment.start + target_storage_row,
                    "token_rows": (segment.start + token_rows).tolist(),
                }
                self.samples.append((features, target, metadata))

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, index):
        features, target, metadata = self.samples[index]
        return torch.from_numpy(features), torch.from_numpy(target), metadata

    def audit(self):
        violations = []
        for _, _, metadata in self.samples:
            tokens = metadata["token_rows"]
            semantic_target = metadata["semantic_target_row"]
            target_storage = metadata["target_storage_row"]
            if tokens[-1] != semantic_target:
                violations.append((metadata, "window must end at semantic target row k"))
            if target_storage != semantic_target + 1:
                violations.append((metadata, "y(k) must be read from storage row k+1"))
            if target_storage in tokens:
                violations.append((metadata, "target storage row appears in input window"))
        return violations


def build_preshifted_datasets(data_dir, window, validation_fraction=0.2, purge=None, include_test=True):
    data_dir = Path(data_dir)
    train_paths = sorted(data_dir.glob("data_train*.csv"))
    test_paths = sorted(data_dir.glob("data_test*.csv"))
    if not train_paths or (include_test and not test_paths):
        raise FileNotFoundError("Expected required train/test CSV files in {}".format(data_dir))
    purge = max(int(window), 1) if purge is None else int(purge)
    train_segments, validation_segments = chronological_train_validation_segments(
        train_paths, validation_fraction=validation_fraction, purge=purge
    )
    test_segments = complete_test_segments(test_paths) if include_test else []
    scaler = MinMaxScaler().fit(segment.values for segment in train_segments)
    return DatasetBundle(
        train=PreShiftedWindowedGasTurbineDataset(train_segments, scaler, window),
        validation=PreShiftedWindowedGasTurbineDataset(validation_segments, scaler, window),
        test=PreShiftedWindowedGasTurbineDataset(test_segments, scaler, window) if include_test else None,
        scaler=scaler,
        segments={"train": train_segments, "validation": validation_segments, "test": test_segments},
    )
