import unittest

import torch

from revision_explicit_pinn.models import UnifiedHybridPINN, UnifiedModelConfig


class UnifiedOutputHeadTest(unittest.TestCase):
    def test_encoder_decoder_contract_and_output_shapes(self):
        models = []
        for mode in ("mimo", "miso"):
            model = UnifiedHybridPINN(
                UnifiedModelConfig(
                    d_model=16,
                    nhead=2,
                    encoder_layers=1,
                    decoder_layers=1,
                    feedforward_dim=32,
                    max_window=8,
                    head_mode=mode,
                )
            )
            result = model(torch.randn(3, 8, 7))
            self.assertIsInstance(model.encoder, torch.nn.TransformerEncoder)
            self.assertIsInstance(model.decoder, torch.nn.TransformerDecoder)
            self.assertEqual(result["prediction"].shape, (3, 5))
            self.assertEqual(result["latent_delta"].shape, (3, 2))
            models.append(model)

        shared_mimo = {name: value.shape for name, value in models[0].state_dict().items()
                       if "observation_heads" not in name}
        shared_miso = {name: value.shape for name, value in models[1].state_dict().items()
                       if "observation_heads" not in name}
        self.assertEqual(shared_mimo, shared_miso)


if __name__ == "__main__":
    unittest.main()
