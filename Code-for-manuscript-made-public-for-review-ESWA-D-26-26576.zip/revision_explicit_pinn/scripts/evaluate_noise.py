import argparse
import csv
import json
from pathlib import Path

import numpy as np
import torch

from revision_explicit_pinn.data import build_datasets
from revision_explicit_pinn.evaluation import grouped_metric_table
from revision_explicit_pinn.evaluation.noise import add_training_scale_gaussian_noise
from revision_explicit_pinn.models import BaselineConfig, BaselinePredictor, ExplicitPhysicsPINN, ModelConfig


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-dir", required=True)
    parser.add_argument("--data-dir", default="data/999")
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--levels", default="0.01,0.03,0.05,0.10")
    args = parser.parse_args()
    run_dir = Path(args.run_dir)
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    with (run_dir / "run_config.json").open("r", encoding="utf-8") as handle:
        config = json.load(handle)
    window = config["data"]["window"]
    bundle = build_datasets(args.data_dir, window, include_test=True)
    if "model_type" in config["model"]:
        model = BaselinePredictor(BaselineConfig(**config["model"]))
    else:
        model = ExplicitPhysicsPINN(ModelConfig(**config["model"]))
    checkpoint = torch.load(str(run_dir / "best.pt"), map_location="cpu")
    model.load_state_dict(checkpoint["model"])
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model.to(device).eval()
    levels = [float(value) for value in args.levels.split(",")]
    rows = []
    for level in levels:
        targets = np.asarray([sample[1] for sample in bundle.test.samples])
        groups = [sample[2]["condition"] for sample in bundle.test.samples]
        noisy = np.stack([add_training_scale_gaussian_noise(sample[0], level, seed=202600 + i)
                          for i, sample in enumerate(bundle.test.samples)])
        predictions = []
        # Batch inference keeps the noise protocol unchanged while making the full
        # 8,371-window audit practical on CPU and GPU.
        for start in range(0, len(noisy), 256):
            batch = torch.tensor(noisy[start:start + 256], dtype=torch.float32, device=device)
            with torch.no_grad():
                predictions.append(model(batch)["prediction"].cpu().numpy())
        predictions = np.concatenate(predictions, axis=0)
        target = np.asarray(targets) * bundle.scaler.scale[2:] + bundle.scaler.minimum[2:]
        prediction = np.asarray(predictions) * bundle.scaler.scale[2:] + bundle.scaler.minimum[2:]
        for row in grouped_metric_table(target, prediction, groups):
            row["noise_level"] = level
            rows.append(row)
    fields = list(rows[0])
    with (output_dir / "noise_metrics_by_condition.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)
    print(str(output_dir))


if __name__ == "__main__":
    main()
