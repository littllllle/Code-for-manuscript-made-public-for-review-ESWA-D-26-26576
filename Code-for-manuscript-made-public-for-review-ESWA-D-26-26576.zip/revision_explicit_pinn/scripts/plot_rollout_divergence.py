"""Visualize free-running fit, pointwise error, and accumulated divergence."""
import argparse
import csv
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from revision_explicit_pinn.data.schema import OUTPUT_NAMES, UNITS
from revision_explicit_pinn.plotting.paper_style import apply_paper_style, save_figure


MODELS = {
    "pinn": ("Proposed PINN-KAN", "#d62728"),
    "transformer": ("Data-only Transformer", "#1f77b4"),
}
CONDITIONS = ["startup", "load_change", "shutdown"]
CONDITION_LABELS = {
    "startup": "Test 1: Startup",
    "load_change": "Test 2: Load change",
    "shutdown": "Test 3: Shutdown",
}


def cumulative_rmse(error):
    count = np.arange(1, len(error) + 1, dtype=float)
    return np.sqrt(np.cumsum(error ** 2) / count)


def finite_positive(values):
    values = np.asarray(values)
    return np.maximum(values, np.finfo(float).tiny)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--pinn", required=True)
    parser.add_argument("--transformer", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)

    loaded = {}
    for key, path in (("pinn", args.pinn), ("transformer", args.transformer)):
        data = np.load(path, allow_pickle=True)
        loaded[key] = {
            "target": data["target"],
            "prediction": data["prediction"],
            "condition": np.asarray(data["condition"]).astype(str),
        }

    apply_paper_style(font_size=8)
    rows = []
    for condition in CONDITIONS:
        reference = loaded["pinn"]
        ref_mask = reference["condition"] == condition
        if not ref_mask.any():
            continue
        target = reference["target"][ref_mask]
        steps = np.arange(len(target))
        fig, axes = plt.subplots(
            len(OUTPUT_NAMES), 3, figsize=(14.0, 11.0), sharex="col",
            constrained_layout=True,
        )
        for output_index, name in enumerate(OUTPUT_NAMES):
            ax_fit, ax_error, ax_cumulative = axes[output_index]
            truth = target[:, output_index]
            ax_fit.plot(steps, truth, color="#444444", linestyle="--", linewidth=1.1,
                        label="Measured" if output_index == 0 else None, zorder=4)

            target_span = float(np.ptp(truth))
            margin = max(target_span * 0.12, max(abs(float(np.mean(truth))) * 0.01, 1e-6))
            ax_fit.set_ylim(float(np.min(truth)) - margin, float(np.max(truth)) + margin)

            for key, (label, color) in MODELS.items():
                data = loaded[key]
                mask = data["condition"] == condition
                prediction = data["prediction"][mask, output_index]
                error = prediction - truth
                absolute_error = np.abs(error)
                accumulated = cumulative_rmse(error)
                ax_fit.plot(steps, prediction, color=color, linewidth=0.8,
                            label=label if output_index == 0 else None, alpha=0.9)
                ax_error.plot(steps, finite_positive(absolute_error), color=color, linewidth=0.8,
                              label=label if output_index == 0 else None)
                ax_cumulative.plot(steps, finite_positive(accumulated), color=color, linewidth=0.9,
                                   label=label if output_index == 0 else None)
                first_exceed = np.flatnonzero(absolute_error > max(target_span, 1e-9))
                rows.append({
                    "test_set": condition,
                    "model": label,
                    "output": name,
                    "samples": len(truth),
                    "final_cumulative_RMSE": float(accumulated[-1]),
                    "maximum_absolute_error": float(np.max(absolute_error)),
                    "first_error_exceeding_target_range": int(first_exceed[0]) if len(first_exceed) else "",
                    "prediction_min": float(np.min(prediction)),
                    "prediction_max": float(np.max(prediction)),
                })

            ax_fit.set_ylabel("{}\n({})".format(name, UNITS[name]))
            ax_error.set_yscale("log")
            ax_cumulative.set_yscale("log")
            for axis in (ax_fit, ax_error, ax_cumulative):
                axis.grid(alpha=0.22, linewidth=0.6)
                axis.tick_params(direction="in")

        axes[0, 0].set_title("Free-running fit (measured range)")
        axes[0, 1].set_title("Absolute error (log scale)")
        axes[0, 2].set_title("Cumulative RMSE (log scale)")
        axes[0, 0].legend(loc="best", ncol=1, frameon=False)
        axes[0, 1].legend(loc="best", ncol=1, frameon=False)
        axes[-1, 0].set_xlabel("Recursive prediction step")
        axes[-1, 1].set_xlabel("Recursive prediction step")
        axes[-1, 2].set_xlabel("Recursive prediction step")
        fig.suptitle("{} - free-running recursive prediction".format(CONDITION_LABELS[condition]), fontsize=12)
        save_figure(fig, output / "{}_rollout_fit_error_divergence.png".format(condition))

    fields = list(rows[0])
    with (output / "rollout_divergence_summary.csv").open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)
    with (output / "README.md").open("w", encoding="utf-8") as handle:
        handle.write("# Free-running comparison\n\n")
        handle.write("Left: predictions within the measured operating range; values outside the axis remain unmodified but leave the visible range.\n\n")
        handle.write("Middle: pointwise absolute error on a logarithmic scale. Right: cumulative RMSE through each recursive step.\n\n")
        handle.write("All errors use the raw, unclipped predictions.\n")
    print("Generated {} rollout figures in {}".format(len(CONDITIONS), output))


if __name__ == "__main__":
    main()
