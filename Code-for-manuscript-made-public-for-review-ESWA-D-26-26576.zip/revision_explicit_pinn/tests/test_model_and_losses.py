import unittest
import inspect

import numpy as np
import torch

from revision_explicit_pinn.losses import KendallTaskWeighting, PhysicsLoss
from revision_explicit_pinn.models import BaselineConfig, BaselinePredictor, ExplicitPhysicsPINN, ModelConfig


class ModelAndLossTest(unittest.TestCase):
    def setUp(self):
        torch.manual_seed(7)
        self.model = ExplicitPhysicsPINN(
            ModelConfig(
                d_model=16, nhead=2, encoder_layers=1, decoder_layers=1,
                feedforward_dim=24, dropout=0.0,
            )
        )
        self.minimum = np.array([1.0, 20.0, 0.0, 2990.0, 0.0, 60.0, 0.0])
        self.scale = np.array([15.0, 65.0, 16.5, 25.0, 300.0, 600.0, 100.0])

    def test_forward_shapes_and_bounded_flows(self):
        features = torch.rand(4, 2, 7)
        output = self.model(features)
        self.assertEqual(tuple(output["prediction"].shape), (4, 5))
        self.assertEqual(tuple(output["flows"].shape), (4, 2))
        self.assertEqual(tuple(output["previous_flows"].shape), (4, 2))
        self.assertTrue(torch.all(output["flows"][:, 0] > 0))
        self.assertTrue(torch.all(output["flows"][:, 0] < self.model.flow_closure.maximum_flow))
        self.assertTrue(torch.all(output["flows"][:, 1].abs() <= 621.58 * 0.02))

    def test_complete_encoder_decoder_is_causal_and_target_free(self):
        self.assertIsInstance(self.model.encoder, torch.nn.TransformerEncoder)
        self.assertIsInstance(self.model.decoder, torch.nn.TransformerDecoder)
        self.assertEqual(list(inspect.signature(self.model.forward).parameters), ["features"])
        mask = self.model.decoder_causal_mask[:4, :4]
        self.assertTrue(torch.all(mask.diagonal() == 0.0))
        self.assertTrue(torch.all(torch.isneginf(mask.triu(diagonal=1)[mask.triu(diagonal=1) != 0])))
        self.assertTrue(torch.all(mask.tril() == 0.0))

    def test_transformer_and_pinn_share_encoder_decoder_backbone(self):
        transformer = ExplicitPhysicsPINN(
            ModelConfig(
                d_model=16, nhead=2, encoder_layers=1, decoder_layers=1,
                feedforward_dim=24, dropout=0.0, closure="fixed",
            )
        )
        pinn_parameter_names = {
            name for name, _ in self.model.named_parameters() if not name.startswith("flow_closure.")
        }
        transformer_parameter_names = {
            name for name, _ in transformer.named_parameters() if not name.startswith("flow_closure.")
        }
        self.assertEqual(pinn_parameter_names, transformer_parameter_names)
        self.assertEqual(self.model.config.architecture, "transformer_encoder_decoder")
        self.assertEqual(transformer.config.architecture, "transformer_encoder_decoder")

    def test_physics_and_kendall_share_gradient_graph(self):
        features = torch.rand(4, 2, 7)
        target = torch.rand(4, 5)
        output = self.model(features)
        physics = PhysicsLoss(self.minimum, self.scale)(
            features, output["prediction"], output["flows"], output["previous_flows"]
        )
        data_loss = torch.mean((output["prediction"] - target) ** 2)
        weighting = KendallTaskWeighting()
        total, weights = weighting(data_loss, physics["mass_loss"], physics["energy_loss"])
        total.backward()
        self.assertTrue(torch.isfinite(total))
        self.assertEqual(set(weights), {"data", "mass", "energy"})
        self.assertIsNotNone(self.model.output_head[-1].weight.grad)
        self.assertIsNotNone(self.model.flow_closure.second.base_weight.grad)
        self.assertIsNotNone(weighting.log_variances.grad)

    def test_observation_units_convert_to_absolute_si(self):
        physics = PhysicsLoss(self.minimum, self.scale)
        outputs = torch.tensor([[15.4, 3000.0, 250.0, 600.0, 30.0]])
        state = physics.observation_to_combustor_state(outputs)
        expected_pressure = 0.98 * (15.4 * 98066.5 + 101350.0)
        self.assertAlmostEqual(float(state[0, 0]), expected_pressure, delta=1.0)
        self.assertGreater(float(state[0, 1]), 600.0 + 273.15)

    def test_all_baselines_follow_shared_output_contract(self):
        features = torch.rand(3, 4, 7)
        for model_type in ("mlp", "gru", "lstm", "tcn", "kan"):
            model = BaselinePredictor(
                BaselineConfig(model_type=model_type, hidden_dim=16, layers=1, dropout=0.0)
            )
            output = model(features)
            self.assertEqual(tuple(output["prediction"].shape), (3, 5))
            self.assertEqual(tuple(output["flows"].shape), (3, 2))

    def test_fixed_closure_transformer(self):
        model = ExplicitPhysicsPINN(
            ModelConfig(d_model=16, nhead=2, encoder_layers=1, feedforward_dim=24, closure="fixed")
        )
        output = model(torch.rand(2, 2, 7))
        self.assertTrue(torch.allclose(output["flows"][:, 0], torch.full((2,), 621.58)))
        self.assertTrue(torch.allclose(output["flows"][:, 1], torch.zeros(2)))


if __name__ == "__main__":
    unittest.main()
