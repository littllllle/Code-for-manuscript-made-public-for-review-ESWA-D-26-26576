"""Validation-only context and batch selection for all final comparison models.

The held-out test trajectories are never loaded.  Each architecture is trained
with the final encoder--decoder implementation (for Transformer and TK-PINN)
or the final baseline implementation, using the same validation criterion and
training budget.  Completed runs are resumable and every candidate is recorded
in a CSV manifest for the manuscript audit.
"""

import argparse
import csv
import gc
import json
import time
from pathlib import Path

import torch

from revision_explicit_pinn.data import build_preshifted_datasets
from revision_explicit_pinn.models import BaselineConfig, BaselinePredictor, ExplicitPhysicsPINN, ModelConfig
from revision_explicit_pinn.training import TrainConfig, Trainer, set_seed


MODELS = ("lstm", "tcn", "kan", "transformer", "tk_pinn")
WINDOWS = (2, 4, 8, 16, 30)
BATCH_SIZES = (32,)


def build_model(model_name, window, d_model, layers, feedforward, nhead):
    if model_name in ("transformer", "tk_pinn"):
        return ExplicitPhysicsPINN(ModelConfig(
            d_model=d_model,
            nhead=nhead,
            encoder_layers=layers,
            decoder_layers=layers,
            feedforward_dim=feedforward,
            max_window=max(WINDOWS),
            closure="kan" if model_name == "tk_pinn" else "fixed",
        ))
    return BaselinePredictor(BaselineConfig(
        model_type=model_name,
        hidden_dim=d_model,
        layers=layers,
        max_window=max(WINDOWS),
    ))


def write_rows(path, rows):
    fields = [
        "model", "window", "batch_size", "seed", "status", "best_epoch",
        "validation_data_loss", "validation_mass", "validation_energy",
        "elapsed_seconds", "test_loaded", "error",
    ]
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows({field: row.get(field, "") for field in fields} for row in rows)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", required=True)
    parser.add_argument("--output-root", required=True)
    parser.add_argument("--epochs", type=int, default=10)
    parser.add_argument("--patience", type=int, default=10)
    parser.add_argument("--seed", type=int, default=2026)
    parser.add_argument("--d-model", type=int, default=64)
    parser.add_argument("--layers", type=int, default=2)
    parser.add_argument("--nhead", type=int, default=4)
    parser.add_argument("--feedforward", type=int, default=128)
    parser.add_argument("--learning-rate", type=float, default=1e-4)
    parser.add_argument("--device", choices=("auto", "cpu", "cuda"), default="auto")
    parser.add_argument("--models", nargs="+", choices=MODELS, default=list(MODELS))
    args = parser.parse_args()

    root = Path(args.output_root)
    root.mkdir(parents=True, exist_ok=True)
    manifest = {
        "protocol": "final-architecture validation-only context and batch selection",
        "models": args.models,
        "windows": list(WINDOWS),
        "batch_sizes": list(BATCH_SIZES),
        "seed": args.seed,
        "epochs": args.epochs,
        "selection_metric": "validation_data_loss",
        "test_loaded": False,
        "architecture": {
            "d_model": args.d_model,
            "heads": args.nhead,
            "encoder_layers": args.layers,
            "decoder_layers": args.layers,
            "feedforward_dim": args.feedforward,
        },
    }
    (root / "validation_grid_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")

    progress = root / "validation_grid_progress.csv"
    rows = []
    total = len(args.models) * len(WINDOWS) * len(BATCH_SIZES)
    completed = 0
    for model_name in args.models:
        for window in WINDOWS:
            for batch_size in BATCH_SIZES:
                completed += 1
                run_id = f"{model_name}_w{window}_b{batch_size}_s{args.seed}"
                run_dir = root / run_id
                summary_path = run_dir / "validation_summary.json"
                if summary_path.exists():
                    summary = json.loads(summary_path.read_text(encoding="utf-8"))
                    rows.append(summary)
                    print(f"[{completed}/{total}] skipped {run_id}", flush=True)
                    continue

                started = time.time()
                row = {
                    "model": model_name,
                    "window": window,
                    "batch_size": batch_size,
                    "seed": args.seed,
                    "test_loaded": False,
                }
                try:
                    set_seed(args.seed)
                    bundle = build_preshifted_datasets(args.data_dir, window=window, include_test=False)
                    if bundle.test is not None:
                        raise RuntimeError("Validation screen must not load test data")
                    model = build_model(
                        model_name, window, args.d_model, args.layers,
                        args.feedforward, args.nhead,
                    )
                    physics_model = model_name == "tk_pinn"
                    trainer = Trainer(
                        model,
                        bundle,
                        run_dir,
                        TrainConfig(
                            epochs=args.epochs,
                            patience=args.patience,
                            batch_size=batch_size,
                            learning_rate=args.learning_rate,
                            weighting="kendall" if physics_model else "equal",
                            use_physics=physics_model,
                            seed=args.seed,
                        ),
                        device=None if args.device == "auto" else args.device,
                    )
                    checkpoint = trainer.fit()
                    best = next(item for item in trainer.history if item["epoch"] == checkpoint["epoch"])
                    row.update({
                        "status": "completed",
                        "best_epoch": checkpoint["epoch"],
                        "validation_data_loss": best["validation_data"],
                        "validation_mass": best["validation_mass"],
                        "validation_energy": best["validation_energy"],
                        "elapsed_seconds": time.time() - started,
                        "error": "",
                    })
                    run_dir.mkdir(parents=True, exist_ok=True)
                    (run_dir / "validation_summary.json").write_text(
                        json.dumps(row, indent=2), encoding="utf-8"
                    )
                    print(
                        f"[{completed}/{total}] {run_id} "
                        f"val={row['validation_data_loss']:.8g}", flush=True
                    )
                except Exception as exc:
                    row.update({
                        "status": "failed",
                        "best_epoch": "",
                        "validation_data_loss": "",
                        "validation_mass": "",
                        "validation_energy": "",
                        "elapsed_seconds": time.time() - started,
                        "error": f"{type(exc).__name__}: {exc}",
                    })
                    print(f"[{completed}/{total}] FAILED {run_id}: {exc}", flush=True)
                rows.append(row)
                write_rows(progress, rows)
                for name in ("model", "bundle", "trainer"):
                    if name in locals():
                        del locals()[name]
                gc.collect()
                if torch.cuda.is_available():
                    torch.cuda.empty_cache()

    write_rows(progress, rows)
    selections = {}
    for model_name in args.models:
        candidates = [
            row for row in rows
            if row.get("model") == model_name and row.get("status") == "completed"
        ]
        if candidates:
            selections[model_name] = min(candidates, key=lambda row: float(row["validation_data_loss"]))
    (root / "selected_configurations.json").write_text(
        json.dumps({
            "selection_metric": "validation_data_loss",
            "test_loaded": False,
            "selections": selections,
        }, indent=2), encoding="utf-8"
    )
    print(json.dumps(selections, indent=2), flush=True)


if __name__ == "__main__":
    main()
