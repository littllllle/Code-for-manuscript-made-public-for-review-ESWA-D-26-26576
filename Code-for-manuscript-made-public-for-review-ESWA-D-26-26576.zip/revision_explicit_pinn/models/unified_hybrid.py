from dataclasses import dataclass
import torch

from .kan import FlowClosureKAN


@dataclass(frozen=True)
class UnifiedModelConfig:
    input_dim: int = 7
    output_dim: int = 5
    latent_dim: int = 2
    d_model: int = 64
    nhead: int = 4
    encoder_layers: int = 2
    decoder_layers: int = 2
    feedforward_dim: int = 128
    dropout: float = 0.1
    max_window: int = 30
    closure: str = "kan"
    head_mode: str = "mimo"


class UnifiedHybridPINN(torch.nn.Module):
    """Shared causal Transformer encoder-decoder with controlled output heads.

    ``head_mode=mimo`` uses one shared observation head. ``head_mode=miso``
    uses independent scalar heads while retaining the same encoder, decoder,
    and latent-state trunk, so the comparison changes only the output head.
    Physical residuals remain computed by the calibrated PhysicsLoss trainer.
    """

    def __init__(self, config=None):
        super().__init__()
        self.config = config or UnifiedModelConfig()
        cfg = self.config
        if cfg.head_mode not in ("mimo", "miso"):
            raise ValueError("head_mode must be mimo or miso")
        self.input_projection = torch.nn.Linear(cfg.input_dim, cfg.d_model)
        self.decoder_input_projection = torch.nn.Linear(cfg.output_dim, cfg.d_model)
        self.encoder_position = torch.nn.Parameter(torch.zeros(1, cfg.max_window, cfg.d_model))
        self.decoder_position = torch.nn.Parameter(torch.zeros(1, cfg.max_window, cfg.d_model))
        encoder_layer = torch.nn.TransformerEncoderLayer(
            d_model=cfg.d_model, nhead=cfg.nhead,
            dim_feedforward=cfg.feedforward_dim, dropout=cfg.dropout,
            activation="gelu", batch_first=True,
        )
        self.encoder = torch.nn.TransformerEncoder(encoder_layer, num_layers=cfg.encoder_layers)
        decoder_layer = torch.nn.TransformerDecoderLayer(
            d_model=cfg.d_model, nhead=cfg.nhead,
            dim_feedforward=cfg.feedforward_dim, dropout=cfg.dropout,
            activation="gelu", batch_first=True,
        )
        self.decoder = torch.nn.TransformerDecoder(decoder_layer, num_layers=cfg.decoder_layers)
        causal_mask = torch.full((cfg.max_window, cfg.max_window), float("-inf"))
        self.register_buffer(
            "decoder_causal_mask", torch.triu(causal_mask, diagonal=1), persistent=False
        )
        self.norm = torch.nn.LayerNorm(cfg.d_model)
        if cfg.head_mode == "mimo":
            self.observation_heads = torch.nn.ModuleList([torch.nn.Linear(cfg.d_model, cfg.output_dim)])
        else:
            self.observation_heads = torch.nn.ModuleList(
                [torch.nn.Linear(cfg.d_model, 1) for _ in range(cfg.output_dim)]
            )
        self.latent_state_head = torch.nn.Linear(cfg.d_model, cfg.latent_dim)
        self.physics_rhs_head = torch.nn.Linear(cfg.d_model, cfg.latent_dim)
        self.flow_closure = FlowClosureKAN(input_dim=cfg.input_dim) if cfg.closure == "kan" else _FixedClosure()
        torch.nn.init.normal_(self.encoder_position, mean=0.0, std=0.02)
        torch.nn.init.normal_(self.decoder_position, mean=0.0, std=0.02)

    def forward(self, features):
        if features.ndim != 3 or features.shape[-1] != self.config.input_dim:
            raise ValueError("Expected features with shape [batch, window, 7]")
        if features.shape[1] < 1 or features.shape[1] > self.config.max_window:
            raise ValueError("Window outside configured positional capacity")
        sequence_length = features.shape[1]
        encoded = self.input_projection(features) + self.encoder_position[:, :sequence_length]
        memory = self.encoder(encoded)
        # The decoder receives only the pre-shifted lagged-output columns.
        # The prediction target is never passed through this interface.
        decoder_tokens = self.decoder_input_projection(features[..., 2:])
        decoder_tokens = decoder_tokens + self.decoder_position[:, :sequence_length]
        decoded = self.decoder(
            tgt=decoder_tokens,
            memory=memory,
            tgt_mask=self.decoder_causal_mask[:sequence_length, :sequence_length],
        )
        last = self.norm(decoded[:, -1])
        if self.config.head_mode == "mimo":
            delta = self.observation_heads[0](last)
        else:
            delta = torch.cat([head(last) for head in self.observation_heads], dim=-1)
        observed = features[:, -1, 2:] + 0.25 * torch.tanh(delta)
        latent = self.latent_state_head(last)
        rhs = self.physics_rhs_head(last)
        current_flows = self.flow_closure(features[:, -1])
        previous = features[:, -2] if features.shape[1] > 1 else features[:, -1]
        previous_flows = self.flow_closure(previous)
        return {
            "prediction": observed,
            "observed_predictions": observed,
            "latent_states": latent,
            "closures": current_flows,
            "flows": current_flows,
            "previous_flows": previous_flows,
            "physics_rhs": rhs,
            "physics_residuals": latent - rhs,
            "latent_delta": rhs,
        }


class _FixedClosure(torch.nn.Module):
    def forward(self, features):
        return torch.stack([torch.ones_like(features[..., 0]), torch.zeros_like(features[..., 0])], dim=-1)

    def regularization_loss(self):
        return torch.tensor(0.0)
