# PG9351FA physical-parameter evidence register

This register separates confirmed machine/model values from pilot assumptions. A
value marked `pilot assumption` must not be described as a measured PG9351FA
parameter in the manuscript.

| Quantity | Runtime value | Status | Evidence/action |
|---|---:|---|---|
| Sampling period | 1 s | confirmed | ESWA manuscript Section 4 and Lu thesis Section 4.4.1 |
| Effective thermal volume | 20 m3 | calibrated nominal | Lu thesis Table 3-4; not a geometric-volume claim |
| Pressure retention | 0.98 | calibrated nominal | Lu thesis Table 3-4 |
| Combustion efficiency | 0.99 | calibrated nominal | Lu thesis Table 3-4 |
| Rated compressor mass flow | 621.58 kg/s | rated anchor | Lu thesis Table 3-4; only anchors bounded KAN closure |
| Turbine efficiency | 0.90 | rated anchor | Lu thesis Table 3-4 |
| Gas constant | 287 J/(kg K) | pilot assumption | Replace with cited mixture-property basis and sensitivity range |
| Specific heat | 1150 J/(kg K) | pilot assumption | Replace with cited temperature-dependent or justified constant relation |
| Natural-gas LHV | 50 MJ/kg | pilot assumption | Replace with fuel assay or cited range; manual requires sample measurement |
| Heat-capacity ratio | 1.33 | pilot assumption | Replace with cited combustion-gas relation and sensitivity range |
| Exhaust back pressure | 101.35 kPaA | ISO boundary assumption | Manual reference condition; validate against plant measurement definition |
| Recorded compressor pressure | kgf/cm2(g) | confirmed from manuscript figures | Convert with `P_abs=P_gauge*98066.5+101350` before physics |
| Recorded turbine exhaust temperature | degree C | confirmed from manuscript figures | Add 273.15 before thermodynamic equations |
| Energy coefficient k | 1 | SI implementation choice | Manuscript definition is incomplete; retain only if dimensional derivation supports it |
| Rotor inertia | 8700, unit unavailable | blocked | Equation (5) remains excluded until unit and shaft-power terms are confirmed |

The pilot configuration is sufficient for software integration and sensitivity
experiments. It is not yet sufficient to freeze the final strong-PINN claim.
