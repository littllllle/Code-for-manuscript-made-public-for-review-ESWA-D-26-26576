"""Curriculum rollout fine-tuning without changing the deployed architecture."""
import argparse
import csv
import json
import time
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import DataLoader

from revision_explicit_pinn.data import build_datasets
from revision_explicit_pinn.evaluation import grouped_metric_table, one_step_predictions_with_metadata, rollout_predictions
from revision_explicit_pinn.losses import KendallTaskWeighting, PhysicsLoss, StaticTaskWeighting
from revision_explicit_pinn.models import ExplicitPhysicsPINN, ModelConfig
from revision_explicit_pinn.training import set_seed


HORIZON_SCHEDULE = [4, 4, 8, 8, 16, 16, 32, 32, 64, 64]
TEACHER_SCHEDULE = [0.8, 0.8, 0.6, 0.6, 0.4, 0.4, 0.2, 0.2, 0.0, 0.0]


def rollout_batch(model, segment, starts, scaler, window, horizon, device,
                  teacher_probability=0.0, noise_std=0.0, truncate_every=16):
    values = scaler.transform(segment.values).astype(np.float32)
    controls = torch.as_tensor(values[:, :2], device=device)
    true_outputs = torch.as_tensor(values[:, 2:], device=device)
    first_predictions, first_targets = [], []
    predictions, targets, differences, difference_targets, drifts, drift_targets = [], [], [], [], [], []
    physics_records = []
    for start in starts:
        initial = []
        for index in range(start - window, start):
            value = true_outputs[index]
            if noise_std > 0.0:
                value = value + noise_std * torch.randn_like(value)
            initial.append(value)
        history = initial
        sequence_predictions = []
        for step in range(horizon):
            target_time = start + step
            tokens = []
            for token_time in range(target_time - window + 1, target_time + 1):
                previous_time = token_time - 1
                previous = history[previous_time - (start - window)]
                tokens.append(torch.cat([controls[token_time], previous], dim=-1))
            features = torch.stack(tokens).unsqueeze(0)
            output = model(features)
            prediction = output["prediction"].squeeze(0)
            target = true_outputs[target_time]
            if step == 0:
                first_predictions.append(prediction)
                first_targets.append(target)
            predictions.append(prediction)
            targets.append(target)
            sequence_predictions.append(prediction)
            physics_records.append((features, output))
            if step > 0:
                differences.append(prediction - sequence_predictions[-2])
                difference_targets.append(target - true_outputs[target_time - 1])

            use_teacher = teacher_probability > 0.0 and float(torch.rand((), device=device)) < teacher_probability
            if use_teacher:
                feedback = target
                if noise_std > 0.0:
                    feedback = feedback + noise_std * torch.randn_like(feedback)
            else:
                feedback = prediction
                if truncate_every > 0 and (step + 1) % truncate_every == 0:
                    feedback = feedback.detach()
            history.append(feedback)
        drifts.append(sequence_predictions[-1] - sequence_predictions[0])
        drift_targets.append(true_outputs[start + horizon - 1] - true_outputs[start])
    zero = torch.zeros((), device=device)
    return {
        "one_prediction": torch.stack(first_predictions),
        "one_target": torch.stack(first_targets),
        "prediction": torch.stack(predictions),
        "target": torch.stack(targets),
        "difference": torch.stack(differences) if differences else zero.reshape(1),
        "difference_target": torch.stack(difference_targets) if difference_targets else zero.reshape(1),
        "drift": torch.stack(drifts),
        "drift_target": torch.stack(drift_targets),
        "physics_records": physics_records,
    }


def component_losses(batch):
    one = torch.mean((batch["one_prediction"] - batch["one_target"]) ** 2)
    rollout = torch.mean((batch["prediction"] - batch["target"]) ** 2)
    increment = torch.mean((batch["difference"] - batch["difference_target"]) ** 2)
    drift = torch.mean((batch["drift"] - batch["drift_target"]) ** 2)
    data = 0.40 * one + 0.40 * rollout + 0.15 * increment + 0.05 * drift
    prediction = batch["prediction"]
    lower = torch.relu(-0.05 - prediction)
    upper = torch.relu(prediction - 1.05)
    bound = torch.mean(lower ** 2 + upper ** 2)
    return data, one, rollout, increment, drift, bound


def observation_state_consistency(physics, batch):
    """Tie the recursive observable increments to the physical state increment.

    Pressure and exhaust temperature are the two observed variables with a
    direct mapping to the calibrated combustor state.  This term prevents the
    physical branch from becoming an auxiliary objective disconnected from the
    output that is fed back during rollout.
    """
    records = batch["physics_records"]
    terms = []
    for features, output in records:
        previous = physics.inverse_outputs(features[:, -1, 2:])
        previous_state = physics.observation_to_combustor_state(previous)
        state_delta = output.get("latent_delta")
        if state_delta is None:
            continue
        current_state = previous_state + state_delta
        predicted = physics.inverse_outputs(output["prediction"])
        predicted_state = physics.observation_to_combustor_state(predicted)
        # State and observation increments are compared in normalized state
        # coordinates, so pressure and temperature contribute comparably.
        state_scale = torch.clamp(previous_state.abs(), min=1.0)
        terms.append(torch.mean(((predicted_state - current_state) / state_scale) ** 2))
    return torch.stack(terms).mean() if terms else torch.zeros((), device=batch["prediction"].device)


def safe_physics(physics, features, output):
    previous_outputs = physics.inverse_outputs(features[:, -1, 2:])
    previous_state = physics.observation_to_combustor_state(previous_outputs)
    proposed = previous_state + output["latent_delta"]
    safe_current = torch.stack([
        torch.clamp(proposed[:, 0], min=1000.0),
        torch.clamp(proposed[:, 1], min=250.0),
    ], dim=-1)
    safe_delta = safe_current - previous_state
    return physics(features, output["prediction"], output["flows"], output["previous_flows"], safe_delta)


def recursive_physics_losses(physics, records):
    mass, energy = [], []
    for features, output in records:
        values = safe_physics(physics, features, output)
        mass.append(values["mass_loss"])
        energy.append(values["energy_loss"])
    return torch.stack(mass).mean(), torch.stack(energy).mean()


@torch.no_grad()
def validation_one_step_mse(model, dataset, device):
    model.eval()
    total, count = 0.0, 0
    for features, target, _ in DataLoader(dataset, batch_size=256, shuffle=False):
        features, target = features.to(device), target.to(device)
        prediction = model(features)["prediction"]
        total += float(torch.sum((prediction - target) ** 2))
        count += target.numel()
    return total / count


def starts_for_segment(segment, window, horizon, count, seed):
    candidates = np.arange(window, len(segment.values) - horizon)
    if len(candidates) <= count:
        return candidates.tolist()
    rng = np.random.RandomState(seed)
    return sorted(rng.choice(candidates, size=count, replace=False).tolist())


@torch.no_grad()
def estimate_kendall_scales(model, physics, bundle, args, device):
    model.eval()
    totals = {"data": 0.0, "mass": 0.0, "energy": 0.0}
    count = 0
    for segment_index, segment in enumerate(bundle.segments["train"]):
        starts = starts_for_segment(segment, args.window, 4, 2, args.seed + segment_index)
        for start in starts:
            batch = rollout_batch(model, segment, [start], bundle.scaler, args.window, 4, device, 0.8, args.noise_std)
            data, _, _, _, _, _ = component_losses(batch)
            mass, energy = recursive_physics_losses(physics, batch["physics_records"])
            totals["data"] += float(data); totals["mass"] += float(mass); totals["energy"] += float(energy)
            count += 1
            if count >= 8:
                break
        if count >= 8:
            break
    return {name: max(value / count, 1.0e-12) for name, value in totals.items()}


def train_one(model_name, bundle, output_dir, args):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    use_physics = model_name == "pinn"
    model = ExplicitPhysicsPINN(ModelConfig(d_model=64, nhead=4, encoder_layers=2,
        feedforward_dim=128, max_window=30,
        closure="kan" if use_physics else "fixed")).to(device)
    checkpoint_path = args.pinn_init if use_physics else args.transformer_init
    checkpoint = torch.load(checkpoint_path, map_location=device)
    model.load_state_dict(checkpoint["model"])
    physics = PhysicsLoss(bundle.scaler.minimum, bundle.scaler.scale).to(device)
    weighting = KendallTaskWeighting().to(device) if use_physics else StaticTaskWeighting().to(device)
    scales = estimate_kendall_scales(model, physics, bundle, args, device) if use_physics else {"data": 1.0, "mass": 1.0, "energy": 1.0}
    optimizer = torch.optim.Adam(list(model.parameters()) + list(weighting.parameters()), lr=args.learning_rate)
    baseline_one = validation_one_step_mse(model, bundle.validation, device)
    print("[{}] baseline one-step={} scales={}".format(model_name, baseline_one, scales), flush=True)
    output_dir.mkdir(parents=True, exist_ok=True)
    history, best = [], None

    for epoch in range(1, args.epochs + 1):
        horizon = HORIZON_SCHEDULE[min(epoch - 1, len(HORIZON_SCHEDULE) - 1)]
        teacher_probability = TEACHER_SCHEDULE[min(epoch - 1, len(TEACHER_SCHEDULE) - 1)]
        # Keep the number of unrolled steps per source approximately bounded.
        starts_count = max(8, min(64, args.steps_per_segment // horizon))
        model.train(); weighting.train()
        sums = {name: 0.0 for name in ("data", "one", "rollout", "increment", "drift", "bound", "consistency")}
        batches = 0
        for segment_index, segment in enumerate(bundle.segments["train"]):
            starts = starts_for_segment(segment, args.window, horizon, starts_count,
                                        args.seed + epoch * 101 + segment_index)
            for offset in range(0, len(starts), args.batch_starts):
                selected = starts[offset:offset + args.batch_starts]
                optimizer.zero_grad()
                batch = rollout_batch(model, segment, selected, bundle.scaler, args.window,
                                      horizon, device, teacher_probability, args.noise_std)
                data, one, rollout, increment, drift, bound = component_losses(batch)
                consistency = observation_state_consistency(physics, batch) if use_physics else torch.zeros((), device=device)
                if use_physics:
                    mass, energy = recursive_physics_losses(physics, batch["physics_records"])
                    total, _ = weighting(data / scales["data"], mass / scales["mass"], energy / scales["energy"])
                else:
                    total = data
                objective = total + args.bound_weight * bound + 0.10 * consistency
                if use_physics:
                    objective = objective + 1.0e-5 * model.flow_closure.regularization_loss()
                if not torch.isfinite(objective):
                    raise FloatingPointError("non-finite curriculum objective")
                objective.backward()
                torch.nn.utils.clip_grad_norm_(list(model.parameters()) + list(weighting.parameters()), 1.0)
                optimizer.step()
                for name, value in (("data", data), ("one", one), ("rollout", rollout),
                                    ("increment", increment), ("drift", drift), ("bound", bound), ("consistency", consistency)):
                    sums[name] += float(value.detach())
                batches += 1

        model.eval()
        val_errors = []
        with torch.no_grad():
            for segment_index, segment in enumerate(bundle.segments["validation"]):
                starts = starts_for_segment(segment, args.window, args.validation_horizon,
                                            args.validation_starts, args.seed + segment_index)
                batch = rollout_batch(model, segment, starts, bundle.scaler, args.window,
                                      args.validation_horizon, device, 0.0, 0.0)
                val_errors.append(float(torch.mean((batch["prediction"] - batch["target"]) ** 2)))
        val_rollout = float(np.mean(val_errors))
        val_one = validation_one_step_mse(model, bundle.validation, device)
        one_ratio = val_one / baseline_one
        criterion = val_rollout + max(0.0, one_ratio - 1.10)
        row = {"epoch": epoch, "horizon": horizon, "teacher_probability": teacher_probability,
               "starts_per_segment": starts_count, "validation_rollout": val_rollout,
               "validation_one_step": val_one, "one_step_ratio": one_ratio,
               "selection_criterion": criterion}
        row.update({"train_{}".format(name): value / max(batches, 1) for name, value in sums.items()})
        history.append(row)
        print("[{}] epoch={} H={} p={:.1f} one_ratio={:.3f} val_roll={:.6g} criterion={:.6g}".format(
            model_name, epoch, horizon, teacher_probability, one_ratio, val_rollout, criterion), flush=True)
        if best is None or criterion < best["criterion"]:
            best = {"model": {k: v.detach().cpu() for k, v in model.state_dict().items()},
                    "weighting": weighting.state_dict(), "epoch": epoch,
                    "criterion": criterion, "validation_rollout": val_rollout,
                    "validation_one_step": val_one}
            torch.save(best, str(output_dir / "best.pt"))

    model.load_state_dict(best["model"])
    (output_dir / "history.json").write_text(json.dumps(history, indent=2), encoding="utf-8")
    return model, device, best, history, scales, baseline_one


def write_metrics(path, rows):
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0])); writer.writeheader(); writer.writerows(rows)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", default="data/999")
    parser.add_argument("--output-root", required=True)
    parser.add_argument("--epochs", type=int, default=10)
    parser.add_argument("--window", type=int, default=8)
    parser.add_argument("--batch-starts", type=int, default=4)
    parser.add_argument("--steps-per-segment", type=int, default=256)
    parser.add_argument("--validation-horizon", type=int, default=64)
    parser.add_argument("--validation-starts", type=int, default=4)
    parser.add_argument("--noise-std", type=float, default=0.003)
    parser.add_argument("--bound-weight", type=float, default=0.01)
    parser.add_argument("--learning-rate", type=float, default=1.0e-5)
    parser.add_argument("--seed", type=int, default=2026)
    parser.add_argument("--pinn-init", required=True)
    parser.add_argument("--transformer-init", required=True)
    parser.add_argument("--models", default="pinn,transformer")
    args = parser.parse_args()
    set_seed(args.seed)
    bundle = build_datasets(args.data_dir, window=args.window, include_test=True)
    root = Path(args.output_root); root.mkdir(parents=True, exist_ok=True)
    for model_name in tuple(name.strip() for name in args.models.split(",") if name.strip()):
        started = time.time()
        model, device, best, history, scales, baseline_one = train_one(model_name, bundle, root / model_name, args)
        target_n, prediction_n, _, conditions = one_step_predictions_with_metadata(model, bundle.test, device)
        target = target_n * bundle.scaler.scale[2:] + bundle.scaler.minimum[2:]
        prediction = prediction_n * bundle.scaler.scale[2:] + bundle.scaler.minimum[2:]
        roll_tn, roll_pn, _, roll_conditions = rollout_predictions(model, bundle.segments["test"], bundle.scaler, args.window, device)
        roll_target = roll_tn * bundle.scaler.scale[2:] + bundle.scaler.minimum[2:]
        roll_prediction = roll_pn * bundle.scaler.scale[2:] + bundle.scaler.minimum[2:]
        write_metrics(root / model_name / "test_metrics.csv", grouped_metric_table(target, prediction, conditions))
        write_metrics(root / model_name / "rollout_metrics.csv", grouped_metric_table(roll_target, roll_prediction, roll_conditions))
        np.savez_compressed(root / model_name / "test_predictions.npz", target=target, prediction=prediction, condition=conditions)
        np.savez_compressed(root / model_name / "rollout_predictions.npz", target=roll_target, prediction=roll_prediction, condition=roll_conditions)
        config = vars(args).copy(); config.update({"model": model_name, "best_epoch": best["epoch"],
            "kendall_scales": scales, "baseline_validation_one_step": baseline_one,
            "elapsed_seconds": time.time() - started, "test_evaluated_after_freezing": True,
            "architecture_changed": False})
        (root / model_name / "run_config.json").write_text(json.dumps(config, indent=2), encoding="utf-8")
    print(str(root), flush=True)


if __name__ == "__main__":
    main()
