"""Aggregate recursive metrics from all model/seed directories into one table."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd


MODELS = ("lstm", "tcn", "kan", "transformer", "pinn")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", required=True, help="directory containing model_seed* result directories")
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    root = Path(args.root)
    frames = []
    audit = []
    for model in MODELS:
        for directory in sorted(root.glob(model + "_seed*")):
            metrics = directory / "fixed_horizon_metrics.csv"
            config = directory / "run_config.json"
            if not metrics.exists():
                audit.append({"directory": str(directory), "status": "missing_fixed_horizon_metrics"})
                continue
            frame = pd.read_csv(metrics)
            frame["model"] = model
            frame["run_directory"] = directory.name
            if config.exists():
                metadata = json.loads(config.read_text(encoding="utf-8"))
                frame["seed"] = metadata.get("seed", directory.name.split("_seed")[-1])
                frame["python_environment"] = metadata.get("python_environment", "unspecified")
                frame["window"] = metadata.get("data", {}).get("window", metadata.get("window", 8))
                frame["fine_tune_horizon"] = metadata.get("fine_tune_horizon", 16)
            else:
                frame["seed"] = directory.name.split("_seed")[-1]
                frame["python_environment"] = "unspecified"
                frame["window"] = 8
                frame["fine_tune_horizon"] = 16
            frames.append(frame)
            audit.append({"directory": str(directory), "status": "included", "rows": int(len(frame))})
    if not frames:
        raise RuntimeError("No fixed_horizon_metrics.csv files found")
    result = pd.concat(frames, ignore_index=True)
    result.to_csv(args.output, index=False, encoding="utf-8-sig")
    summary = result.groupby(["model", "condition", "horizon", "output"], as_index=False).agg(
        MSE_mean=("MSE", "mean"), MSE_std=("MSE", "std"),
        RMSE_mean=("RMSE", "mean"), RMSE_std=("RMSE", "std"),
        MAE_mean=("MAE", "mean"), MAE_std=("MAE", "std"),
        runs=("seed", "nunique"),
    )
    summary.to_csv(Path(args.output).with_name(Path(args.output).stem + "_mean_std.csv"), index=False, encoding="utf-8-sig")
    Path(args.output).with_name(Path(args.output).stem + "_audit.json").write_text(
        json.dumps({"rows": int(len(result)), "models": sorted(result.model.unique()), "runs": audit}, indent=2),
        encoding="utf-8",
    )
    print(json.dumps({"rows": len(result), "models": sorted(result.model.unique())}, indent=2))


if __name__ == "__main__":
    main()
