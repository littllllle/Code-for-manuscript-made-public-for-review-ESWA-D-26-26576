import json
import unittest
from pathlib import Path

import numpy as np

from revision_explicit_pinn.evaluation import metric_table


class MetricsTest(unittest.TestCase):
    def test_perfect_prediction(self):
        target = np.arange(50, dtype=np.float64).reshape(10, 5) + 1.0
        rows = metric_table(target, target.copy())
        self.assertEqual(len(rows), 5)
        for row in rows:
            self.assertEqual(row["MSE"], 0.0)
            self.assertAlmostEqual(row["R2"], 1.0)
            self.assertAlmostEqual(row["fit_score_percent"], 100.0)

    def test_grid_has_35_configurations_and_three_seeds(self):
        path = Path(__file__).resolve().parents[1] / "configs" / "grid_search.json"
        with open(path, "r", encoding="utf-8") as handle:
            config = json.load(handle)
        self.assertEqual(len(config["batch_sizes"]) * len(config["windows"]), 35)
        self.assertEqual(len(config["seeds"]), 3)
        self.assertFalse(config["isga_used"])


if __name__ == "__main__":
    unittest.main()
