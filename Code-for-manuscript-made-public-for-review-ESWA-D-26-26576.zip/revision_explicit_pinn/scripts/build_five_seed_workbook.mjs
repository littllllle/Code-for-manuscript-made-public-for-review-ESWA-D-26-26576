import fs from "node:fs/promises";
import path from "node:path";
import { SpreadsheetFile, Workbook } from "@oai/artifact-tool";

const sourceDir = process.argv[2];
const outputPath = process.argv[3];
if (!sourceDir || !outputPath) {
  throw new Error("Usage: node build_five_seed_workbook.mjs <tables-dir> <output.xlsx>");
}

const imports = [
  ["one_step_seed_metrics.csv", "OneStep Seed"],
  ["one_step_mean_std.csv", "OneStep Summary"],
  ["one_step_wilcoxon_holm.csv", "OneStep Tests"],
  ["recursive_pooled_horizon_seed_metrics.csv", "Recursive Seed"],
  ["recursive_pooled_horizon_mean_std.csv", "Recursive Summary"],
  ["recursive_endpoint_mean_std.csv", "Recursive Endpoint"],
  ["recursive_wilcoxon_holm.csv", "Recursive Tests"],
];

const firstText = await fs.readFile(path.join(sourceDir, imports[0][0]), "utf8");
const workbook = await Workbook.fromCSV(firstText, { sheetName: imports[0][1] });
for (const [fileName, sheetName] of imports.slice(1)) {
  const csvText = await fs.readFile(path.join(sourceDir, fileName), "utf8");
  await workbook.fromCSV(csvText, { sheetName });
}

const protocol = workbook.worksheets.add("Protocol");
protocol.getRange("A1:F1").merge();
protocol.getRange("A1").values = [["Five-seed statistical evidence for one-step and finite-horizon prediction"]];
protocol.getRange("A3:B13").values = [
  ["Item", "Definition"],
  ["Models", "LSTM, TCN, KAN, Transformer, TK-PINN"],
  ["Seeds", "2026, 2027, 2028, 2029, 2030"],
  ["Test conditions", "Startup, load change, shutdown; complete test segments"],
  ["Outputs", "P_c, n, W_e, T_e, G_NOx; reported separately"],
  ["Recursive horizons", "H = 10, 20, 40, 80 steps"],
  ["Mean/std", "Arithmetic mean and sample standard deviation across five seeds (ddof=1)"],
  ["Recursive pooled MSE", "For each seed and horizon, arithmetic mean of lead-wise MSE over leads 1...H"],
  ["Recursive pooled RMSE", "Square root of the corresponding pooled-horizon MSE"],
  ["Statistical test", "Paired two-sided Wilcoxon signed-rank test on seed-level MSE"],
  ["Multiplicity", "Holm correction across four TK-PINN versus baseline tests within each task family"],
];
protocol.getRange("D3:E8").values = [
  ["Verification", "Workbook formula"],
  ["One-step seed rows", null],
  ["One-step summary rows", null],
  ["Recursive seed rows", null],
  ["Recursive summary rows", null],
  ["Significant tests (Holm, 0.05)", null],
];
protocol.getRange("E4").formulas = [["=COUNTA('OneStep Seed'!A2:A376)"]];
protocol.getRange("E5").formulas = [["=COUNTA('OneStep Summary'!A2:A76)"]];
protocol.getRange("E6").formulas = [["=COUNTA('Recursive Seed'!A2:A1501)"]];
protocol.getRange("E7").formulas = [["=COUNTA('Recursive Summary'!A2:A301)"]];
protocol.getRange("E8").formulas = [["=COUNTIF('OneStep Tests'!O2:O61,TRUE)+COUNTIF('Recursive Tests'!P2:P241,TRUE)"]];

const headerFill = "#1F4E78";
const subheaderFill = "#D9EAF7";
for (const sheet of workbook.worksheets.items) {
  sheet.showGridLines = false;
  const used = sheet.getUsedRange();
  if (used) {
    used.format.font = { name: "Times New Roman", size: 10, color: "#1A1A1A" };
    used.format.verticalAlignment = "center";
  }
  if (sheet.name !== "Protocol") {
    const header = used.getRow(0);
    header.format.fill = headerFill;
    header.format.font = { name: "Times New Roman", size: 10, bold: true, color: "#FFFFFF" };
    header.format.wrapText = true;
    header.format.rowHeight = 32;
    sheet.freezePanes.freezeRows(1);
    used.format.borders = {
      insideHorizontal: { style: "thin", color: "#E5E7EB" },
      bottom: { style: "thin", color: "#9CA3AF" },
    };
    used.format.autofitColumns();
    used.format.autofitRows();
  }
}

protocol.getRange("A1:F1").format = {
  fill: headerFill,
  font: { name: "Times New Roman", size: 15, bold: true, color: "#FFFFFF" },
  horizontalAlignment: "center",
  verticalAlignment: "center",
  rowHeight: 30,
};
protocol.getRange("A3:B3").format = { fill: subheaderFill, font: { bold: true, color: "#1F2937" } };
protocol.getRange("D3:E3").format = { fill: subheaderFill, font: { bold: true, color: "#1F2937" } };
protocol.getRange("A3:B13").format.borders = { preset: "all", style: "thin", color: "#CBD5E1" };
protocol.getRange("D3:E8").format.borders = { preset: "all", style: "thin", color: "#CBD5E1" };
protocol.getRange("A1:A13").format.columnWidth = 24;
protocol.getRange("B1:B13").format.columnWidth = 78;
protocol.getRange("D1:D13").format.columnWidth = 30;
protocol.getRange("E1:E13").format.columnWidth = 18;
protocol.getRange("B4:B13").format.wrapText = true;
protocol.getRange("A3:E13").format.autofitRows();
protocol.freezePanes.freezeRows(3);

for (const name of ["OneStep Tests", "Recursive Tests"]) {
  const sheet = workbook.worksheets.getItem(name);
  const used = sheet.getUsedRange();
  const headers = used.getRow(0).values[0];
  const adjustedIndex = headers.indexOf("p_holm");
  if (adjustedIndex >= 0) {
    const column = sheet.getRangeByIndexes(1, adjustedIndex, used.rowCount - 1, 1);
    column.format.numberFormat = "0.0000";
    column.conditionalFormats.add("cellIs", {
      operator: "lessThan",
      formula: 0.05,
      format: { fill: "#DCFCE7", font: { color: "#166534", bold: true } },
    });
  }
}

await fs.mkdir(path.dirname(outputPath), { recursive: true });
const previewDir = path.join(path.dirname(outputPath), "workbook_previews");
await fs.mkdir(previewDir, { recursive: true });
for (const sheet of workbook.worksheets.items) {
  const previewRange = sheet.name === "Protocol" ? "A1:F13" : "A1:Q25";
  const preview = await workbook.render({ sheetName: sheet.name, range: previewRange, scale: 0.8, format: "png" });
  await fs.writeFile(path.join(previewDir, `${sheet.name.replaceAll(" ", "_")}.png`), new Uint8Array(await preview.arrayBuffer()));
}

const inspection = await workbook.inspect({
  kind: "table",
  range: "Protocol!A1:E13",
  include: "values,formulas",
  tableMaxRows: 15,
  tableMaxCols: 6,
});
console.log(inspection.ndjson);
const errors = await workbook.inspect({
  kind: "match",
  searchTerm: "#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A",
  options: { useRegex: true, maxResults: 100 },
  summary: "final formula error scan",
});
console.log(errors.ndjson);

const output = await SpreadsheetFile.exportXlsx(workbook);
await output.save(outputPath);
console.log(`saved ${outputPath}`);
