from collections import defaultdict

import numpy as np
import torch
from torch.utils.data import DataLoader


@torch.no_grad()
def one_step_predictions(model, dataset, device, batch_size=256):
    model.eval()
    predictions = []
    targets = []
    loader = DataLoader(dataset, batch_size=batch_size, shuffle=False, drop_last=False)
    for features, target, _ in loader:
        output = model(features.to(device))["prediction"].cpu().numpy()
        predictions.append(output)
        targets.append(target.numpy())
    return np.concatenate(targets), np.concatenate(predictions)


@torch.no_grad()
def one_step_predictions_with_metadata(model, dataset, device, batch_size=256):
    """One-step predictions with source/condition labels kept sample-aligned."""
    target, prediction = one_step_predictions(model, dataset, device, batch_size=batch_size)
    metadata = [sample[2] for sample in dataset.samples]
    sources = np.asarray([item["source"] for item in metadata])
    conditions = np.asarray([item["condition"] for item in metadata])
    return target, prediction, sources, conditions


@torch.no_grad()
def rollout_predictions(model, segments, scaler, window, device):
    """Free-run each trajectory; only measured controls remain available after initialization."""
    model.eval()
    all_targets = []
    all_predictions = []
    source_ids = []
    condition_ids = []
    for segment in segments:
        normalized = scaler.transform(segment.values).astype(np.float32)
        predicted_outputs = {}
        for target_time in range(window, len(normalized)):
            token_times = range(target_time - window + 1, target_time + 1)
            tokens = []
            for token_time in token_times:
                previous_time = token_time - 1
                previous_output = predicted_outputs.get(previous_time, normalized[previous_time, 2:])
                tokens.append(np.concatenate([normalized[token_time, :2], previous_output]))
            features = torch.tensor(np.asarray(tokens), dtype=torch.float32, device=device).unsqueeze(0)
            prediction = model(features)["prediction"].squeeze(0).cpu().numpy()
            predicted_outputs[target_time] = prediction
            all_targets.append(normalized[target_time, 2:])
            all_predictions.append(prediction)
            source_ids.append(segment.source)
            condition_ids.append(segment.condition)
    return (
        np.asarray(all_targets),
        np.asarray(all_predictions),
        np.asarray(source_ids),
        np.asarray(condition_ids),
    )
