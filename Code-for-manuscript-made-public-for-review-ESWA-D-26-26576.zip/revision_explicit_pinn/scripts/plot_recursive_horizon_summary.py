"""Plot completed finite-horizon recursive MSE by test condition."""
from pathlib import Path
import csv
import collections

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from revision_explicit_pinn.plotting.paper_style import apply_paper_style, save_figure


ROOT = Path(r"D:\PythonProjects\PINN_code+tex\ESWA返修\返修交付包_统一参数框架_20260831\04_图表与CSV结果\final_simulation_20260831\04_recursive_finite_horizon")
OUT = ROOT / "summary_figures"
MODELS = {
    "lstm": ("LSTM", "#2ca02c"),
    "tcn": ("TCN", "#9467bd"),
    "kan": ("KAN", "#ff7f0e"),
    "transformer": ("Transformer", "#1f77b4"),
    "pinn": ("TK-PINN", "#d62728"),
}
CONDITIONS = ("startup", "load_change", "shutdown")
CONDITION_LABELS = {"startup": "Startup", "load_change": "Load change", "shutdown": "Shutdown"}
HORIZONS = (10, 20, 40, 80)


def collect():
    values = collections.defaultdict(list)
    for run_dir in ROOT.glob("*_seed*"):
        model = run_dir.name.split("_seed", 1)[0]
        if model not in MODELS:
            continue
        path = run_dir / "fixed_horizon_metrics.csv"
        if not path.exists():
            continue
        with path.open(encoding="utf-8", newline="") as handle:
            for row in csv.DictReader(handle):
                if row["condition"] in CONDITIONS and int(row["horizon"]) in HORIZONS:
                    values[(model, row["condition"], int(row["horizon"]))].append(float(row["MSE"]))
    return values


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    apply_paper_style(font_size=9)
    values = collect()
    fig, axes = plt.subplots(1, 3, figsize=(8.2, 2.9), sharey=True, constrained_layout=True)
    for ax, condition in zip(axes, CONDITIONS):
        for model, (label, color) in MODELS.items():
            means = [np.mean(values[(model, condition, h)]) if values[(model, condition, h)] else np.nan for h in HORIZONS]
            if np.isfinite(means).any():
                ax.plot(HORIZONS, means, marker="o", markersize=3.5, linewidth=1.1, color=color, label=label)
        ax.set_title(CONDITION_LABELS[condition])
        ax.set_xlabel("Recursive horizon (steps)")
        ax.set_xticks(HORIZONS)
        ax.set_yscale("log")
        ax.grid(alpha=0.22, linewidth=0.6)
        ax.tick_params(direction="in")
    axes[0].set_ylabel("Mean MSE (all outputs, five seeds)")
    axes[0].legend(frameon=False, fontsize=8, loc="upper left")
    save_figure(fig, OUT / "recursive_horizon_mse_by_condition.png", dpi=300)
    plt.close(fig)

    rows = []
    for (model, condition, horizon), data in sorted(values.items()):
        rows.append({"model": model, "condition": condition, "horizon": horizon,
                     "mean_mse": float(np.mean(data)), "std_mse": float(np.std(data, ddof=1)),
                     "n": len(data)})
    with (OUT / "recursive_horizon_mse_summary.csv").open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(rows)
    print("saved", OUT / "recursive_horizon_mse_by_condition.png")


if __name__ == "__main__":
    main()
