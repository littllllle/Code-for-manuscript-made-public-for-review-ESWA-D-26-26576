"""Reproducible explicit-physics PINN implementation for the ESWA revision."""

