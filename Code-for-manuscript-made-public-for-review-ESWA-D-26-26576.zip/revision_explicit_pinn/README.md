# Explicit-physics PINN revision workspace

This directory is the clean implementation target for the ESWA revision. The copied historical implementation is in `../legacy_source` and must remain unchanged except when a deliberately documented compatibility fix is required.

Run Python through the supplied environment wrapper from the implementation root:

```powershell
.\run_pinn_kan.ps1 -c "import torch; print(torch.cuda.is_available())"
```

The implementation order is defined by `../review_plan/08_按代码逻辑顺序的完整修改与执行计划.md`.

The manuscript dataset, the PG9351FA parameter thesis, and the Taiyanggong operation manual have been confirmed to concern the same gas-turbine model. Source copies are preserved in `../parameter_sources/`. The confirmed nominal values and the remaining evidence gates are recorded in `../IMPLEMENTATION_READINESS.md`.

Current package layout:

```text
configs -> data -> physics -> models -> losses -> training
        -> evaluation -> analysis/plotting -> scripts/tests
```

Real-data preprocessing, model development, synthetic physics tests, and parameterized pilot runs may start immediately. Do not freeze the final strong-PINN experiment or manuscript claims until the parameter, observation-mapping, sensitivity, and held-out physics checks in `../IMPLEMENTATION_READINESS.md` are satisfied.

Implemented entry points:

```powershell
# Unit, leakage, SI-unit, and differentiability checks
..\run_pinn_kan.ps1 -m unittest discover -s revision_explicit_pinn\tests -v

# A configured training run (write to a permitted output directory)
..\run_pinn_kan.ps1 -m revision_explicit_pinn.scripts.train `
  --data-dir data\999 --output-dir <run-dir> --window 2 `
  --batch-size 16 --epochs 100 --weighting kendall --rollout

# Generate the fixed 35-configuration x 3-seed plan; this does not launch jobs
..\run_pinn_kan.ps1 -m revision_explicit_pinn.scripts.make_grid_manifest

# Render a completed run using the shared paper style
..\run_pinn_kan.ps1 -m revision_explicit_pinn.scripts.plot_run --run-dir <run-dir>
```

Important source-unit correction: the manuscript figures identify recorded
compressor pressure as `kgf/cm2(g)` and turbine exhaust temperature as degree C.
The physics layer converts them to absolute Pa and K. The nomenclature table in
the current manuscript (`kPa`, `K`) is inconsistent with the actual records and
must be corrected during manuscript revision.
