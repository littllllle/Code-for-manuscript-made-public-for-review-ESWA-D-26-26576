"""Rebuild the one-step five-instance statistics from the window-4 archive.

The manuscript's measured-feedback one-step comparison uses the window length
S_l=4 selected by the validation-only screen for all five models.  This script
recomputes the physical-unit tables (MSE, RMSE, MAE, active-set MAPE, fitting
score), the paired Wilcoxon/Holm tests, and the LaTeX row block for
Tables 4--6 directly from the frozen window-4 test-prediction CSVs.

Metric definitions follow finalize_five_seed_evidence.py:
  - std: sample standard deviation across the five seeds (ddof=1);
  - fit score: 100*(1 - sqrt(sum(e^2))/sqrt(sum(y^2)));
  - active MAPE: 100*mean(|e/y|) over |y| >= 0.01*max(|training y|) per output.
"""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import wilcoxon

PACKAGE = Path(__file__).resolve().parents[1]
RESULTS = PACKAGE / "04_图表与CSV结果"
PRIMARY = RESULTS / "primary_window4_20260907"

SEEDS = (2026, 2027, 2028, 2029, 2030)
# Directory names in primary_window4_20260907.
MODELS = (("lstm", "LSTM"), ("tcn", "TCN"), ("kan", "KAN"),
          ("transformer", "Transformer"), ("tk_pinn", "TK-PINN"))
CONDITIONS = ("startup", "load_change", "shutdown")
OUTPUTS = (("P_c", r"$P_c$ (kg$\cdot$cm$^{-2}$)"), ("n", r"$n$ ($\mathrm{r\cdot min^{-1}}$)"),
           ("W_e", r"$W_e$ (MW)"), ("T_e", r"$T_e$ ($^{\circ}$C)"),
           ("G_NOx", r"$G_{NOx}$ (mg$\cdot$Nm$^{-3}$)"))

# Training-only maximum absolute output values (identical for every final
# training configuration; recomputed from data_train*.csv when available).
REFERENCE_MAX_FALLBACK = {"P_c": 16.3311882, "n": 3013.194824, "W_e": 278.4793396,
                          "T_e": 650.8931274, "G_NOx": 100.0}


def active_mape(truth, estimate, reference_max=None, relative_threshold=0.01):
    truth = np.asarray(truth, dtype=np.float64)
    estimate = np.asarray(estimate, dtype=np.float64)
    scale = float(np.max(np.abs(truth)) if reference_max is None else reference_max)
    threshold = relative_threshold * max(scale, np.finfo(np.float64).eps)
    valid = np.abs(truth) >= threshold
    if not np.any(valid):
        return np.nan, 0.0, threshold
    value = float(np.mean(np.abs(estimate[valid] - truth[valid]) / np.abs(truth[valid])) * 100.0)
    return value, float(np.mean(valid)), threshold


def training_output_max():
    for data_dir in (PACKAGE / "03_代码" / "data" / "999",
                     PACKAGE.parents[1] / "03_代码" / "data" / "999"):
        arrays = [np.loadtxt(path, delimiter=",", encoding="utf-8-sig")
                  for path in sorted(data_dir.glob("data_train*.csv"))]
        if arrays:
            values = np.vstack(arrays)[:, 2:]
            return {name: float(np.max(np.abs(values[:, i]))) for i, (name, _) in enumerate(OUTPUTS)}
    return dict(REFERENCE_MAX_FALLBACK)


def metrics_from_predictions(frame, mape_reference_max):
    target = frame["target"].to_numpy(dtype=float)
    prediction = frame["prediction"].to_numpy(dtype=float)
    error = prediction - target
    mse = float(np.mean(error ** 2))
    mape, coverage, threshold = active_mape(target, prediction, reference_max=mape_reference_max)
    target_energy = float(np.sum(target ** 2))
    fit_score = (100.0 * (1.0 - math.sqrt(float(np.sum(error ** 2))) / math.sqrt(target_energy))
                 if target_energy > 0 else float("nan"))
    return {"MSE": mse, "RMSE": math.sqrt(mse), "MAE": float(np.mean(np.abs(error))),
            "MAPE_percent": mape, "MAPE_active_coverage": coverage,
            "MAPE_active_threshold": threshold, "fit_score_percent": fit_score,
            "R2": float("nan"), "samples": int(len(frame))}


def collect_one_step(reference_max, audit):
    rows = []
    for model, label in MODELS:
        for seed in SEEDS:
            path = PRIMARY / f"{model}_seed{seed}" / "test_predictions.csv"
            if not path.exists():
                audit.append({"model": model, "seed": seed, "status": "missing", "path": str(path)})
                continue
            frame = pd.read_csv(path)
            for condition in CONDITIONS:
                for index, (output, _) in enumerate(OUTPUTS):
                    subset = frame[(frame["condition"] == condition) & (frame["output_index"] == index)]
                    if subset.empty:
                        raise ValueError(f"No rows for {model}, seed={seed}, {condition}, {output}")
                    rows.append({"model": model, "model_label": label, "seed": seed,
                                 "condition": condition, "output": output,
                                 **metrics_from_predictions(subset, reference_max[output])})
            audit.append({"model": model, "seed": seed, "status": "included", "path": str(path),
                          "prediction_rows": int(len(frame))})
    result = pd.DataFrame(rows)
    if len(result) != len(MODELS) * len(SEEDS) * len(CONDITIONS) * len(OUTPUTS):
        raise RuntimeError(f"One-step table has {len(result)} rows; expected {5 * 5 * 3 * 5}")
    return result


def holm_adjust(p_values):
    order = np.argsort(p_values)
    adjusted = np.empty(len(p_values), dtype=float)
    running = 0.0
    for rank, index in enumerate(order):
        candidate = min(1.0, (len(p_values) - rank) * float(p_values[index]))
        running = max(running, candidate)
        adjusted[index] = running
    return adjusted


def paired_tests(frame):
    rows = []
    for keys, group in frame.groupby(["condition", "output"], sort=False):
        pivot = group.pivot(index="seed", columns="model", values="MSE")
        for baseline in ("lstm", "tcn", "kan", "transformer"):
            delta = pivot["tk_pinn"].to_numpy() - pivot[baseline].to_numpy()
            if np.allclose(delta, 0.0):
                statistic, p_value = 0.0, 1.0
            else:
                test = wilcoxon(pivot["tk_pinn"], pivot[baseline], alternative="two-sided", mode="auto")
                statistic, p_value = float(test.statistic), float(test.pvalue)
            rows.append({"condition": keys[0], "output": keys[1], "comparison": f"TK-PINN vs {baseline.upper()}",
                         "n_pairs": len(delta), "wilcoxon_statistic": statistic, "p_raw": p_value})
    result = pd.DataFrame(rows)
    result["p_holm"] = np.nan
    for _, indices in result.groupby(["condition", "output"]).groups.items():
        idx = list(indices)
        result.loc[idx, "p_holm"] = holm_adjust(result.loc[idx, "p_raw"].to_numpy())
    result["significant_0_05"] = result["p_holm"] < 0.05
    return result


def latex_number(mean, sd):
    return f"${mean:.3f}\\pm{sd:.3f}$"


def latex_sig(value, significant=4):
    """Plain-decimal rendering with `significant` significant digits."""
    if value == 0:
        return "0"
    decimals = max(0, significant - 1 - int(math.floor(math.log10(abs(value)))))
    return f"{value:.{decimals}f}"


def latex_rows(summary):
    """Data rows for Tables 4--6 in the manuscript's current table style."""
    out = []
    for oi, (output, display) in enumerate(OUTPUTS):
        part = summary[(summary.output == output)]
        if len(part) != 5:
            raise RuntimeError(f"bad row count for {output}")
        for mi, (model, label) in enumerate(MODELS):
            row = part[part.model == model].iloc[0]
            prefix = display if mi == 0 else ""
            mse = f"${latex_sig(row.MSE_mean)}\\pm{latex_sig(row.MSE_std)}$"
            values = [mse, latex_number(row.RMSE_mean, row.RMSE_std),
                      latex_number(row.MAE_mean, row.MAE_std),
                      latex_number(row.MAPE_percent_mean, row.MAPE_percent_std),
                      latex_number(row.fit_score_percent_mean, row.fit_score_percent_std)]
            out.append(prefix + " & " + label + " & " + " & ".join(values) + r" \\")
        if oi < len(OUTPUTS) - 1:
            out.append(r"\midrule")
    return "\n".join(out)


def claim_checks(summary, tests):
    lines = []
    for condition in CONDITIONS:
        part = summary[summary.condition == condition]
        best = part.loc[part.groupby("output").MSE_mean.idxmin()][["output", "model", "MSE_mean"]]
        lines.append(f"{condition}: best per output -> "
                     + ", ".join(f"{r.output}:{r.model}({r.MSE_mean:.4g})" for r in best.itertuples()))
    lines.append("Holm-significant TK-PINN-vs-baseline tests (alpha=0.05): "
                 + str(int(tests.significant_0_05.sum())))
    sig = tests[tests.significant_0_05]
    if len(sig):
        lines.append("significant cells:\n" + sig.to_string(index=False))
    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--primary-dir", default=str(PRIMARY))
    parser.add_argument("--out-dir", default=str(PRIMARY / "aggregated"))
    args = parser.parse_args()
    primary = Path(args.primary_dir)
    out = Path(args.out_dir)
    out.mkdir(parents=True, exist_ok=True)
    audit = []
    reference_max = training_output_max()
    frame = collect_one_step(reference_max, audit)
    summary = frame.groupby(["model", "model_label", "condition", "output"], as_index=False).agg(
        **{f"{m}_mean": (m, "mean") for m in ("MSE", "RMSE", "MAE", "MAPE_percent",
                                              "MAPE_active_coverage", "MAPE_active_threshold",
                                              "fit_score_percent", "R2")},
        **{f"{m}_std": (m, "std") for m in ("MSE", "RMSE", "MAE", "MAPE_percent",
                                            "MAPE_active_coverage", "MAPE_active_threshold",
                                            "fit_score_percent", "R2")},
        n_seeds=("seed", "nunique"))
    summary.to_csv(out / "one_step_mean_std.csv", index=False, encoding="utf-8-sig")
    frame.to_csv(out / "one_step_seed_metrics.csv", index=False, encoding="utf-8-sig")
    tests = paired_tests(frame)
    tests.to_csv(out / "one_step_wilcoxon_holm.csv", index=False, encoding="utf-8-sig")
    rows = {}
    for condition in CONDITIONS:
        rows[condition] = latex_rows(summary[summary.condition == condition])
    (out / "tables4_6_rows_window4.json").write_text(
        json.dumps(rows, indent=1, ensure_ascii=False), encoding="utf-8")
    (out / "one_step_rebuild_audit.json").write_text(json.dumps({
        "protocol": {"seeds": list(SEEDS), "models": [m for m, _ in MODELS],
                     "conditions": list(CONDITIONS), "outputs": [o for o, _ in OUTPUTS],
                     "window": 4, "std_definition": "sample standard deviation across five seeds (ddof=1)",
                     "fit_score_definition": "100*(1-sqrt(sum(error^2))/sqrt(sum(target^2)))",
                     "mape_definition": "100*mean(abs(error/target)) over |target| >= 0.01*training_max_abs(output)",
                     "mape_reference_max_abs_training": reference_max,
                     "laTeX_format": "MSE: 4 significant digits; RMSE/MAE/MAPE/Fs: 3 decimals"},
        "issues": [r for r in audit if r["status"] != "included"],
        "runs": audit}, indent=2, ensure_ascii=False), encoding="utf-8")
    print(claim_checks(summary, tests))
    print(f"wrote one-step window-4 statistics to {out}")


if __name__ == "__main__":
    main()
