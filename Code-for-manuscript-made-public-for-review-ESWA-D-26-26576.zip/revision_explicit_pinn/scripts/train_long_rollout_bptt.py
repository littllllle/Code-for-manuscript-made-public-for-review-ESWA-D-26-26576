"""Architecture-preserving long-rollout training with differentiable BPTT and DAgger."""
import argparse
import csv
import json
import time
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import DataLoader

from revision_explicit_pinn.data import WindowedGasTurbineDataset, build_datasets
from revision_explicit_pinn.evaluation import grouped_metric_table, one_step_predictions_with_metadata, rollout_predictions
from revision_explicit_pinn.losses import KendallTaskWeighting, PhysicsLoss, StaticTaskWeighting
from revision_explicit_pinn.models import ExplicitPhysicsPINN, ModelConfig
from revision_explicit_pinn.training import set_seed
from revision_explicit_pinn.scripts.train_recursive_curriculum_10epoch import (
    component_losses, recursive_physics_losses, rollout_batch, safe_physics, starts_for_segment,
)


REGIMES = ("startup", "load_change", "shutdown")
HORIZONS = (4, 8, 16, 32, 64, 64, 128, 128, 256, 256)
TEACHER_PROBABILITIES = (0.8, 0.8, 0.6, 0.6, 0.4, 0.3, 0.2, 0.1, 0.05, 0.0)


def write_rows(path, rows):
    with Path(path).open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(rows)


@torch.no_grad()
def one_step_mse(model, dataset, device):
    total = 0.0; count = 0
    model.eval()
    for features, target, _ in DataLoader(dataset, batch_size=256, shuffle=False):
        prediction = model(features.to(device))["prediction"]
        target = target.to(device)
        total += float(torch.sum((prediction - target) ** 2)); count += target.numel()
    return total / count


def estimate_scales(model, physics, segments, scaler, args, device):
    model.eval(); totals = {"data": 0.0, "mass": 0.0, "energy": 0.0}; count = 0
    with torch.no_grad():
        for segment_index, segment in enumerate(segments):
            for start in starts_for_segment(segment, args.window, 4, 4, args.seed + segment_index):
                batch = rollout_batch(model, segment, [start], scaler, args.window, 4, device, 0.9, args.noise_std)
                data, *_ = component_losses(batch)
                mass, energy = recursive_physics_losses(physics, batch["physics_records"])
                totals["data"] += float(data); totals["mass"] += float(mass); totals["energy"] += float(energy); count += 1
                if count >= 8: break
            if count >= 8: break
    return {name: max(value / count, 1e-12) for name, value in totals.items()}


@torch.no_grad()
def dagger_features(model, segment, starts, scaler, window, horizon, device):
    """Collect model-induced histories and retain real next-step labels."""
    values = scaler.transform(segment.values).astype(np.float32)
    controls = torch.as_tensor(values[:, :2], device=device)
    truth = torch.as_tensor(values[:, 2:], device=device)
    features, targets = [], []
    was_training = model.training
    model.eval()
    for start in starts:
        history = [truth[index] for index in range(start - window, start)]
        for step in range(horizon):
            target_time = start + step
            tokens = []
            for token_time in range(target_time - window + 1, target_time + 1):
                previous = history[token_time - 1 - (start - window)]
                tokens.append(torch.cat([controls[token_time], previous], dim=-1))
            feature = torch.stack(tokens)
            prediction = model(feature.unsqueeze(0))["prediction"].squeeze(0)
            features.append(feature.cpu()); targets.append(truth[target_time].cpu())
            history.append(prediction.detach())
    model.train(was_training)
    return torch.stack(features), torch.stack(targets)


def train_one_step(model, physics, weighting, optimizer, dataset, use_physics, scales, device):
    model.train(); weighting.train(); total = 0.0; count = 0
    loader = DataLoader(dataset, batch_size=32, shuffle=True, drop_last=True)
    for features, target, _ in loader:
        features, target = features.to(device), target.to(device)
        optimizer.zero_grad(); output = model(features)
        data = torch.mean((output["prediction"] - target) ** 2)
        if use_physics:
            values = safe_physics(physics, features, output)
            loss, _ = weighting(data / scales["data"], values["mass_loss"] / scales["mass"], values["energy_loss"] / scales["energy"])
            loss = loss + 1e-5 * model.flow_closure.regularization_loss()
        else:
            loss = data
        loss.backward(); torch.nn.utils.clip_grad_norm_(list(model.parameters()) + list(weighting.parameters()), 1.0); optimizer.step()
        total += float(data.detach()) * len(features); count += len(features)
    return total / max(count, 1)


def train_regime(model_name, regime, bundle, output_dir, args):
    output_dir.mkdir(parents=True, exist_ok=True)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    use_physics = model_name == "pinn"
    train_segments = [segment for segment in bundle.segments["train"] if segment.condition == regime]
    validation_segments = [segment for segment in bundle.segments["validation"] if segment.condition == regime]
    test_segments = [segment for segment in bundle.segments["test"] if segment.condition == regime]
    train_dataset = WindowedGasTurbineDataset(train_segments, bundle.scaler, args.window)
    validation_dataset = WindowedGasTurbineDataset(validation_segments, bundle.scaler, args.window)
    test_dataset = WindowedGasTurbineDataset(test_segments, bundle.scaler, args.window)
    model = ExplicitPhysicsPINN(ModelConfig(d_model=64, nhead=4, encoder_layers=2, feedforward_dim=128, max_window=30, closure="kan")).to(device)
    initial = torch.load(args.pinn_init if use_physics else args.transformer_init, map_location=device)
    model.load_state_dict(initial["model"])
    physics = PhysicsLoss(bundle.scaler.minimum, bundle.scaler.scale).to(device)
    weighting = KendallTaskWeighting().to(device) if use_physics else StaticTaskWeighting().to(device)
    optimizer = torch.optim.Adam(list(model.parameters()) + list(weighting.parameters()), lr=args.learning_rate)
    initial_scales = {"data": 1.0, "mass": 1.0, "energy": 1.0}
    # Phase A: condition-specific one-step adaptation before rolling feedback.
    pretrain_history = []
    for epoch in range(1, args.pretrain_epochs + 1):
        if use_physics and epoch == 1:
            initial_scales = estimate_scales(model, physics, train_segments, bundle.scaler, args, device)
        value = train_one_step(model, physics, weighting, optimizer, train_dataset, use_physics, initial_scales, device)
        pretrain_history.append({"epoch": epoch, "one_step_data": value})
    scales = estimate_scales(model, physics, train_segments, bundle.scaler, args, device) if use_physics else initial_scales
    baseline_one = one_step_mse(model, validation_dataset, device)
    best = None; history = []
    print("[{}:{}] regime warm-start complete; baseline_one={} scales={}".format(model_name, regime, baseline_one, scales), flush=True)

    for epoch in range(1, args.rollout_epochs + 1):
        horizon = HORIZONS[min(epoch - 1, len(HORIZONS) - 1)]
        teacher_probability = TEACHER_PROBABILITIES[min(epoch - 1, len(TEACHER_PROBABILITIES) - 1)]
        starts_per_segment = max(8, min(48, args.rollout_steps_per_segment // horizon))
        sums = {"data": 0.0, "dagger": 0.0}; batches = 0
        model.train(); weighting.train()
        for segment_index, segment in enumerate(train_segments):
            starts = starts_for_segment(segment, args.window, horizon, starts_per_segment, args.seed + 1009 * epoch + segment_index)
            for offset in range(0, len(starts), args.batch_starts):
                selected = starts[offset:offset + args.batch_starts]
                optimizer.zero_grad()
                rollout = rollout_batch(model, segment, selected, bundle.scaler, args.window, horizon, device, teacher_probability, args.noise_std)
                data, *_ = component_losses(rollout)
                # DAgger: regenerate detached free-run states, then learn to recover their true next state.
                dagger_x, dagger_y = dagger_features(model, segment, selected, bundle.scaler, args.window, horizon, device)
                dagger_prediction = model(dagger_x.to(device))["prediction"]
                dagger = torch.mean((dagger_prediction - dagger_y.to(device)) ** 2)
                # The primary rollout retains the computation graph, so this term
                # performs true multi-step BPTT. Detached DAgger remains auxiliary.
                combined_data = 0.85 * data + 0.15 * dagger
                if use_physics:
                    mass, energy = recursive_physics_losses(physics, rollout["physics_records"])
                    objective, _ = weighting(combined_data / scales["data"], mass / scales["mass"], energy / scales["energy"])
                    objective = objective + 1e-5 * model.flow_closure.regularization_loss()
                else:
                    objective = combined_data
                bound = torch.mean(torch.relu(-0.05 - rollout["prediction"]) ** 2 + torch.relu(rollout["prediction"] - 1.05) ** 2)
                objective = objective + args.bound_weight * bound
                if not torch.isfinite(objective): raise FloatingPointError("non-finite DAgger objective")
                objective.backward(); torch.nn.utils.clip_grad_norm_(list(model.parameters()) + list(weighting.parameters()), 1.0); optimizer.step()
                sums["data"] += float(data.detach()); sums["dagger"] += float(dagger.detach()); batches += 1

        model.eval(); rollout_values = []
        with torch.no_grad():
            for segment_index, segment in enumerate(validation_segments):
                starts = starts_for_segment(segment, args.window, args.validation_horizon, args.validation_starts, args.seed + segment_index)
                batch = rollout_batch(model, segment, starts, bundle.scaler, args.window, args.validation_horizon, device, 0.0, 0.0)
                rollout_values.append(float(torch.mean((batch["prediction"] - batch["target"]) ** 2)))
        validation_rollout = float(np.mean(rollout_values)); validation_one = one_step_mse(model, validation_dataset, device)
        ratio = validation_one / baseline_one; criterion = validation_rollout + max(0.0, ratio - 1.10)
        row = {"epoch": epoch, "horizon": horizon, "teacher_probability": teacher_probability,
               "starts_per_segment": starts_per_segment, "train_data": sums["data"] / max(batches, 1),
               "train_dagger": sums["dagger"] / max(batches, 1), "validation_rollout": validation_rollout,
               "validation_one_step": validation_one, "one_step_ratio": ratio, "criterion": criterion}
        history.append(row)
        print("[{}:{}] epoch={} H={} p={} val_roll={:.6g} ratio={:.3f}".format(model_name, regime, epoch, horizon, teacher_probability, validation_rollout, ratio), flush=True)
        if best is None or criterion < best["criterion"]:
            best = {"model": {key: value.detach().cpu() for key, value in model.state_dict().items()}, "epoch": epoch,
                    "criterion": criterion, "validation_rollout": validation_rollout, "validation_one_step": validation_one}
            torch.save(best, str(output_dir / "best.pt"))

    model.load_state_dict(best["model"])
    target_n, prediction_n, _, conditions = one_step_predictions_with_metadata(model, test_dataset, device)
    target = target_n * bundle.scaler.scale[2:] + bundle.scaler.minimum[2:]
    prediction = prediction_n * bundle.scaler.scale[2:] + bundle.scaler.minimum[2:]
    roll_tn, roll_pn, _, roll_conditions = rollout_predictions(model, test_segments, bundle.scaler, args.window, device)
    roll_target = roll_tn * bundle.scaler.scale[2:] + bundle.scaler.minimum[2:]
    roll_prediction = roll_pn * bundle.scaler.scale[2:] + bundle.scaler.minimum[2:]
    write_rows(output_dir / "test_metrics.csv", grouped_metric_table(target, prediction, conditions))
    write_rows(output_dir / "rollout_metrics.csv", grouped_metric_table(roll_target, roll_prediction, roll_conditions))
    np.savez_compressed(output_dir / "test_predictions.npz", target=target, prediction=prediction, condition=conditions)
    np.savez_compressed(output_dir / "rollout_predictions.npz", target=roll_target, prediction=roll_prediction, condition=roll_conditions)
    (output_dir / "history.json").write_text(json.dumps({"pretrain": pretrain_history, "rollout": history}, indent=2), encoding="utf-8")
    return {"regime": regime, "model": model_name, "best_epoch": best["epoch"], "validation_rollout": best["validation_rollout"], "validation_one_step": best["validation_one_step"], "kendall_scales": scales}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", default="data/999"); parser.add_argument("--output-root", required=True)
    parser.add_argument("--window", type=int, default=8); parser.add_argument("--pretrain-epochs", type=int, default=3)
    parser.add_argument("--rollout-epochs", type=int, default=10); parser.add_argument("--batch-starts", type=int, default=1)
    parser.add_argument("--rollout-steps-per-segment", type=int, default=256); parser.add_argument("--validation-horizon", type=int, default=256)
    parser.add_argument("--validation-starts", type=int, default=8); parser.add_argument("--noise-std", type=float, default=0.003)
    parser.add_argument("--bound-weight", type=float, default=0.01); parser.add_argument("--learning-rate", type=float, default=1e-5)
    parser.add_argument("--seed", type=int, default=2026); parser.add_argument("--pinn-init", required=True); parser.add_argument("--transformer-init", required=True)
    args = parser.parse_args(); set_seed(args.seed); root = Path(args.output_root); root.mkdir(parents=True, exist_ok=True)
    bundle = build_datasets(args.data_dir, window=args.window, include_test=True)
    summaries = []
    for regime in REGIMES:
        for model_name in ("pinn", "transformer"):
            started = time.time(); result = train_regime(model_name, regime, bundle, root / regime / model_name, args)
            result["elapsed_seconds"] = time.time() - started; summaries.append(result)
    (root / "run_summary.json").write_text(json.dumps(summaries, indent=2), encoding="utf-8")
    write_rows(root / "run_summary.csv", summaries); print(str(root), flush=True)


if __name__ == "__main__": main()
