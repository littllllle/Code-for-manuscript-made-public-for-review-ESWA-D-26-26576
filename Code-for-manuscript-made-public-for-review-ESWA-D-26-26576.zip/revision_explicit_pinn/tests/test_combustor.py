import unittest

import torch

from revision_explicit_pinn.physics import CombustorParameters, combustor_rhs, trapezoidal_residual


class CombustorPhysicsTest(unittest.TestCase):
    def setUp(self):
        self.params = CombustorParameters(
            gas_constant=287.0,
            effective_volume=20.0,
            specific_heat=1100.0,
            lower_heating_value=5.0e7,
            combustion_efficiency=0.99,
        )

    def test_balanced_no_fuel_state_is_stationary(self):
        state = torch.tensor([[1.0e6, 900.0]], dtype=torch.float64)
        flows = torch.tensor([[600.0, 0.0, 600.0]], dtype=torch.float64)
        enthalpy = torch.tensor([[9.0e5, 0.0, 9.0e5]], dtype=torch.float64)
        rhs = combustor_rhs(state, flows, enthalpy, self.params)
        self.assertTrue(torch.allclose(rhs, torch.zeros_like(rhs), atol=1e-12))

    def test_fuel_addition_changes_temperature(self):
        state = torch.tensor([[1.0e6, 900.0]], dtype=torch.float64, requires_grad=True)
        flows = torch.tensor([[600.0, 10.0, 610.0]], dtype=torch.float64)
        enthalpy = torch.tensor([[9.0e5, 0.0, 9.0e5]], dtype=torch.float64)
        rhs = combustor_rhs(state, flows, enthalpy, self.params)
        self.assertGreater(float(rhs[0, 1]), 0.0)
        rhs.sum().backward()
        self.assertIsNotNone(state.grad)
        self.assertTrue(torch.isfinite(state.grad).all())

    def test_trapezoidal_residual_zero_for_linear_step(self):
        now = torch.tensor([[2.0, 3.0]])
        rhs = torch.tensor([[0.5, -0.25]])
        dt = 2.0
        nxt = now + dt * rhs
        residual = trapezoidal_residual(now, nxt, rhs, rhs, dt)
        self.assertTrue(torch.allclose(residual, torch.zeros_like(residual)))


if __name__ == "__main__":
    unittest.main()

