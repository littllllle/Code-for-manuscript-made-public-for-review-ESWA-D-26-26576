import argparse
import csv
import json
from pathlib import Path

import numpy as np
import torch

from revision_explicit_pinn.data import WindowedGasTurbineDataset, build_datasets, second_unit_segments
from revision_explicit_pinn.evaluation import grouped_metric_table, metric_table, one_step_predictions_with_metadata, rollout_predictions
from revision_explicit_pinn.models import BaselineConfig, BaselinePredictor, ExplicitPhysicsPINN, ModelConfig


def write_rows(path, rows):
    with Path(path).open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def build_model(config):
    model_config = config["model"]
    if "model_type" in model_config:
        return BaselinePredictor(BaselineConfig(**model_config))
    return ExplicitPhysicsPINN(ModelConfig(**model_config))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-dir", required=True)
    parser.add_argument("--data-dir", default="data/999")
    parser.add_argument("--second-unit-dir", default="data/second_unit_candidate")
    parser.add_argument("--output-dir", required=True)
    args = parser.parse_args()
    run_dir = Path(args.run_dir)
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    with (run_dir / "run_config.json").open("r", encoding="utf-8") as handle:
        config = json.load(handle)
    window = config["data"]["window"]
    bundle = build_datasets(args.data_dir, window, include_test=True)
    model = build_model(config)
    checkpoint = torch.load(str(run_dir / "best.pt"), map_location="cpu")
    model.load_state_dict(checkpoint["model"])
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model.to(device)

    target_norm, prediction_norm, sources, conditions = one_step_predictions_with_metadata(
        model, bundle.test, device
    )
    target = target_norm * bundle.scaler.scale[2:] + bundle.scaler.minimum[2:]
    prediction = prediction_norm * bundle.scaler.scale[2:] + bundle.scaler.minimum[2:]
    write_rows(output_dir / "first_unit_one_step_by_condition.csv", grouped_metric_table(target, prediction, conditions))
    roll_target_n, roll_prediction_n, roll_sources, roll_conditions = rollout_predictions(
        model, bundle.segments["test"], bundle.scaler, window, device
    )
    roll_target = roll_target_n * bundle.scaler.scale[2:] + bundle.scaler.minimum[2:]
    roll_prediction = roll_prediction_n * bundle.scaler.scale[2:] + bundle.scaler.minimum[2:]
    write_rows(output_dir / "first_unit_rollout_by_condition.csv", grouped_metric_table(roll_target, roll_prediction, roll_conditions))

    second_segments = second_unit_segments(args.second_unit_dir)
    second_dataset = WindowedGasTurbineDataset(second_segments, bundle.scaler, window)
    second_target_n, second_prediction_n, second_sources, second_conditions = one_step_predictions_with_metadata(
        model, second_dataset, device
    )
    second_target = second_target_n * bundle.scaler.scale[2:] + bundle.scaler.minimum[2:]
    second_prediction = second_prediction_n * bundle.scaler.scale[2:] + bundle.scaler.minimum[2:]
    write_rows(output_dir / "second_unit_zero_shot_one_step.csv", grouped_metric_table(second_target, second_prediction, second_conditions))
    second_roll_tn, second_roll_pn, _, second_roll_conditions = rollout_predictions(
        model, second_segments, bundle.scaler, window, device
    )
    second_roll_target = second_roll_tn * bundle.scaler.scale[2:] + bundle.scaler.minimum[2:]
    second_roll_prediction = second_roll_pn * bundle.scaler.scale[2:] + bundle.scaler.minimum[2:]
    write_rows(output_dir / "second_unit_zero_shot_rollout.csv", grouped_metric_table(second_roll_target, second_roll_prediction, second_roll_conditions))
    np.savez_compressed(
        str(output_dir / "evaluation_predictions.npz"),
        first_target=target, first_prediction=prediction, first_condition=conditions,
        second_target=second_target, second_prediction=second_prediction, second_condition=second_conditions,
    )
    print(str(output_dir))


if __name__ == "__main__":
    main()

