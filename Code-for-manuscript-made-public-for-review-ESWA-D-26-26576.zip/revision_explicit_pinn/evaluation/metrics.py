import numpy as np

from revision_explicit_pinn.data.schema import OUTPUT_NAMES


def metric_table(target, prediction, epsilon=1e-8):
    target = np.asarray(target, dtype=np.float64)
    prediction = np.asarray(prediction, dtype=np.float64)
    if target.shape != prediction.shape or target.ndim != 2:
        raise ValueError("target and prediction must be equal two-dimensional arrays")
    rows = []
    for index, name in enumerate(OUTPUT_NAMES):
        truth = target[:, index]
        estimate = prediction[:, index]
        error = estimate - truth
        mse = float(np.mean(error ** 2))
        rmse = float(np.sqrt(mse))
        mae = float(np.mean(np.abs(error)))
        valid = np.abs(truth) > epsilon
        mape = float(np.mean(np.abs(error[valid] / truth[valid])) * 100.0) if valid.any() else np.nan
        denominator = float(np.sum((truth - np.mean(truth)) ** 2))
        r2 = float(1.0 - np.sum(error ** 2) / denominator) if denominator > epsilon else np.nan
        # Avoid numpy.linalg here: the legacy CUDA environment links a second
        # Intel OpenMP runtime when LAPACK is initialized after PyTorch.
        fit_denominator = float(np.sqrt(np.sum((truth - np.mean(truth)) ** 2)))
        error_norm = float(np.sqrt(np.sum(error ** 2)))
        fit_score = float(100.0 * (1.0 - error_norm / fit_denominator)) if fit_denominator > epsilon else np.nan
        rows.append(
            {"output": name, "MSE": mse, "RMSE": rmse, "MAE": mae, "MAPE_percent": mape, "R2": r2, "fit_score_percent": fit_score}
        )
    return rows


def grouped_metric_table(target, prediction, groups, group_name="condition"):
    target = np.asarray(target)
    prediction = np.asarray(prediction)
    groups = np.asarray(groups)
    if len(groups) != len(target):
        raise ValueError("Group labels must align with target rows")
    rows = []
    for group in sorted(set(groups.tolist())):
        mask = groups == group
        for row in metric_table(target[mask], prediction[mask]):
            row[group_name] = group
            row["samples"] = int(mask.sum())
            rows.append(row)
    return rows
