from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


OUTPUTS = ["P_c", "n", "W_e", "T_e", "G_NOx"]
CONDITIONS = ["startup", "load_change", "shutdown"]
LABELS = {"startup": "Startup", "load_change": "Load change", "shutdown": "Shutdown"}
COLORS = {"pinn": "#C43C39", "transformer": "#276FBF"}


def normalized_recursive(root: Path, phase: str) -> pd.DataFrame:
    scaler = json.loads((root / "pinn" / "run_config.json").read_text(encoding="utf-8"))["scaler"]
    ranges = dict(zip(OUTPUTS, np.asarray(scaler["maximum"][2:]) - np.asarray(scaler["minimum"][2:])))
    parts = []
    for model in ("pinn", "transformer"):
        frame = pd.read_csv(root / model / "fixed_horizon_metrics.csv")
        frame = frame[frame.condition.isin(CONDITIONS)].copy()
        frame["model"] = model
        frame["normalized_MSE"] = frame.apply(lambda row: row.MSE / ranges[row.output] ** 2, axis=1)
        parts.append(frame)
    data = pd.concat(parts, ignore_index=True)
    result = data.groupby(["condition", "model", "horizon"], as_index=False).agg(
        normalized_MSE=("normalized_MSE", "mean")
    )
    result["normalized_RMSE"] = np.sqrt(result.pop("normalized_MSE"))
    result["phase"] = phase
    return result


def one_step(root: Path, phase: str) -> pd.DataFrame:
    parts = []
    for model in ("pinn", "transformer"):
        frame = pd.read_csv(root / model / "test_metrics.csv")
        frame["model"] = model
        frame["phase"] = phase
        parts.append(frame)
    return pd.concat(parts, ignore_index=True)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--baseline", type=Path, required=True)
    parser.add_argument("--finetuned", type=Path, required=True)
    args = parser.parse_args()
    baseline = args.baseline.resolve()
    finetuned = args.finetuned.resolve()
    report = finetuned / "report"
    report.mkdir(parents=True, exist_ok=True)

    recursive = pd.concat(
        [normalized_recursive(baseline, "single_step"), normalized_recursive(finetuned, "recursive_finetune")],
        ignore_index=True,
    )
    wide = recursive.pivot(
        index=["condition", "model", "horizon"], columns="phase", values="normalized_RMSE"
    ).reset_index()
    wide["finetune_improvement_percent"] = (
        (wide["single_step"] - wide["recursive_finetune"]) / wide["single_step"] * 100.0
    )
    wide.to_csv(report / "table_recursive_finetune_effect.csv", index=False)

    single = pd.concat([one_step(baseline, "single_step"), one_step(finetuned, "recursive_finetune")])
    one_wide = single.pivot(index=["model", "output"], columns="phase", values="RMSE").reset_index()
    one_wide["finetune_improvement_percent"] = (
        (one_wide["single_step"] - one_wide["recursive_finetune"]) / one_wide["single_step"] * 100.0
    )
    one_wide.to_csv(report / "table_one_step_finetune_effect.csv", index=False)

    plt.rcParams.update({"font.family": "Times New Roman", "font.size": 11, "axes.grid": True, "grid.alpha": 0.2})
    fig, axes = plt.subplots(1, 3, figsize=(12.5, 3.5), sharey=True, constrained_layout=True)
    for axis, condition in zip(axes, CONDITIONS):
        for model in ("pinn", "transformer"):
            for phase, linestyle, marker in (("single_step", "--", "o"), ("recursive_finetune", "-", "s")):
                subset = recursive[
                    (recursive.condition == condition) & (recursive.model == model) & (recursive.phase == phase)
                ].sort_values("horizon")
                axis.plot(
                    subset.horizon,
                    subset.normalized_RMSE,
                    color=COLORS[model],
                    linestyle=linestyle,
                    marker=marker,
                    linewidth=1.4,
                    markersize=4,
                    label=f"{model.upper()} {'fine-tuned' if phase == 'recursive_finetune' else 'single-step'}",
                )
        axis.set_title(LABELS[condition])
        axis.set_xlabel("Horizon")
        axis.set_xticks([10, 20, 40, 80])
    axes[0].set_ylabel("Pooled normalized RMSE")
    axes[0].legend(frameon=False, fontsize=8)
    fig.savefig(report / "figure_recursive_finetune_effect.png", dpi=300, bbox_inches="tight")
    plt.close(fig)
    print(f"Wrote fine-tuning comparison to {report}")


if __name__ == "__main__":
    main()
