# Complete public code package

This folder is a copy of the current `03_代码` directory, including the explicit PINN implementation, training/evaluation code, plotting and reproduction scripts. Generated Python bytecode caches are excluded.
