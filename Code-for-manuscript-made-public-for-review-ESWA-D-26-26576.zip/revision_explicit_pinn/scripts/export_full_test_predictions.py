import argparse
import csv
import json
from pathlib import Path

import numpy as np
import torch

from revision_explicit_pinn.data import build_datasets
from revision_explicit_pinn.evaluation import (
    grouped_metric_table,
    one_step_predictions_with_metadata,
    rollout_predictions,
)
from revision_explicit_pinn.scripts.evaluate_checkpoint import build_model, write_rows


def write_long(path, target, prediction, sources, conditions):
    fields = ["sample_index", "source", "condition", "output_index", "target", "prediction", "error"]
    with Path(path).open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for sample_index in range(len(target)):
            for output_index in range(target.shape[1]):
                actual = float(target[sample_index, output_index])
                estimate = float(prediction[sample_index, output_index])
                writer.writerow({
                    "sample_index": sample_index,
                    "source": sources[sample_index],
                    "condition": conditions[sample_index],
                    "output_index": output_index,
                    "target": actual,
                    "prediction": estimate,
                    "error": estimate - actual,
                })


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-dir", required=True)
    parser.add_argument("--data-dir", required=True)
    parser.add_argument("--output-dir", required=True)
    args = parser.parse_args()
    run_dir = Path(args.run_dir)
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    with (run_dir / "run_config.json").open("r", encoding="utf-8") as handle:
        config = json.load(handle)
    window = int(config["data"]["window"])
    bundle = build_datasets(args.data_dir, window, include_test=True)
    model = build_model(config)
    checkpoint = torch.load(str(run_dir / "best.pt"), map_location="cpu")
    model.load_state_dict(checkpoint["model"])
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model.to(device)

    target_n, prediction_n, sources, conditions = one_step_predictions_with_metadata(model, bundle.test, device)
    target = target_n * bundle.scaler.scale[2:] + bundle.scaler.minimum[2:]
    prediction = prediction_n * bundle.scaler.scale[2:] + bundle.scaler.minimum[2:]
    write_long(output_dir / "one_step_full.csv", target, prediction, sources, conditions)
    write_rows(output_dir / "one_step_metrics_by_condition.csv", grouped_metric_table(target, prediction, conditions))

    roll_tn, roll_pn, roll_sources, roll_conditions = rollout_predictions(
        model, bundle.segments["test"], bundle.scaler, window, device
    )
    roll_target = roll_tn * bundle.scaler.scale[2:] + bundle.scaler.minimum[2:]
    roll_prediction = roll_pn * bundle.scaler.scale[2:] + bundle.scaler.minimum[2:]
    write_long(output_dir / "rollout_full.csv", roll_target, roll_prediction, roll_sources, roll_conditions)
    write_rows(
        output_dir / "rollout_metrics_by_condition.csv",
        grouped_metric_table(roll_target, roll_prediction, roll_conditions),
    )
    expected = len(bundle.test) * target.shape[1]
    audit = {
        "window": window,
        "test_samples": len(bundle.test),
        "outputs": int(target.shape[1]),
        "one_step_rows": int(target.size),
        "rollout_rows": int(roll_target.size),
        "expected_rows": int(expected),
        "one_step_complete": bool(target.size == expected),
        "rollout_complete": bool(roll_target.size == expected),
        "device": str(device),
    }
    with (output_dir / "full_test_audit.json").open("w", encoding="utf-8") as handle:
        json.dump(audit, handle, indent=2)
    if not audit["one_step_complete"] or not audit["rollout_complete"]:
        raise RuntimeError("Full-test row count audit failed")
    print(json.dumps(audit, indent=2))


if __name__ == "__main__":
    main()
