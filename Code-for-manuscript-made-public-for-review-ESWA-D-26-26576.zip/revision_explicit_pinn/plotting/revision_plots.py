from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

from revision_explicit_pinn.data.schema import OUTPUT_NAMES, UNITS
from revision_explicit_pinn.plotting.paper_style import apply_paper_style, save_figure


def plot_prediction(target, prediction, output_path, title="One-step prediction"):
    apply_paper_style()
    target = np.asarray(target)
    prediction = np.asarray(prediction)
    figure, axes = plt.subplots(5, 1, figsize=(7.2, 8.6), sharex=True, constrained_layout=True)
    for index, (axis, name) in enumerate(zip(axes, OUTPUT_NAMES)):
        axis.plot(target[:, index], color="#777777", linestyle="--", linewidth=1.0, label="Measured")
        axis.plot(prediction[:, index], color="#1f77b4", linewidth=1.0, label="Predicted")
        axis.set_ylabel("{}\n({})".format(name, UNITS[name]))
        axis.grid(True, alpha=0.2)
    axes[0].legend(loc="best", ncol=2)
    axes[0].set_title(title)
    axes[-1].set_xlabel("Sample")
    save_figure(figure, output_path)
    plt.close(figure)


def plot_training_history(history, output_path):
    apply_paper_style()
    epochs = [row["epoch"] for row in history]
    figure, axes = plt.subplots(2, 1, figsize=(6.8, 5.6), sharex=True, constrained_layout=True)
    for split, style in (("train", "-"), ("validation", "--")):
        axes[0].plot(epochs, [row[split + "_data"] for row in history], style, label=split.capitalize())
    for name, color in (("data", "#1f77b4"), ("mass", "#d62728"), ("energy", "#2ca02c")):
        axes[1].plot(epochs, [row["train_weight_" + name] for row in history], color=color, label=name)
    axes[0].set_ylabel("Normalized MSE")
    axes[1].set_ylabel("Effective weight")
    axes[1].set_xlabel("Epoch")
    axes[0].set_yscale("log")
    axes[0].legend(loc="best")
    axes[1].legend(loc="best", ncol=3)
    save_figure(figure, output_path)
    plt.close(figure)

