from .multitask import KendallTaskWeighting, StaticTaskWeighting
from .physics_loss import PhysicsLoss, PhysicsRuntimeConfig

__all__ = ["KendallTaskWeighting", "StaticTaskWeighting", "PhysicsLoss", "PhysicsRuntimeConfig"]

