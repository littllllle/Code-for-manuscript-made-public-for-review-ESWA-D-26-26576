"""Refresh primary figures with the established reference style.

Only the data source is changed to the completed window-4 archive. Figure
geometry, fonts, palette, line styles, panel labels, and legend placement
follow build_final_simulation_figures.py from replot_20260831.
"""
from __future__ import annotations

import json
import math
import re
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import numpy as np
import pandas as pd

PACKAGE = Path(__file__).resolve().parents[3]
RESULTS = PACKAGE / "04_图表与CSV结果"
PRIMARY = RESULTS / "primary_window4_20260907"
FIG = PACKAGE / "01_手稿" / "figures_revision"
REFERENCE_STYLE = PACKAGE.parent / "03_代码" / "plotting_参照"
sys.path.insert(0, str(REFERENCE_STYLE))
from paper_plot_style import apply_paper_style, format_axis, panel_label  # noqa: E402

SEEDS = (2026, 2027, 2028, 2029, 2030)
MODELS = ("lstm", "tcn", "kan", "transformer", "tk_pinn")
LABELS = {"lstm": "LSTM", "tcn": "TCN", "kan": "KAN", "transformer": "Transformer", "tk_pinn": "TK-PINN"}
COLORS = {"lstm": "#3F8F72", "tcn": "#6F4AA8", "kan": "#D18F3B", "transformer": "#1F5A7A", "tk_pinn": "#C1121F"}
LINESTYLES = {
    "lstm": (0, (5.0, 2.2)),
    "tcn": (0, (1.2, 1.7)),
    "kan": (0, (7.0, 2.0, 1.4, 2.0)),
    "transformer": (0, (3.0, 1.5)),
    "tk_pinn": (0, (6.0, 1.25)),
}
CONDITIONS = ("startup", "load_change", "shutdown")
CONDITION_LABELS = {"startup": "Startup", "load_change": "Load change", "shutdown": "Shutdown"}
OUTPUTS = ("P_c", "n", "W_e", "T_e", "G_NOx")
OUTPUT_LABELS = (
    r"$P_c$ (kg$\cdot$cm$^{-2}$)", r"$n$ (r$\cdot$min$^{-1}$)", r"$W_e$ (MW)",
    r"$T_e$ ($^{\circ}$C)", r"$G_{NOx}$ (mg$\!\cdot\!$Nm$^{-3}$)",
)
OUTPUT_SHORT = (r"$P_c$", r"$n$", r"$W_e$", r"$T_e$", r"$G_{NOx}$")
MEASURED_COLOR = "#202020"
MEASURED_STYLE = "-"
MEASURED_WIDTH = 0.72
BASELINE_WIDTH = 0.78
PINN_WIDTH = 1.18
SINGLE_TRAJECTORY_SIZE = (3.55, 5.35)


def save(fig, stem):
    FIG.mkdir(parents=True, exist_ok=True)
    path = FIG / stem
    fig.savefig(path, dpi=600, bbox_inches="tight", facecolor="white")
    fig.savefig(path.with_suffix(".pdf"), bbox_inches="tight", facecolor="white")
    plt.close(fig)


def style_axes(axes):
    for axis in np.asarray(axes, dtype=object).ravel():
        format_axis(axis)
        axis.grid(False)


def model_legend(include_measured=True):
    handles = []
    if include_measured:
        handles.append(Line2D([0], [0], color=MEASURED_COLOR, ls=MEASURED_STYLE,
                              lw=MEASURED_WIDTH, alpha=0.78, label="Measured"))
    handles.extend(
        Line2D([0], [0], color=COLORS[m], ls=LINESTYLES[m],
               lw=PINN_WIDTH if m == "tk_pinn" else BASELINE_WIDTH,
               alpha=1.0 if m == "tk_pinn" else 0.82, label=LABELS[m])
        for m in MODELS
    )
    return handles


def plot_trajectory_axis(axis, x, measured, predictions):
    axis.plot(x, measured, color=MEASURED_COLOR, ls=MEASURED_STYLE,
              lw=MEASURED_WIDTH, alpha=0.76, zorder=1)
    for layer, model in enumerate(MODELS, start=3):
        axis.plot(x, predictions[model], color=COLORS[model], ls=LINESTYLES[model],
                  lw=PINN_WIDTH if model == "tk_pinn" else BASELINE_WIDTH,
                  alpha=1.0 if model == "tk_pinn" else 0.80,
                  zorder=9 if model == "tk_pinn" else layer)
    final_index = max(int(len(x) - 1), 1)
    axis.set_xlim(0, final_index)
    raw_step = max(final_index / 4.0, 1.0)
    magnitude = 10.0 ** math.floor(math.log10(raw_step))
    normalized = raw_step / magnitude
    multiplier = next(value for value in (1.0, 2.0, 5.0, 10.0) if normalized <= value)
    tick_step = max(int(multiplier * magnitude), 1)
    axis.set_xticks(np.arange(0, final_index + 1, tick_step, dtype=int))
    axis.margins(x=0)


def one_step_path(model, seed):
    return PRIMARY / f"{model}_seed{seed}" / "test_predictions.csv"


def plot_one_step(number, condition):
    paths = [one_step_path(model, 2027) for model in MODELS]
    frames = {model: pd.read_csv(path) for model, path in zip(MODELS, paths)}
    fig, axes = plt.subplots(5, 1, figsize=SINGLE_TRAJECTORY_SIZE, sharex=True)
    for output_index, axis in enumerate(axes):
        ref = frames["tk_pinn"]
        part = ref[(ref.condition == condition) & (ref.output_index == output_index)].sort_values("sample_index")
        x = np.arange(len(part))
        predictions = {}
        for model in MODELS:
            subset = frames[model][(frames[model].condition == condition) &
                                   (frames[model].output_index == output_index)].sort_values("sample_index")
            if len(subset) != len(part):
                raise RuntimeError(f"Unequal lengths in Fig. {number}: {model}, {condition}, output {output_index}")
            predictions[model] = subset.prediction.to_numpy()
        plot_trajectory_axis(axis, x, part.target.to_numpy(), predictions)
        axis.set_ylabel(OUTPUT_LABELS[output_index])
        if output_index < 4:
            axis.tick_params(labelbottom=False)
    axes[-1].set_xlabel("Time (s)")
    style_axes(axes)
    fig.legend(handles=model_legend(), loc="upper center", ncol=3, bbox_to_anchor=(0.5, 0.998),
               fontsize=6.9, handlelength=2.4, columnspacing=0.85, handletextpad=0.35)
    fig.subplots_adjust(left=0.205, right=0.985, bottom=0.078, top=0.905, hspace=0.13)
    save(fig, {"startup": "Fig08_one_step_startup", "load_change": "Fig09_one_step_load_change", "shutdown": "Fig10_one_step_shutdown"}[condition] + ".png")


def training_ranges():
    config = json.loads((PRIMARY / "tk_pinn_seed2027" / "run_config.json").read_text(encoding="utf-8"))
    return np.asarray(config["scaler"]["maximum"], float)[2:] - np.asarray(config["scaler"]["minimum"], float)[2:]


def plot_boxplots():
    ranges = training_ranges()
    values = {(condition, model): [] for condition in CONDITIONS for model in MODELS}
    for model in MODELS:
        for seed in SEEDS:
            frame = pd.read_csv(one_step_path(model, seed))
            for condition in CONDITIONS:
                for oi in range(5):
                    part = frame[(frame.condition == condition) & (frame.output_index == oi)]
                    values[(condition, model)].extend(
                        (np.abs(part.prediction - part.target) / ranges[oi] * 100.0).tolist()
                    )
    fig, axes = plt.subplots(1, 3, figsize=(7.2, 2.85), sharey=True)
    for ci, (condition, axis) in enumerate(zip(CONDITIONS, axes)):
        data = [np.asarray(values[(condition, model)]) for model in MODELS]
        box = axis.boxplot(data, showfliers=False, whis=1.5, patch_artist=True,
                           medianprops={"color": "#111111", "linewidth": 0.9})
        for patch, model in zip(box["boxes"], MODELS):
            patch.set_facecolor(COLORS[model]); patch.set_alpha(0.78); patch.set_edgecolor("#333333")
        axis.set_xticks(range(1, 6), [LABELS[m] for m in MODELS], rotation=32, ha="right")
        axis.set_title(CONDITION_LABELS[condition])
        panel_label(axis, ci, y=-0.44)
    axes[0].set_ylabel("Normalized absolute error (%)")
    style_axes(axes)
    fig.subplots_adjust(left=0.09, right=0.99, bottom=0.29, top=0.9, wspace=0.18)
    save(fig, "Fig11_one_step_error_boxplots.png")


def plot_radar():
    summary = pd.read_csv(PRIMARY / "aggregated" / "primary_window4_metrics_mean_sd.csv")
    angles = np.linspace(0, 2 * np.pi, 5, endpoint=False)
    closed = np.r_[angles, angles[0]]
    fig, axes = plt.subplots(1, 3, figsize=(7.2, 2.75), subplot_kw={"projection": "polar"})
    for ci, (condition, axis) in enumerate(zip(CONDITIONS, axes)):
        part = summary[summary.condition == condition]
        best = part.groupby("output").RMSE_mean.min()
        for model in MODELS:
            model_part = part[part.model == model].set_index("output")
            scores = np.array([best[o] / model_part.loc[o, "RMSE_mean"] for o in OUTPUTS])
            axis.plot(closed, np.r_[scores, scores[0]], color=COLORS[model], ls=LINESTYLES[model], lw=1.05)
        axis.set_xticks(angles, OUTPUT_SHORT)
        axis.set_ylim(0, 1.04)
        axis.set_yticks((0.25, 0.5, 0.75, 1.0), ("", "0.50", "", "1.00"), fontsize=7.5)
        axis.set_title("")
        panel_label(axis, ci, y=-0.28)
    fig.legend(handles=model_legend(False), loc="upper center", ncol=5, bbox_to_anchor=(0.5, 1.02), fontsize=8.3)
    fig.subplots_adjust(left=0.035, right=0.97, bottom=0.12, top=0.79, wspace=0.45)
    save(fig, "Fig12_one_step_relative_rmse_radar.png")


def plot_window_screen():
    progress = pd.read_csv(RESULTS / "baseline_window_validation_20260907" / "validation_grid_progress.csv")
    # Preserve both the raw validation losses and the within-model scaling used
    # for the visual comparison, so the selection can be independently audited.
    progress = progress.copy()
    progress["relative_validation_loss"] = progress.groupby("model")["validation_data_loss"].transform(
        lambda values: values / values.min()
    )
    progress.to_csv(RESULTS / "baseline_window_validation_20260907" / "validation_grid_relative_loss.csv", index=False)
    fig, axis = plt.subplots(figsize=(3.45, 2.65))
    for model in MODELS:
        part = progress[progress.model == model].sort_values("window")
        relative_loss = part.relative_validation_loss
        axis.plot(part.window, relative_loss, marker="o", ms=3.5,
                  color=COLORS[model], lw=1.1, label=LABELS[model])
        selected = part.loc[part.validation_data_loss.idxmin()]
        axis.scatter([selected.window], [1.0], s=34,
                     facecolors="white", edgecolors=COLORS[model], linewidths=0.9, zorder=5)
    axis.axvline(4, color="#555555", lw=0.8, ls=":")
    axis.text(4.3, 0.96, r"Selected $S_l=4$", transform=axis.get_xaxis_transform(),
              va="top", fontsize=7.5)
    axis.set_xlabel(r"Window length $S_l$")
    axis.set_ylabel("Loss relative to model minimum")
    axis.set_xticks((2, 4, 8, 16, 30))
    axis.legend(fontsize=6.4, loc="best", ncol=2)
    style_axes([axis])
    fig.subplots_adjust(left=0.17, right=0.98, bottom=0.18, top=0.96)
    save(fig, "Fig06_validation_window_sensitivity.png")


def main():
    apply_paper_style()
    plot_window_screen()
    plot_one_step(8, "startup")
    plot_one_step(9, "load_change")
    plot_one_step(10, "shutdown")
    plot_boxplots()
    plot_radar()
    print("Refreshed Fig. 6 and Fig. 8--12 with reference style and window-4 data.")


if __name__ == "__main__":
    main()
