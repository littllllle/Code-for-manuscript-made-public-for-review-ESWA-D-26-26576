import numpy as np


def add_training_scale_gaussian_noise(features, level, seed):
    """Add zero-mean noise in normalized feature space; level is train-range fraction."""
    if level < 0:
        raise ValueError("Noise level must be non-negative")
    generator = np.random.RandomState(seed)
    return np.asarray(features) + generator.normal(0.0, level, size=np.asarray(features).shape)

