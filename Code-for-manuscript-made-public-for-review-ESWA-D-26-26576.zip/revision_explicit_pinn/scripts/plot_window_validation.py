"""Plot validation-only context screening for the final manuscript."""
import argparse
import csv
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from revision_explicit_pinn.plotting.paper_style import apply_paper_style, style_axes


LABELS = {
    "lstm": "LSTM",
    "tcn": "TCN",
    "kan": "KAN",
    "transformer": "Transformer",
    "tk_pinn": "TK-PINN",
}
COLORS = {
    "lstm": "#1f77b4",
    "tcn": "#2ca02c",
    "kan": "#9467bd",
    "transformer": "#ff7f0e",
    "tk_pinn": "#d62728",
}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--csv", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    rows = []
    with Path(args.csv).open(newline="", encoding="utf-8") as handle:
        for row in csv.DictReader(handle):
            if row["status"] == "completed":
                row["window"] = int(row["window"])
                row["validation_data_loss"] = float(row["validation_data_loss"])
                rows.append(row)

    apply_paper_style(font_size=9)
    fig, ax = plt.subplots(figsize=(6.35, 3.85))
    for model in LABELS:
        subset = sorted((r for r in rows if r["model"] == model), key=lambda r: r["window"])
        if not subset:
            continue
        x = [r["window"] for r in subset]
        y = [r["validation_data_loss"] for r in subset]
        best = min(subset, key=lambda r: r["validation_data_loss"])
        ax.plot(x, y, marker="o", markersize=4, color=COLORS[model], label=LABELS[model])
        ax.scatter([best["window"]], [best["validation_data_loss"]], s=58,
                   facecolors="white", edgecolors=COLORS[model], linewidths=1.4, zorder=4)
    ax.set_yscale("log")
    ax.set_xticks([2, 4, 8, 16, 30])
    ax.set_xlabel(r"Temporal context length $S_l$")
    ax.set_ylabel("Validation observation loss")
    ax.set_xlim(1.2, 30.8)
    style_axes(ax, grid=True)
    ax.legend(ncol=3, frameon=False, loc="upper center", bbox_to_anchor=(0.5, 1.19),
              columnspacing=1.2, handlelength=1.8)
    fig.tight_layout(pad=0.6)
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output, dpi=600, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print(output)


if __name__ == "__main__":
    main()
