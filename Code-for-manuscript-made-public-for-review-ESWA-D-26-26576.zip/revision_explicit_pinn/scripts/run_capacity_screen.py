"""Validation-only capacity/window screen for the Kendall PINN.

The screen never loads test data. It is deliberately separate from the final
paired comparison so the selected configuration can be frozen before testing.
"""
import argparse
import csv
import gc
import json
import time
from pathlib import Path

import torch

from revision_explicit_pinn.data import build_datasets
from revision_explicit_pinn.models import ExplicitPhysicsPINN, ModelConfig
from revision_explicit_pinn.training import TrainConfig, Trainer, set_seed


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", required=True)
    parser.add_argument("--output-root", required=True)
    parser.add_argument("--epochs", type=int, default=50)
    parser.add_argument("--patience", type=int, default=50)
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--seeds", nargs="+", type=int, default=[2026, 2027, 2028])
    parser.add_argument("--windows", nargs="+", type=int, default=[4, 8, 12, 16, 24])
    parser.add_argument("--d-models", nargs="+", type=int, default=[32, 48, 64])
    args = parser.parse_args()
    root = Path(args.output_root)
    root.mkdir(parents=True, exist_ok=True)
    progress = root / "capacity_progress.csv"
    fields = ["run_id", "window", "d_model", "batch_size", "seed", "status", "best_epoch", "validation_data_loss", "validation_mass", "validation_energy", "elapsed_seconds", "error"]
    rows = []
    configs = [(window, d_model, seed) for window in args.windows for d_model in args.d_models for seed in args.seeds]
    for index, (window, d_model, seed) in enumerate(configs, 1):
        run_id = "w{}_d{}_b{}_s{}".format(window, d_model, args.batch_size, seed)
        run_dir = root / run_id
        summary_path = run_dir / "summary.json"
        if summary_path.exists():
            saved = json.loads(summary_path.read_text(encoding="utf-8"))
            rows.append({key: saved.get(key, "") for key in fields})
            print("[capacity {}/{}] skipped {}".format(index, len(configs), run_id), flush=True)
            continue
        started = time.time()
        try:
            set_seed(seed)
            bundle = build_datasets(args.data_dir, window=window, include_test=False)
            model = ExplicitPhysicsPINN(ModelConfig(
                d_model=d_model, nhead=4, encoder_layers=2,
                feedforward_dim=2 * d_model, max_window=max(30, window), closure="kan",
            ))
            trainer = Trainer(model, bundle, run_dir, TrainConfig(
                epochs=args.epochs, patience=args.patience, batch_size=args.batch_size,
                learning_rate=1e-4, weighting="kendall", use_physics=True,
                seed=seed, static_mass_weight=0.01, static_energy_weight=0.001,
            ))
            checkpoint = trainer.fit()
            best_row = min((row for row in trainer.history if row["epoch"] == checkpoint["epoch"]), key=lambda row: row["validation_data"])
            summary = {
                "run_id": run_id, "window": window, "d_model": d_model,
                "batch_size": args.batch_size, "seed": seed, "status": "completed",
                "best_epoch": checkpoint["epoch"], "validation_data_loss": best_row["validation_data"],
                "validation_mass": best_row["validation_mass"], "validation_energy": best_row["validation_energy"],
                "elapsed_seconds": time.time() - started, "test_evaluated": False,
            }
            summary_path.write_text(json.dumps(summary, indent=2), encoding="utf-8")
            rows.append({key: summary.get(key, "") for key in fields})
            print("[capacity {}/{}] {} val={:.6g} mass={:.4g} energy={:.4g}".format(index, len(configs), run_id, summary["validation_data_loss"], summary["validation_mass"], summary["validation_energy"]), flush=True)
        except Exception as exc:
            summary = {"run_id": run_id, "window": window, "d_model": d_model, "batch_size": args.batch_size, "seed": seed, "status": "failed", "best_epoch": "", "validation_data_loss": "", "validation_mass": "", "validation_energy": "", "elapsed_seconds": time.time() - started, "error": "{}: {}".format(type(exc).__name__, exc)}
            rows.append({key: summary.get(key, "") for key in fields})
            print("[capacity {}/{}] FAILED {} {}".format(index, len(configs), run_id, summary["error"]), flush=True)
        with progress.open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=fields)
            writer.writeheader()
            writer.writerows(rows)
        gc.collect()
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
    completed = [row for row in rows if row["status"] == "completed"]
    # Select by validation data loss subject to a conservative physical gate.
    feasible = [row for row in completed if float(row["validation_mass"]) < 20.0 and float(row["validation_energy"]) < 20.0]
    selected_pool = feasible or completed
    selected = min(selected_pool, key=lambda row: float(row["validation_data_loss"]))
    (root / "selected_config.json").write_text(json.dumps({"selection_rule": "validation data loss with mass/energy < 20 gate", "selected": selected, "feasible_count": len(feasible), "total_completed": len(completed)}, indent=2), encoding="utf-8")
    print(json.dumps({"selected": selected, "feasible_count": len(feasible), "total_completed": len(completed)}, indent=2), flush=True)


if __name__ == "__main__":
    main()
