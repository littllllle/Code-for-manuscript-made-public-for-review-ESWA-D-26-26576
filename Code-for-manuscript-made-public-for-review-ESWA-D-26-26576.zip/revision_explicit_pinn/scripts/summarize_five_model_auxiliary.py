"""Aggregate audited five-model auxiliary inference into long and mean/std CSVs."""
from pathlib import Path
import argparse
import json
from typing import List

import pandas as pd


MODELS = ("lstm", "tcn", "kan", "transformer", "pinn")
SEEDS = (2026, 2027, 2028, 2029, 2030)
METRICS = ("MSE", "RMSE", "MAE", "MAPE_percent", "R2", "fit_score_percent")


def collect(root: Path, filename: str) -> pd.DataFrame:
    frames = []
    for model in MODELS:
        for seed in SEEDS:
            path = root / f"{model}_seed{seed}" / filename
            frame = pd.read_csv(path)
            frame.insert(0, "seed", seed)
            frame.insert(0, "model", model)
            frames.append(frame)
    return pd.concat(frames, ignore_index=True)


def aggregate(frame: pd.DataFrame, groups: List[str]) -> pd.DataFrame:
    named = {}
    for metric in METRICS:
        named[f"{metric}_mean"] = (metric, "mean")
        named[f"{metric}_std"] = (metric, "std")
    named["n_seeds"] = ("seed", "nunique")
    return frame.groupby(groups, as_index=False).agg(**named)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    args = parser.parse_args()
    noise = collect(args.root, "noise_metrics_by_condition.csv")
    transfer = collect(args.root, "second_unit_zero_shot_one_step.csv")
    noise.to_csv(args.root / "noise_five_model_five_seed_long.csv", index=False)
    transfer.to_csv(args.root / "second_unit_five_model_five_seed_long.csv", index=False)
    noise_summary = aggregate(noise, ["model", "condition", "output", "noise_level"])
    transfer_summary = aggregate(transfer, ["model", "condition", "output"])
    noise_summary.to_csv(args.root / "noise_five_model_mean_std.csv", index=False)
    transfer_summary.to_csv(args.root / "second_unit_five_model_mean_std.csv", index=False)
    audit = {"status": "complete", "models": list(MODELS), "seeds": list(SEEDS),
             "noise_long_rows": len(noise), "noise_summary_rows": len(noise_summary),
             "second_unit_long_rows": len(transfer), "second_unit_summary_rows": len(transfer_summary),
             "all_groups_have_five_seeds": bool((noise_summary.n_seeds.eq(5).all() and transfer_summary.n_seeds.eq(5).all()))}
    (args.root / "summary_audit.json").write_text(json.dumps(audit, indent=2), encoding="utf-8")
    print(json.dumps(audit, indent=2))


if __name__ == "__main__":
    main()
