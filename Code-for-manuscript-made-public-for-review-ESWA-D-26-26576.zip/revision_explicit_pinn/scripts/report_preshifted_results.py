from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


OUTPUTS = ["P_c", "n", "W_e", "T_e", "G_NOx"]
CONDITIONS = ["startup", "load_change", "shutdown"]
CONDITION_LABELS = {
    "startup": "Startup",
    "load_change": "Load change",
    "shutdown": "Shutdown",
}
COLORS = {"pinn": "#C43C39", "transformer": "#276FBF"}
LABELS = {"pinn": "PINN-KAN", "transformer": "Transformer"}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Report corrected pre-shifted experiments")
    parser.add_argument("--root", type=Path, required=True)
    return parser.parse_args()


def configure_plotting() -> None:
    plt.rcParams.update(
        {
            "font.family": "Times New Roman",
            "font.size": 10,
            "mathtext.fontset": "stix",
            "axes.linewidth": 0.8,
            "axes.grid": True,
            "grid.alpha": 0.2,
            "grid.linewidth": 0.6,
            "savefig.dpi": 300,
        }
    )


def load_metrics(root: Path) -> tuple[pd.DataFrame, pd.DataFrame]:
    one_step_parts = []
    horizon_parts = []
    for model in ("pinn", "transformer"):
        one = pd.read_csv(root / model / "test_metrics.csv")
        one.insert(0, "model", model)
        one_step_parts.append(one)
        horizon_parts.append(pd.read_csv(root / model / "fixed_horizon_metrics.csv"))
    return pd.concat(one_step_parts, ignore_index=True), pd.concat(horizon_parts, ignore_index=True)


def build_tables(
    root: Path, report_dir: Path, one: pd.DataFrame, horizon: pd.DataFrame
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    wide_one = one.pivot(index="output", columns="model", values=["RMSE", "MAE", "R2"])
    wide_one.columns = [f"{metric}_{model}" for metric, model in wide_one.columns]
    wide_one = wide_one.reset_index()
    wide_one["RMSE_improvement_percent"] = (
        (wide_one["RMSE_transformer"] - wide_one["RMSE_pinn"])
        / wide_one["RMSE_transformer"]
        * 100.0
    )
    wide_one.to_csv(report_dir / "table_one_step_comparison.csv", index=False)

    grouped = (
        horizon[horizon["condition"].isin(CONDITIONS)]
        .groupby(["condition", "model", "horizon", "output"], as_index=False)
        .agg(
            pooled_MSE=("MSE", "mean"),
            mean_MAE_across_leads=("MAE", "mean"),
            mean_R2_across_leads=("R2", "mean"),
        )
    )
    grouped["pooled_RMSE_across_leads"] = np.sqrt(grouped.pop("pooled_MSE"))
    endpoint = horizon[horizon["condition"].isin(CONDITIONS)].copy()
    endpoint = endpoint[endpoint["lead"] == endpoint["horizon"]][
        ["condition", "model", "horizon", "output", "RMSE", "MAE", "R2"]
    ].rename(columns={"RMSE": "endpoint_RMSE", "MAE": "endpoint_MAE", "R2": "endpoint_R2"})
    summary = grouped.merge(endpoint, on=["condition", "model", "horizon", "output"])
    summary.to_csv(report_dir / "table_fixed_horizon_summary.csv", index=False)

    paired = summary.pivot(
        index=["condition", "horizon", "output"],
        columns="model",
        values=["pooled_RMSE_across_leads", "endpoint_RMSE"],
    )
    paired.columns = [f"{metric}_{model}" for metric, model in paired.columns]
    paired = paired.reset_index()
    for metric in ("pooled_RMSE_across_leads", "endpoint_RMSE"):
        paired[f"{metric}_improvement_percent"] = (
            (paired[f"{metric}_transformer"] - paired[f"{metric}_pinn"])
            / paired[f"{metric}_transformer"]
            * 100.0
        )
    paired.to_csv(report_dir / "table_pinn_vs_transformer_horizons.csv", index=False)

    scaler = json.loads((root / "pinn" / "run_config.json").read_text(encoding="utf-8"))["scaler"]
    ranges = dict(zip(OUTPUTS, np.asarray(scaler["maximum"][2:]) - np.asarray(scaler["minimum"][2:])))
    normalized = horizon[horizon["condition"].isin(CONDITIONS)].copy()
    normalized["normalized_MSE"] = normalized.apply(
        lambda row: row.MSE / (ranges[row.output] ** 2), axis=1
    )
    normalized_summary = (
        normalized.groupby(["condition", "model", "horizon"], as_index=False)
        .agg(pooled_normalized_MSE=("normalized_MSE", "mean"))
    )
    normalized_summary["pooled_normalized_RMSE"] = np.sqrt(
        normalized_summary.pop("pooled_normalized_MSE")
    )
    normalized_endpoint = normalized[normalized.lead == normalized.horizon].groupby(
        ["condition", "model", "horizon"], as_index=False
    ).agg(endpoint_normalized_MSE=("normalized_MSE", "mean"))
    normalized_endpoint["endpoint_normalized_RMSE"] = np.sqrt(
        normalized_endpoint.pop("endpoint_normalized_MSE")
    )
    normalized_summary = normalized_summary.merge(
        normalized_endpoint, on=["condition", "model", "horizon"]
    )
    normalized_wide = normalized_summary.pivot(
        index=["condition", "horizon"],
        columns="model",
        values=["pooled_normalized_RMSE", "endpoint_normalized_RMSE"],
    )
    normalized_wide.columns = [f"{metric}_{model}" for metric, model in normalized_wide.columns]
    normalized_wide = normalized_wide.reset_index()
    for metric in ("pooled_normalized_RMSE", "endpoint_normalized_RMSE"):
        normalized_wide[f"{metric}_improvement_percent"] = (
            (normalized_wide[f"{metric}_transformer"] - normalized_wide[f"{metric}_pinn"])
            / normalized_wide[f"{metric}_transformer"]
            * 100.0
        )
    normalized_wide.to_csv(report_dir / "table_normalized_recursive_summary.csv", index=False)
    return wide_one, paired, normalized_wide


def plot_one_step(report_dir: Path, one: pd.DataFrame) -> None:
    fig, axes = plt.subplots(1, 5, figsize=(12.5, 2.8), constrained_layout=True)
    for axis, output in zip(axes, OUTPUTS):
        values = [float(one[(one.model == model) & (one.output == output)].RMSE.iloc[0]) for model in ("pinn", "transformer")]
        axis.bar([0, 1], values, color=[COLORS["pinn"], COLORS["transformer"]], width=0.62)
        axis.set_xticks([0, 1], ["PINN-KAN", "Transformer"], rotation=20)
        axis.set_title(output)
        axis.set_ylabel("RMSE")
        axis.grid(axis="x", visible=False)
    fig.savefig(report_dir / "figure_one_step_rmse.png", bbox_inches="tight")
    plt.close(fig)


def plot_lead_rmse(report_dir: Path, horizon: pd.DataFrame) -> None:
    data = horizon[(horizon.horizon == 80) & horizon.condition.isin(CONDITIONS)]
    fig, axes = plt.subplots(3, 5, figsize=(13.5, 8.0), sharex=True, constrained_layout=True)
    for row, condition in enumerate(CONDITIONS):
        for col, output in enumerate(OUTPUTS):
            axis = axes[row, col]
            for model in ("pinn", "transformer"):
                subset = data[(data.condition == condition) & (data.output == output) & (data.model == model)]
                axis.plot(subset.lead, subset.RMSE, color=COLORS[model], linewidth=1.35, label=LABELS[model])
            if row == 0:
                axis.set_title(output)
            if col == 0:
                axis.set_ylabel(f"{CONDITION_LABELS[condition]}\nRMSE")
            if row == 2:
                axis.set_xlabel("Recursive lead")
    axes[0, 0].legend(frameon=False, fontsize=9)
    fig.savefig(report_dir / "figure_h80_rmse_by_lead_and_condition.png", bbox_inches="tight")
    plt.close(fig)


def plot_normalized_accumulation(root: Path, report_dir: Path) -> None:
    scaler = json.loads((root / "pinn" / "run_config.json").read_text(encoding="utf-8"))["scaler"]
    output_ranges = np.asarray(scaler["maximum"][2:]) - np.asarray(scaler["minimum"][2:])
    archives = {
        model: np.load(root / model / "recursive_predictions_h80.npz", allow_pickle=True)
        for model in ("pinn", "transformer")
    }
    fig, axes = plt.subplots(1, 3, figsize=(11.5, 3.2), sharey=True, constrained_layout=True)
    for axis, condition in zip(axes, CONDITIONS):
        for model, archive in archives.items():
            mask = archive["condition"] == condition
            normalized_error = (archive["prediction"][mask] - archive["target"][mask]) / output_ranges
            lead_nrmse = np.sqrt(np.mean(normalized_error**2, axis=(0, 2)))
            axis.plot(np.arange(1, 81), lead_nrmse, color=COLORS[model], linewidth=1.5, label=LABELS[model])
        axis.set_title(CONDITION_LABELS[condition])
        axis.set_xlabel("Recursive lead")
    axes[0].set_ylabel("Aggregate normalized RMSE")
    axes[0].legend(frameon=False)
    fig.savefig(report_dir / "figure_h80_normalized_error_accumulation.png", bbox_inches="tight")
    plt.close(fig)


def plot_midpoint_origins(root: Path, report_dir: Path) -> dict[str, int]:
    archives = {
        model: np.load(root / model / "recursive_predictions_h80.npz", allow_pickle=True)
        for model in ("pinn", "transformer")
    }
    selected: dict[str, int] = {}
    reference = archives["pinn"]
    for condition in CONDITIONS:
        condition_indices = np.flatnonzero(reference["condition"] == condition)
        index = int(condition_indices[len(condition_indices) // 2])
        selected[condition] = int(reference["origin"][index])
        fig, axes = plt.subplots(5, 1, figsize=(11.5, 9.5), sharex=True, constrained_layout=True)
        lead = np.arange(1, 81)
        for output_index, (axis, output) in enumerate(zip(axes, OUTPUTS)):
            axis.plot(lead, reference["target"][index, :, output_index], color="#111111", linewidth=1.4, label="Measured")
            for model, archive in archives.items():
                model_index = np.flatnonzero(
                    (archive["condition"] == condition) & (archive["origin"] == selected[condition])
                )[0]
                axis.plot(
                    lead,
                    archive["prediction"][model_index, :, output_index],
                    color=COLORS[model],
                    linewidth=1.15,
                    linestyle="--" if model == "transformer" else "-",
                    label=LABELS[model],
                )
            axis.set_ylabel(output)
        axes[0].legend(ncol=3, frameon=False)
        axes[-1].set_xlabel("Recursive lead")
        fig.savefig(report_dir / f"figure_h80_midpoint_fit_{condition}.png", bbox_inches="tight")
        plt.close(fig)
    return selected


def write_markdown(
    root: Path,
    report_dir: Path,
    one_table: pd.DataFrame,
    paired: pd.DataFrame,
    normalized: pd.DataFrame,
    selected: dict[str, int],
) -> None:
    one_rows = []
    for row in one_table.itertuples(index=False):
        one_rows.append(
            f"| {row.output} | {row.RMSE_pinn:.6g} | {row.RMSE_transformer:.6g} | {row.RMSE_improvement_percent:.2f}% |"
        )
    horizon_overall = (
        paired.groupby("horizon", as_index=False)[
            ["pooled_RMSE_across_leads_improvement_percent", "endpoint_RMSE_improvement_percent"]
        ]
        .mean()
        .sort_values("horizon")
    )
    horizon_rows = [
        f"| {int(row.horizon)} | {row.pooled_RMSE_across_leads_improvement_percent:.2f}% | {row.endpoint_RMSE_improvement_percent:.2f}% |"
        for row in horizon_overall.itertuples(index=False)
    ]
    wins = (
        paired.assign(win=paired["pooled_RMSE_across_leads_improvement_percent"] > 0)
        .groupby(["condition", "horizon"], as_index=False)
        .agg(wins=("win", "sum"))
    )
    win_rows = [
        f"| {CONDITION_LABELS[row.condition]} | {int(row.horizon)} | {int(row.wins)}/5 |"
        for row in wins.itertuples(index=False)
    ]
    normalized_rows = [
        f"| {CONDITION_LABELS[row.condition]} | {int(row.horizon)} | "
        f"{row.pooled_normalized_RMSE_pinn:.5f} | {row.pooled_normalized_RMSE_transformer:.5f} | "
        f"{row.pooled_normalized_RMSE_improvement_percent:.2f}% |"
        for row in normalized.itertuples(index=False)
    ]
    text = f"""# 预错位数据修正后的训练与递归测试结果

## 数据语义与实验有效性

- CSV 第 `k` 行直接解释为 `[u(k), y(k-1)]`，输入窗口不再对输出列执行第二次减一错位。
- 窗口末行是 `[u(k), y(k-1)]`，监督目标 `y(k)` 位于 CSV 第 `k+1` 行的输出列。
- 五组训练数据联合训练，验证集按训练序列末段划分；缩放器仅由训练部分拟合。
- 三组测试数据分别对应启动、正常变负荷和停机工况，未参与参数选择。
- 窗口审计违规数为 0。此前采用二次错位的检查点与结果不应写入最终手稿。

## 固定参数

两种模型共享 `window=8, batch_size=32, d_model=64, nhead=4, encoder_layers=2, feedforward_dim=128, dropout=0.1, epochs=50, seed=2026`。PINN-KAN 使用显式质量/能量残差、KAN 闭合项和 Kendall 多任务权重；纯 Transformer 不使用物理损失和 KAN。

## 一步预测

| Output | PINN-KAN RMSE | Transformer RMSE | PINN improvement |
|---|---:|---:|---:|
{chr(10).join(one_rows)}

五个输出的一步 RMSE 均由 PINN-KAN 取得较小值。但这些是同一随机种子的固定参数结果，不能替代多随机种子显著性检验。

## 固定起点递归预测

每个预测起点仅使用该起点之前的真实历史初始化；块内从第 2 步开始递归回填预测输出。未来控制量来自 CSV 中已知的控制轨迹，因此这是“已知未来控制条件下的响应递归预测”，不是无控制信息的完全自主预测。

| Horizon | Mean pooled-RMSE improvement | Mean endpoint-RMSE improvement |
|---:|---:|---:|
{chr(10).join(horizon_rows)}

上表的百分比先在每个“工况-输出”组合内按 `(Transformer-PINN)/Transformer` 计算，再对 15 个组合取算术平均。正值表示 PINN-KAN 更好。

由于五个物理量的单位和量级不同，综合比较还应先按训练集量程归一化：

| Condition | Horizon | PINN-KAN pooled NRMSE | Transformer pooled NRMSE | PINN improvement |
|---|---:|---:|---:|---:|
{chr(10).join(normalized_rows)}

归一化综合指标中 PINN-KAN 在所有工况和步长均较低；这与逐变量表中存在负改进并不矛盾。综合 NRMSE 回答总体误差积累，逐变量表用于暴露具体短板，二者都应保留。

### PINN-KAN 获胜输出数

| Condition | Horizon | Wins |
|---|---:|---:|
{chr(10).join(win_rows)}

递归误差随步长增加，不能据此声称模型在任意长时间尺度上无误差累积。这里验证的是最多 80 步的固定起点递归稳定性，与数千步单起点自由运行不同。

## 图和完整表

- `figure_one_step_rmse.png`：五个输出的一步 RMSE。
- `figure_h80_rmse_by_lead_and_condition.png`：三种工况、五个输出的逐步 RMSE。
- `figure_h80_normalized_error_accumulation.png`：按训练量程归一化后的综合累积误差。
- `figure_h80_midpoint_fit_*.png`：各工况时间中点起点的 80 步拟合，不按误差挑选。起点行号：`{json.dumps(selected, ensure_ascii=False)}`。
- `table_one_step_comparison.csv`、`table_fixed_horizon_summary.csv`、`table_pinn_vs_transformer_horizons.csv` 和 `table_normalized_recursive_summary.csv` 保存完整数值。

## 客观结论边界

本次结果可用于证明：在正确的 CSV 时序语义下，固定参数的一步任务中 PINN-KAN 优于同容量 Transformer，并可进一步用逐工况/逐输出递归指标判断其 10–80 步误差积累优势。最终手稿应按完整表逐项陈述，不能只报告总体均值，也不能把有限步长条件递归预测表述为无限期长期稳定。

结果根目录：`{root}`
"""
    (report_dir / "RESULTS_SUMMARY_CN.md").write_text(text, encoding="utf-8")


def main() -> None:
    args = parse_args()
    root = args.root.resolve()
    report_dir = root / "report"
    report_dir.mkdir(parents=True, exist_ok=True)
    configure_plotting()
    one, horizon = load_metrics(root)
    one_table, paired, normalized = build_tables(root, report_dir, one, horizon)
    plot_one_step(report_dir, one)
    plot_lead_rmse(report_dir, horizon)
    plot_normalized_accumulation(root, report_dir)
    selected = plot_midpoint_origins(root, report_dir)
    write_markdown(root, report_dir, one_table, paired, normalized, selected)
    print(f"Wrote report to {report_dir}")


if __name__ == "__main__":
    main()
