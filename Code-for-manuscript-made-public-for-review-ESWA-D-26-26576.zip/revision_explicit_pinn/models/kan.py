"""Small B-spline KAN used only for named component-flow closures."""

import math

import torch
import torch.nn.functional as functional


class KANLinear(torch.nn.Module):
    def __init__(self, in_features, out_features, grid_size=5, spline_order=3):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.grid_size = grid_size
        self.spline_order = spline_order
        step = 2.0 / grid_size
        grid = (
            torch.arange(-spline_order, grid_size + spline_order + 1, dtype=torch.float32) * step - 1.0
        ).expand(in_features, -1).contiguous()
        self.register_buffer("grid", grid)
        self.base_weight = torch.nn.Parameter(torch.empty(out_features, in_features))
        self.spline_weight = torch.nn.Parameter(
            torch.empty(out_features, in_features, grid_size + spline_order)
        )
        self.spline_scale = torch.nn.Parameter(torch.ones(out_features, in_features))
        torch.nn.init.kaiming_uniform_(self.base_weight, a=math.sqrt(5))
        torch.nn.init.normal_(self.spline_weight, mean=0.0, std=0.02)

    def b_splines(self, values):
        flat = values.reshape(-1, self.in_features).unsqueeze(-1)
        grid = self.grid
        bases = ((flat >= grid[:, :-1]) & (flat < grid[:, 1:])).to(flat.dtype)
        for order in range(1, self.spline_order + 1):
            left = (flat - grid[:, : -(order + 1)]) / (
                grid[:, order:-1] - grid[:, : -(order + 1)]
            )
            right = (grid[:, order + 1 :] - flat) / (
                grid[:, order + 1 :] - grid[:, 1:-order]
            )
            bases = left * bases[:, :, :-1] + right * bases[:, :, 1:]
        return bases.contiguous()

    def forward(self, values):
        return self.edge_contributions(values).sum(dim=-1)

    def edge_contributions(self, values):
        """Return each learnable univariate edge contribution [..., out, in]."""
        original_shape = values.shape
        flat = values.reshape(-1, self.in_features)
        base = functional.silu(flat).unsqueeze(1) * self.base_weight.unsqueeze(0)
        bases = self.b_splines(flat)
        coefficients = self.spline_weight * self.spline_scale.unsqueeze(-1)
        spline = torch.einsum("bik,oik->boi", bases, coefficients)
        return (base + spline).reshape(*original_shape[:-1], self.out_features, self.in_features)

    def regularization_loss(self):
        return self.spline_weight.abs().mean()


class FlowClosureKAN(torch.nn.Module):
    """Operating-point air-flow baseline with bounded KAN corrections.

    The outputs are [air_in, mass_accumulation]. PhysicsLoss constructs
    gas_out = air_in + fuel - mass_accumulation using fuel in physical units.
    """

    def __init__(self, input_dim=7, hidden_dim=12, rated_flow=621.58, upper_factor=1.35):
        super().__init__()
        self.first = KANLinear(input_dim, hidden_dim)
        self.second = KANLinear(hidden_dim, 2)
        self.rated_flow = float(rated_flow)
        self.maximum_flow = float(rated_flow * upper_factor)
        self.air_deviation_fraction = 0.10
        self.accumulation_fraction = 0.02

    def forward(self, normalized_features):
        # KAN grid is [-1,1]; normalized plant features are ordinarily [0,1].
        hidden = self.first(2.0 * normalized_features - 1.0)
        raw = self.second(torch.tanh(hidden))
        speed = torch.clamp(normalized_features[..., 3], 0.0, 1.1)
        igv = torch.clamp(normalized_features[..., 1], 0.0, 1.1)
        baseline = self.rated_flow * (0.15 + 0.85 * speed) * (0.75 + 0.25 * igv)
        air = baseline * (1.0 + self.air_deviation_fraction * torch.tanh(raw[..., 0]))
        accumulation = self.rated_flow * self.accumulation_fraction * torch.tanh(raw[..., 1])
        return torch.stack([air, accumulation], dim=-1)

    def regularization_loss(self):
        return self.first.regularization_loss() + self.second.regularization_loss()
