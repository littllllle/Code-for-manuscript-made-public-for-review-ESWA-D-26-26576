"""Regenerate Figs. 17--19 with the original plotting implementation.

Only the data roots are redirected to the final five-instance archive; the
plotting functions, style, colours, dimensions and labels remain those of
``build_final_simulation_figures.py``.
"""
from __future__ import annotations

import importlib.util
import json
from pathlib import Path


HERE = Path(__file__).resolve()
PACKAGE = HERE.parents[1]
CODE_ROOT = PACKAGE / "03_代码"
ORIGINAL = CODE_ROOT / "build_final_simulation_figures.py"
AB_ROOT = PACKAGE / "04_图表与CSV结果" / "ablation_window4_20260908"
FIG_ROOT = PACKAGE / "01_手稿" / "figures_revision"
TABLE_ROOT = AB_ROOT / "figure_tables"

spec = importlib.util.spec_from_file_location("original_figures", ORIGINAL)
if spec is None or spec.loader is None:
    raise ImportError(ORIGINAL)
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

# Match the manuscript font family for both text and math labels.
for font_path in (r"C:\Windows\Fonts\times.ttf", r"C:\Windows\Fonts\timesbd.ttf",
                  r"C:\Windows\Fonts\timesi.ttf", r"C:\Windows\Fonts\timesbi.ttf"):
    if Path(font_path).exists():
        mod.font_manager.fontManager.addfont(font_path)
mod.apply_paper_style()
mod.plt.rcParams.update({
    "font.family": "Times New Roman",
    "font.serif": ["Times New Roman"],
    "mathtext.fontset": "custom",
    "mathtext.rm": "Times New Roman",
    "mathtext.it": "Times New Roman:italic",
    "mathtext.bf": "Times New Roman:bold",
})

# Keep the original source tree for non-ablation resources (the output-head
# study and the serialized primary scaler), while redirecting final outputs.
mod.PACKAGE = PACKAGE
mod.RESULTS = PACKAGE / "04_图表与CSV结果"
mod.COMPLETE = mod.RESULTS / "complete_code_tests_20260830"
mod.FINAL = mod.RESULTS / "final_simulation_20260831"
mod.OUTPUT_HEAD_ROOT = mod.COMPLETE / "phase9_mimo_miso"
mod.OUT = FIG_ROOT
mod.TABLE_OUT = TABLE_ROOT
mod.OUT.mkdir(parents=True, exist_ok=True)
mod.TABLE_OUT.mkdir(parents=True, exist_ok=True)
mod.MANIFEST.clear()


def ablation_sources(_phase: str, variants: dict):
    """Resolve the original variant labels against the final archive."""
    mapping = {
        None: "full_tk_pinn",
        "kan": "no_physics",
        "physics": "no_kan",
        "equal": "equal_weighting",
        "static": "fixed_weighting",
    }
    paths = {}
    for label, prefix in variants.items():
        variant = mapping[prefix]
        for seed in mod.SEEDS:
            paths[(label, seed)] = AB_ROOT / f"{variant}_seed{seed}" / "test_predictions.csv"
    return mod.SEEDS, "five_instances", paths


mod.ablation_sources = ablation_sources

# The original Kendall panel reads the full-model histories from the primary
# archive.  Its ablation bars are redirected through ``ablation_sources``.
mod.plot_component_ablation()
mod.plot_kendall_weighting()
mod.plot_mimo_miso()

manifest_path = AB_ROOT / "figure_tables" / "ablation_figures_manifest.json"
manifest_path.write_text(json.dumps({"figures": mod.MANIFEST}, indent=2), encoding="utf-8")
print(f"wrote Figs. 17--19 to {FIG_ROOT}")
print(f"wrote figure tables to {TABLE_ROOT}")
