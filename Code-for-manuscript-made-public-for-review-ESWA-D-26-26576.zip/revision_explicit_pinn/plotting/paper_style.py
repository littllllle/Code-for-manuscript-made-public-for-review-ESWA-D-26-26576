from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt


PALETTE = {
    "blue": "#1f77b4",
    "red": "#d62728",
    "green": "#2ca02c",
    "purple": "#9467bd",
    "black": "#111111",
    "gray": "#777777",
}


def apply_paper_style(font_size=10):
    """Apply the shared style distilled from the five reference scripts."""
    plt.rcParams.update(
        {
            "font.family": "Times New Roman",
            "font.size": font_size,
            "mathtext.fontset": "stix",
            "mathtext.default": "regular",
            "axes.labelsize": font_size,
            "axes.titlesize": font_size + 1,
            "legend.fontsize": max(8, font_size - 1),
            "xtick.labelsize": max(8, font_size - 1),
            "ytick.labelsize": max(8, font_size - 1),
            "axes.linewidth": 0.8,
            "lines.linewidth": 1.2,
            "savefig.dpi": 300,
            "figure.dpi": 150,
        }
    )


def style_axes(axis, grid=True):
    if grid:
        axis.grid(alpha=0.2, linewidth=0.6)
    axis.tick_params(direction="in", width=0.8)
    for spine in axis.spines.values():
        spine.set_linewidth(0.8)
    return axis


def save_figure(fig, path, dpi=300):
    output_path = Path(path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(
        str(output_path),
        dpi=dpi,
        bbox_inches="tight",
        facecolor="white",
    )
    plt.close(fig)
    return output_path
