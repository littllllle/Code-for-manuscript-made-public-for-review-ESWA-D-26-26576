"""Fast end-to-end smoke test for the recursive TK-PINN pipeline."""
from pathlib import Path
import json
import csv
import copy

import numpy as np
import torch
from torch.utils.data import DataLoader, Subset

from revision_explicit_pinn.data import build_preshifted_datasets
from revision_explicit_pinn.evaluation import metric_table
from revision_explicit_pinn.models import ExplicitPhysicsPINN, ModelConfig
from revision_explicit_pinn.scripts.train_recursive_finetune import rollout_batch, make_future_arrays
from revision_explicit_pinn.scripts.train_preshifted_horizon import fixed_horizon_rollout
from revision_explicit_pinn.training import TrainConfig, Trainer, set_seed


def write_rows(path, rows):
    with Path(path).open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(rows)


def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", required=True)
    parser.add_argument("--base-dir", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--seed", type=int, default=2026)
    parser.add_argument("--horizon", type=int, default=2)
    args = parser.parse_args()
    set_seed(args.seed)
    output = Path(args.output_dir); output.mkdir(parents=True, exist_ok=True)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    bundle = build_preshifted_datasets(args.data_dir, window=8, include_test=True)
    audits = bundle.train.audit() + bundle.validation.audit() + bundle.test.audit()
    if audits:
        raise RuntimeError("window audit failed: {}".format(audits[:2]))
    base = json.loads((Path(args.base_dir) / "run_config.json").read_text(encoding="utf-8"))["model"]
    model = ExplicitPhysicsPINN(ModelConfig(**base)).to(device)
    trainer = Trainer(model, bundle, output, TrainConfig(epochs=1, batch_size=4, patience=1, seed=args.seed))
    checkpoint = torch.load(str(Path(args.base_dir) / "best.pt"), map_location=device)
    model.load_state_dict(checkpoint["model"])
    trainer.weighting.load_state_dict(checkpoint["weighting"])
    loader = DataLoader(Subset(bundle.train, list(range(min(4, len(bundle.train))))), batch_size=4, shuffle=False)
    features, _, metadata = next(iter(loader))
    target_np, control_np = make_future_arrays(metadata, bundle.segments["train"], bundle.scaler, args.horizon)
    future_targets = torch.as_tensor(target_np, device=device)
    future_controls = torch.as_tensor(control_np, device=device)
    optimizer = torch.optim.Adam(list(model.parameters()) + list(trainer.weighting.parameters()), lr=5e-5)
    objective, losses = rollout_batch(model, features.to(device), future_targets, future_controls,
                                      trainer.physics, trainer.weighting, trainer.loss_scales,
                                      True, 1e-5, 0.5, True)
    optimizer.zero_grad(); objective.backward(); optimizer.step()
    if not torch.isfinite(objective):
        raise FloatingPointError("non-finite smoke objective")
    torch.save({"model": copy.deepcopy(model.state_dict()), "weighting": copy.deepcopy(trainer.weighting.state_dict()), "epoch": 1}, output / "best.pt")
    (output / "history.json").write_text(json.dumps([{"epoch": 1, "smoke_objective": float(objective.detach())}], indent=2), encoding="utf-8")
    (output / "run_config.json").write_text(json.dumps({"model": base, "device": str(device), "seed": args.seed, "smoke": True, "horizon": args.horizon}, indent=2), encoding="utf-8")
    for segment in bundle.segments["test"]:
        origins, target, prediction = fixed_horizon_rollout(model, segment, bundle.scaler, 8, args.horizon, device, batch_size=32)
        target = target * bundle.scaler.scale[2:] + bundle.scaler.minimum[2:]
        prediction = prediction * bundle.scaler.scale[2:] + bundle.scaler.minimum[2:]
        write_rows(output / (segment.condition + "_metrics.csv"), metric_table(target[:, -1], prediction[:, -1]))
    print(json.dumps({"status": "PASS", "device": str(device), "train_batch": 4, "horizon": args.horizon, "output": str(output)}, indent=2))


if __name__ == "__main__":
    main()
