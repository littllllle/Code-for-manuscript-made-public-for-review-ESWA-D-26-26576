"""Train on pre-shifted CSVs and evaluate fixed-horizon recursive forecasts."""

import argparse
import csv
import json
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import DataLoader

from revision_explicit_pinn.data import build_preshifted_datasets
from revision_explicit_pinn.evaluation import metric_table, one_step_predictions
from revision_explicit_pinn.models import ExplicitPhysicsPINN, ModelConfig
from revision_explicit_pinn.training import TrainConfig, Trainer, set_seed


HORIZONS = (10, 20, 40, 80)


@torch.no_grad()
def fixed_horizon_rollout(model, segment, scaler, window, horizon, device, batch_size=128):
    """Reset from measured history at every origin, then recursively predict H steps."""
    normalized = scaler.transform(segment.values).astype(np.float32)
    origins = np.arange(window - 1, len(normalized) - horizon, dtype=np.int64)
    targets = np.empty((len(origins), horizon, 5), dtype=np.float32)
    predictions = np.empty_like(targets)
    model.eval()
    for start in range(0, len(origins), batch_size):
        current_origins = origins[start:start + batch_size]
        windows = np.stack(
            [normalized[o - window + 1:o + 1] for o in current_origins], axis=0
        )
        windows = torch.as_tensor(windows, dtype=torch.float32, device=device)
        for lead in range(horizon):
            output = model(windows)["prediction"]
            predictions[start:start + len(current_origins), lead] = output.cpu().numpy()
            target_storage_rows = current_origins + lead + 1
            targets[start:start + len(current_origins), lead] = normalized[target_storage_rows, 2:]
            if lead + 1 < horizon:
                controls = torch.as_tensor(
                    normalized[target_storage_rows, :2], dtype=torch.float32, device=device
                )
                next_tokens = torch.cat([controls, output], dim=-1).unsqueeze(1)
                windows = torch.cat([windows[:, 1:], next_tokens], dim=1)
    return origins, targets, predictions


def write_rows(path, rows):
    with Path(path).open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(rows)


def horizon_metrics(target, prediction, horizon, condition, model_name, output_names):
    rows = []
    for lead in range(horizon):
        for j, name in enumerate(output_names):
            error = prediction[:, lead, j] - target[:, lead, j]
            mse = float(np.mean(error ** 2))
            rmse = float(np.sqrt(mse))
            mae = float(np.mean(np.abs(error)))
            denominator = float(np.sum((target[:, lead, j] - np.mean(target[:, lead, j])) ** 2))
            r2 = 1.0 - float(np.sum(error ** 2)) / denominator if denominator > 1e-12 else float("nan")
            rows.append({"condition": condition, "model": model_name, "horizon": horizon,
                         "lead": lead + 1, "output": name, "MSE": mse, "RMSE": rmse,
                         "MAE": mae, "R2": r2, "samples": int(len(target))})
    return rows


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--model-name", choices=("pinn", "transformer"), required=True)
    parser.add_argument("--window", type=int, default=8)
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--epochs", type=int, default=50)
    parser.add_argument("--patience", type=int, default=50)
    parser.add_argument("--seed", type=int, default=2026)
    parser.add_argument("--d-model", type=int, default=64)
    parser.add_argument("--layers", type=int, default=2)
    parser.add_argument("--decoder-layers", type=int, default=2)
    parser.add_argument("--nhead", type=int, default=4)
    parser.add_argument("--feedforward", type=int, default=128)
    args = parser.parse_args()
    set_seed(args.seed)
    output = Path(args.output_dir); output.mkdir(parents=True, exist_ok=True)
    bundle = build_preshifted_datasets(args.data_dir, window=args.window, include_test=True)
    audits = bundle.train.audit() + bundle.validation.audit() + bundle.test.audit()
    if audits:
        raise RuntimeError("Pre-shifted causal audit failed: {}".format(audits[:3]))
    use_physics = args.model_name == "pinn"
    model = ExplicitPhysicsPINN(ModelConfig(
        d_model=args.d_model, nhead=args.nhead, encoder_layers=args.layers,
        decoder_layers=args.decoder_layers,
        feedforward_dim=args.feedforward, max_window=max(30, args.window),
        closure="kan" if use_physics else "fixed"
    ))
    trainer = Trainer(model, bundle, output, TrainConfig(
        epochs=args.epochs, batch_size=args.batch_size, patience=args.patience,
        learning_rate=1e-4, weighting="kendall" if use_physics else "equal",
        seed=args.seed, use_physics=use_physics,
    ))
    checkpoint = trainer.fit()
    device = trainer.device
    target_norm, prediction_norm = one_step_predictions(model, bundle.test, device, batch_size=256)
    target = target_norm * bundle.scaler.scale[2:] + bundle.scaler.minimum[2:]
    prediction = prediction_norm * bundle.scaler.scale[2:] + bundle.scaler.minimum[2:]
    write_rows(output / "test_metrics.csv", metric_table(target, prediction))
    np.savez_compressed(output / "test_predictions.npz", target=target, prediction=prediction)

    all_rows = []
    for horizon in HORIZONS:
        horizon_target = []; horizon_prediction = []; horizon_conditions = []; horizon_origins = []
        for segment in bundle.segments["test"]:
            origins, truth, pred = fixed_horizon_rollout(
                model, segment, bundle.scaler, args.window, horizon, device
            )
            truth = truth * bundle.scaler.scale[2:] + bundle.scaler.minimum[2:]
            pred = pred * bundle.scaler.scale[2:] + bundle.scaler.minimum[2:]
            horizon_target.append(truth); horizon_prediction.append(pred)
            horizon_conditions.extend([segment.condition] * len(origins))
            horizon_origins.extend(origins.tolist())
            all_rows.extend(horizon_metrics(
                truth, pred, horizon, segment.condition, args.model_name,
                ("P_c", "n", "W_e", "T_e", "G_NOx")
            ))
        target_h = np.concatenate(horizon_target, axis=0)
        prediction_h = np.concatenate(horizon_prediction, axis=0)
        all_rows.extend(horizon_metrics(
            target_h, prediction_h, horizon, "all_test", args.model_name,
            ("P_c", "n", "W_e", "T_e", "G_NOx")
        ))
        if horizon == max(HORIZONS):
            np.savez_compressed(
                output / "recursive_predictions_h80.npz", target=target_h,
                prediction=prediction_h, condition=np.asarray(horizon_conditions),
                origin=np.asarray(horizon_origins),
            )
    write_rows(output / "fixed_horizon_metrics.csv", all_rows)
    summary = {
        "model": args.model_name, "window": args.window, "epochs": args.epochs,
        "best_epoch": checkpoint["epoch"], "train_samples": len(bundle.train),
        "validation_samples": len(bundle.validation), "test_samples": len(bundle.test),
        "window_semantics": "CSV row k=[u(k), y(k-1)], target y(k) is stored row k+1",
        "horizons": list(HORIZONS), "device": str(device), "window_audit_violations": 0,
    }
    (output / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2), flush=True)


if __name__ == "__main__":
    main()
