"""Train final encoder-decoder one-step models, then resume recursive suite."""
from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path


HERE = Path(__file__).resolve()
PACKAGE = HERE.parents[3]
CODE = PACKAGE / next(p.name for p in PACKAGE.iterdir() if p.is_dir() and p.name.startswith("03"))
RESULTS = PACKAGE / next(p.name for p in PACKAGE.iterdir() if p.is_dir() and p.name.startswith("04"))
DATA = CODE / "data" / "999"
TRAIN = CODE / "revision_explicit_pinn" / "scripts" / "train.py"
RECURSIVE_SUITE = CODE / "revision_explicit_pinn" / "scripts" / "run_final_recursive_suite.py"
OUT = RESULTS / "final_simulation_20260831" / "03_one_step_encoder_decoder"
PYTHON = Path(r"D:\Anaconda\envs\PINN-KAN\python.exe")
SEEDS = (2026, 2027, 2028, 2029, 2030)
MODELS = ("transformer", "pinn")


def is_complete(output: Path) -> bool:
    config_path = output / "run_config.json"
    if not ((output / "test_predictions.npz").exists() and (output / "best.pt").exists()
            and config_path.exists()):
        return False
    config = json.loads(config_path.read_text(encoding="utf-8"))
    return config.get("model", {}).get("architecture") == "transformer_encoder_decoder"


def environment():
    env = os.environ.copy()
    env["PYTHONPATH"] = str(CODE) + os.pathsep + env.get("PYTHONPATH", "")
    env_root = PYTHON.parent
    env["PATH"] = (
        str(env_root) + os.pathsep + str(env_root / "Scripts") + os.pathsep
        + str(env_root / "Library" / "bin") + os.pathsep + env.get("PATH", "")
    )
    return env


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    manifest = []
    env = environment()
    for model in MODELS:
        for seed in SEEDS:
            output = OUT / "{}_seed{}".format(model, seed)
            if is_complete(output):
                manifest.append({"model": model, "seed": seed, "status": "already_complete"})
                continue
            command = [
                str(PYTHON), str(TRAIN),
                "--data-dir", str(DATA), "--output-dir", str(output),
                "--window", "8", "--batch-size", "32", "--epochs", "50",
                "--patience", "50", "--learning-rate", "0.0001",
                "--seed", str(seed), "--d-model", "64", "--layers", "2",
                "--decoder-layers", "2", "--nhead", "4", "--feedforward", "128",
                "--model-type", "transformer", "--closure", "kan" if model == "pinn" else "fixed",
                "--weighting", "kendall" if model == "pinn" else "equal",
            ]
            if model == "transformer":
                command.append("--no-physics")
            print("[encoder-decoder one-step] {} seed {}".format(model, seed), flush=True)
            completed = subprocess.run(command, env=env)
            status = "complete" if completed.returncode == 0 and (output / "test_predictions.npz").exists() else "failed"
            manifest.append({"model": model, "seed": seed, "status": status, "output": str(output)})
            (OUT / "run_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
            if status == "failed":
                raise SystemExit("failed: one-step {} seed {}".format(model, seed))
    print("[encoder-decoder] one-step suite complete; resuming finite-horizon suite", flush=True)
    completed = subprocess.run([str(PYTHON), str(RECURSIVE_SUITE)], env=env)
    if completed.returncode != 0:
        raise SystemExit("finite-horizon suite failed with code {}".format(completed.returncode))


if __name__ == "__main__":
    main()
