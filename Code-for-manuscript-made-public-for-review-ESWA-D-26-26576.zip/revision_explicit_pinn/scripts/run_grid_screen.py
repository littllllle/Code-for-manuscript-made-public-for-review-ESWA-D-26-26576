import argparse
import csv
import gc
import json
from pathlib import Path
import time
import traceback

import torch

from revision_explicit_pinn.data import build_datasets
from revision_explicit_pinn.models import ExplicitPhysicsPINN, ModelConfig
from revision_explicit_pinn.training import TrainConfig, Trainer, set_seed


def write_progress(rows, path):
    fields = [
        "run_id", "batch_size", "window", "seed", "status", "best_epoch",
        "validation_data_loss", "elapsed_seconds", "error",
    ]
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", default="data/999")
    parser.add_argument("--config", default="revision_explicit_pinn/configs/grid_search.json")
    parser.add_argument("--output-root", required=True)
    parser.add_argument("--epochs", type=int, default=3)
    parser.add_argument("--patience", type=int, default=3)
    parser.add_argument("--d-model", type=int, default=64)
    parser.add_argument("--layers", type=int, default=2)
    parser.add_argument("--nhead", type=int, default=4)
    parser.add_argument("--feedforward", type=int, default=128)
    parser.add_argument("--train-steps", type=int, default=100)
    parser.add_argument("--validation-steps", type=int, default=50)
    args = parser.parse_args()

    with Path(args.config).open("r", encoding="utf-8") as handle:
        search = json.load(handle)
    output_root = Path(args.output_root)
    output_root.mkdir(parents=True, exist_ok=True)
    progress_path = output_root / "grid_progress.csv"
    rows = []
    total = len(search["batch_sizes"]) * len(search["windows"]) * len(search["seeds"])
    completed = 0
    for batch_size in search["batch_sizes"]:
        for window in search["windows"]:
            for seed in search["seeds"]:
                completed += 1
                run_id = "bs{}_w{}_s{}".format(batch_size, window, seed)
                run_dir = output_root / run_id
                summary_path = run_dir / "summary.json"
                if summary_path.exists():
                    with summary_path.open("r", encoding="utf-8") as handle:
                        summary = json.load(handle)
                    rows.append({
                        "run_id": run_id, "batch_size": batch_size, "window": window,
                        "seed": seed, "status": "completed", "best_epoch": summary["best_epoch"],
                        "validation_data_loss": summary["best_validation_data_loss"],
                        "elapsed_seconds": summary.get("elapsed_seconds", ""), "error": "",
                    })
                    print("[grid {}/{}] {} skipped".format(completed, total, run_id), flush=True)
                    continue
                started = time.time()
                model = None
                bundle = None
                trainer = None
                try:
                    set_seed(seed)
                    bundle = build_datasets(args.data_dir, window, include_test=False)
                    model = ExplicitPhysicsPINN(ModelConfig(
                        d_model=args.d_model, nhead=args.nhead,
                        encoder_layers=args.layers, feedforward_dim=args.feedforward,
                        max_window=max(30, window), closure="kan",
                    ))
                    trainer = Trainer(
                        model, bundle, run_dir,
                        TrainConfig(
                            epochs=args.epochs, batch_size=batch_size, patience=args.patience,
                            weighting="kendall", seed=seed, use_physics=True,
                            max_train_steps_per_epoch=args.train_steps,
                            max_validation_steps=args.validation_steps,
                        ),
                    )
                    checkpoint = trainer.fit()
                    elapsed = time.time() - started
                    summary = {
                        "run_id": run_id,
                        "best_epoch": checkpoint["epoch"],
                        "best_validation_data_loss": checkpoint["validation_data_loss"],
                        "batch_size": batch_size,
                        "window": window,
                        "seed": seed,
                        "epochs_budget": args.epochs,
                        "train_steps_per_epoch": args.train_steps,
                        "validation_steps": args.validation_steps,
                        "elapsed_seconds": elapsed,
                        "test_evaluated": False,
                        "uses_isga": False,
                    }
                    with summary_path.open("w", encoding="utf-8") as handle:
                        json.dump(summary, handle, indent=2)
                    row = {
                        "run_id": run_id, "batch_size": batch_size, "window": window,
                        "seed": seed, "status": "completed", "best_epoch": checkpoint["epoch"],
                        "validation_data_loss": checkpoint["validation_data_loss"],
                        "elapsed_seconds": elapsed, "error": "",
                    }
                    print(
                        "[grid {}/{}] {} validation={:.8g} time={:.1f}s".format(
                            completed, total, run_id, checkpoint["validation_data_loss"], elapsed
                        ), flush=True,
                    )
                except Exception as exc:
                    row = {
                        "run_id": run_id, "batch_size": batch_size, "window": window,
                        "seed": seed, "status": "failed", "best_epoch": "",
                        "validation_data_loss": "", "elapsed_seconds": time.time() - started,
                        "error": "{}: {}".format(type(exc).__name__, exc),
                    }
                    traceback.print_exc()
                rows.append(row)
                write_progress(rows, progress_path)
                del model, bundle, trainer
                gc.collect()
                if torch.cuda.is_available():
                    torch.cuda.empty_cache()
    write_progress(rows, progress_path)
    print("Grid screen finished: {}".format(progress_path), flush=True)


if __name__ == "__main__":
    main()
