"""Run the final five-model finite-horizon recursive suite."""
from __future__ import annotations

import json
import os
import subprocess
import sys
import shutil
from pathlib import Path


HERE = Path(__file__).resolve()
PACKAGE = HERE.parents[3]
CODE = PACKAGE / next(p.name for p in PACKAGE.iterdir() if p.is_dir() and p.name.startswith("03"))
RESULTS = PACKAGE / next(p.name for p in PACKAGE.iterdir() if p.is_dir() and p.name.startswith("04"))
DATA = CODE / "data" / "999"
SCRIPT = CODE / "revision_explicit_pinn" / "scripts" / "train_recursive_finetune.py"
BASE_RESULTS = RESULTS / "complete_code_tests_20260830"
OUT = RESULTS / "final_simulation_20260831" / "04_recursive_finite_horizon"
ENCODER_DECODER_BASES = RESULTS / "final_simulation_20260831" / "03_one_step_encoder_decoder"
ASCII_TCN_ROOT = Path(r"D:\PythonProjects\PINN_code+tex\_final_tcn_runtime")
SEEDS = (2026, 2027, 2028, 2029, 2030)
MODELS = ("lstm", "tcn", "kan", "transformer", "pinn")


def is_complete(output: Path, model: str) -> bool:
    if not (output / "fixed_horizon_metrics.csv").exists():
        return False
    if model not in ("transformer", "pinn"):
        return True
    config_path = output / "run_config.json"
    if not config_path.exists():
        return False
    config = json.loads(config_path.read_text(encoding="utf-8"))
    return config.get("model", {}).get("architecture") == "transformer_encoder_decoder"


def find_base(model: str, seed: int) -> Path:
    if model == "pinn":
        candidates = sorted(ENCODER_DECODER_BASES.glob("pinn_seed*/best.pt"))
    elif model == "transformer":
        candidates = sorted(ENCODER_DECODER_BASES.glob("transformer_seed*/best.pt"))
    else:
        candidates = sorted(BASE_RESULTS.glob("phase10_baselines/{}_seed*/best.pt".format(model)))
    if not candidates:
        raise FileNotFoundError("No base checkpoint for {}".format(model))
    exact = [p for p in candidates if str(seed) in p.parent.name]
    return (exact[0] if exact else candidates[0]).parent


def main():
    python_by_model = {
        "tcn": Path(r"D:\Anaconda\envs\py38\python.exe"),
        "lstm": Path(r"D:\Anaconda\envs\PINN-KAN\python.exe"),
        "kan": Path(r"D:\Anaconda\envs\PINN-KAN\python.exe"),
        "transformer": Path(r"D:\Anaconda\envs\PINN-KAN\python.exe"),
        "pinn": Path(r"D:\Anaconda\envs\PINN-KAN\python.exe"),
    }
    OUT.mkdir(parents=True, exist_ok=True)
    ASCII_TCN_ROOT.mkdir(parents=True, exist_ok=True)
    ascii_data = ASCII_TCN_ROOT / "data"
    if not ascii_data.exists():
        shutil.copytree(DATA, ascii_data)
    ascii_base = ASCII_TCN_ROOT / "base"
    ascii_base.mkdir(exist_ok=True)
    (ascii_base / "run_config.json").write_text(
        json.dumps({"model": {"model_type": "tcn", "input_dim": 7, "output_dim": 5,
                               "hidden_dim": 64, "layers": 2, "dropout": 0.1, "max_window": 30}}, indent=2),
        encoding="utf-8",
    )
    manifest = []
    for model in MODELS:
        for seed in SEEDS:
            output = OUT / "{}_seed{}".format(model, seed)
            if is_complete(output, model):
                manifest.append({"model": model, "seed": seed, "status": "already_complete", "output": str(output)})
                continue
            base = find_base(model, seed)
            run_data = DATA
            run_output = output
            if model == "tcn":
                base = ascii_base
                run_data = ascii_data
                run_output = ASCII_TCN_ROOT / "{}_seed{}".format(model, seed)
                if run_output.exists():
                    shutil.rmtree(run_output)
            command = [
                str(python_by_model[model]), str(SCRIPT),
                "--data-dir", str(run_data), "--base-dir", str(base), "--output-dir", str(run_output),
                "--model-name", model, "--window", "8", "--batch-size", "32",
                "--epochs", "20", "--fine-tune-horizon", "16", "--seed", str(seed),
            ]
            if model == "tcn":
                command.append("--from-scratch")
            env = os.environ.copy()
            env["PYTHONPATH"] = str(CODE) + os.pathsep + env.get("PYTHONPATH", "")
            if model != "tcn":
                env["PATH"] = str(Path(r"D:\Anaconda\envs\PINN-KAN")) + os.pathsep + str(Path(r"D:\Anaconda\envs\PINN-KAN\Scripts")) + os.pathsep + str(Path(r"D:\Anaconda\envs\PINN-KAN\Library\bin")) + os.pathsep + env.get("PATH", "")
            print("[suite] {} seed {}".format(model, seed), flush=True)
            completed = subprocess.run(command, env=env)
            if model == "tcn" and completed.returncode == 0:
                if output.exists():
                    shutil.rmtree(output)
                shutil.copytree(run_output, output)
            status = "complete" if completed.returncode == 0 and (output / "fixed_horizon_metrics.csv").exists() else "failed"
            manifest.append({"model": model, "seed": seed, "status": status, "returncode": completed.returncode, "output": str(output)})
            (OUT / "run_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
            if status == "failed":
                raise SystemExit("failed: {} seed {}".format(model, seed))
    print(json.dumps({"output": str(OUT), "runs": manifest}, indent=2))


if __name__ == "__main__":
    main()
