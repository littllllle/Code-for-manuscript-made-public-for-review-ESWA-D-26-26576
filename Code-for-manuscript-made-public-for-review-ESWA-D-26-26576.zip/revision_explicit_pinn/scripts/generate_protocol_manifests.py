import csv, json, hashlib
from pathlib import Path
import pandas as pd

def main():
    here=Path(__file__).resolve(); package=here.parents[3]; data=package/'03_代码'/'data'/'999'; out=package/'06_参数与数据协议'; out.mkdir(exist_ok=True)
    files=[]
    for p in sorted(data.glob('*.csv')):
        df=pd.read_csv(p); files.append({'file':p.name,'rows':int(len(df)),'columns':int(len(df.columns)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'columns_names':[str(c) for c in df.columns]})
    (out/'environment.json').write_text(json.dumps({'environment':'PINN-KAN','python':'3.7','torch':'1.11.0+cu113','cuda':True},indent=2),encoding='utf-8')
    (out/'data_manifest.json').write_text(json.dumps({'data_dir':str(data),'train_files':[x['file'] for x in files if 'train' in x['file']], 'test_files':[x['file'] for x in files if 'test' in x['file']], 'files':files,'window':8,'pre_shifted_csv':True,'second_shift_forbidden':True},indent=2),encoding='utf-8')
    with (out/'data_protocol_audit.csv').open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=['file','rows','columns','sha256']); w.writeheader(); w.writerows([{k:x[k] for k in w.fieldnames} for x in files])
if __name__=='__main__': main()
