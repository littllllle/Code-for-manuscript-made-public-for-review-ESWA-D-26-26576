"""Authoritative schema for the seven-column PG9351FA records."""

COLUMN_NAMES = ("G_f", "O_IGV", "P_c", "n", "W_e", "T_e", "G_NOx")
INPUT_NAMES = COLUMN_NAMES[:2]
OUTPUT_NAMES = COLUMN_NAMES[2:]
SAMPLING_PERIOD_S = 1.0

UNITS = {
    "G_f": "kg/s",
    "O_IGV": "degree",
    "P_c": "kgf/cm2(g)",
    "n": "r/min",
    "W_e": "MW",
    "T_e": "degree C",
    "G_NOx": "mg/Nm3",
}

FEATURE_NAMES = INPUT_NAMES + tuple("prev_{}".format(name) for name in OUTPUT_NAMES)

# Confirmed by the data owner. All files below belong to the first PG9351FA
# unit; the labels describe operating conditions, not different machines.
FILE_CONDITIONS = {
    "data_train1.csv": "startup",
    "data_train2.csv": "startup",
    "data_train3.csv": "load_change",
    "data_train4.csv": "shutdown",
    "data_train5.csv": "shutdown",
    "data_test_1.csv": "startup",
    "data_test_2.csv": "load_change",
    "data_test_3.csv": "shutdown",
}

SECOND_UNIT_CONDITIONS = {
    "test3升.csv": "load_increase",
    "test2降.csv": "load_decrease",
}


def condition_for_file(filename):
    try:
        return FILE_CONDITIONS[filename]
    except KeyError:
        raise ValueError("No confirmed operating-condition label for {}".format(filename))


def validate_array(values):
    if values.ndim != 2 or values.shape[1] != len(COLUMN_NAMES):
        raise ValueError(
            "Expected a two-dimensional seven-column array ordered as {}, got {}".format(
                COLUMN_NAMES, values.shape
            )
        )
