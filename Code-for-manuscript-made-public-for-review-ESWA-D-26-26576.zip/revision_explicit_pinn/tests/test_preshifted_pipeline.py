import unittest

import numpy as np

from revision_explicit_pinn.data.pipeline import MinMaxScaler, Segment
from revision_explicit_pinn.data.preshifted import PreShiftedWindowedGasTurbineDataset


class PreShiftedPipelineTests(unittest.TestCase):
    def test_csv_shift_is_not_applied_twice(self):
        rows = []
        for k in range(8):
            rows.append([100 + k, 200 + k] + [1000 + 10 * (k - 1) + j for j in range(5)])
        values = np.asarray(rows, dtype=np.float64)
        segment = Segment("synthetic.csv", "startup", "train", 0, len(values), values)
        scaler = MinMaxScaler().fit([values])
        dataset = PreShiftedWindowedGasTurbineDataset([segment], scaler, window=3)

        features, target, metadata = dataset.samples[0]
        np.testing.assert_allclose(features, scaler.transform(values[0:3]).astype(np.float32))
        np.testing.assert_allclose(target, scaler.transform(values[3:4]).astype(np.float32)[0, 2:])
        self.assertEqual(metadata["token_rows"], [0, 1, 2])
        self.assertEqual(metadata["semantic_target_row"], 2)
        self.assertEqual(metadata["target_storage_row"], 3)
        self.assertEqual(dataset.audit(), [])


if __name__ == "__main__":
    unittest.main()
