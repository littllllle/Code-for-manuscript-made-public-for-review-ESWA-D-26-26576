"""Aggregate the final window-4 ablation predictions by condition and output."""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve()
PACKAGE = HERE.parents[3]
ROOT = PACKAGE / "04_图表与CSV结果" / "ablation_window4_20260908"
OUT = ROOT / "aggregated"
VARIANTS = ("full_tk_pinn", "no_physics", "no_kan", "equal_weighting", "fixed_weighting", "separate_scalar")
SEEDS = (2026, 2027, 2028, 2029, 2030)
OUTPUTS = ("P_c", "n", "W_e", "T_e", "G_NOx")
UNITS = {"P_c": "kg·cm^-2", "n": "rpm", "W_e": "MW", "T_e": "°C", "G_NOx": "mg·Nm^-3"}


UNITS = {
    "P_c": "kg\u00b7cm^-2",
    "n": "rpm",
    "W_e": "MW",
    "T_e": "\u00b0C",
    "G_NOx": "mg\u00b7Nm^-3",
}


def metrics(frame: pd.DataFrame) -> list[dict]:
    rows = []
    for condition, group in frame.groupby("condition", sort=True):
        for output_index, output in enumerate(OUTPUTS):
            part = group[group.output_index == output_index]
            target = part.target.to_numpy(dtype=float)
            prediction = part.prediction.to_numpy(dtype=float)
            error = prediction - target
            mse = float(np.mean(error ** 2))
            denominator = float(np.sum((target - target.mean()) ** 2))
            valid = np.abs(target) > 1e-8
            rows.append({
                "condition": condition, "output": output, "unit": UNITS[output],
                "samples": int(len(part)), "MSE": mse, "RMSE": float(np.sqrt(mse)),
                "MAE": float(np.mean(np.abs(error))),
                "MAPE_percent": float(np.mean(np.abs(error[valid] / target[valid])) * 100.0) if valid.any() else np.nan,
                "R2": float(1.0 - np.sum(error ** 2) / denominator) if denominator > 1e-12 else np.nan,
                "fit_score_percent": float(100.0 * (1.0 - np.sqrt(np.sum(error ** 2)) /
                                                    np.sqrt(denominator))) if denominator > 1e-12 else np.nan,
            })
    return rows


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    rows = []
    audit = []
    for variant in VARIANTS:
        for seed in SEEDS:
            run = ROOT / f"{variant}_seed{seed}"
            path = run / "test_predictions.csv"
            if not path.exists():
                raise FileNotFoundError(path)
            frame = pd.read_csv(path)
            if frame.empty or frame.sample_index.nunique() < 8000:
                raise RuntimeError(f"incomplete test set in {run}: {len(frame)} rows")
            for row in metrics(frame):
                row.update({"variant": variant, "seed": seed})
                rows.append(row)
            config = json.loads((run / "run_config.json").read_text(encoding="utf-8"))
            audit.append({"variant": variant, "seed": seed, "window": config["data"]["window"],
                          "epochs": config["train"]["epochs"], "device": config["device"],
                          "architecture": config["model"].get("architecture", ""),
                          "head_factorization": config["model"].get("head_factorization", "joint_vector"),
                          "physics_runtime": json.dumps(config.get("physics_runtime", {}), sort_keys=True),
                          "prediction_rows": int(len(frame)), "status": "complete"})
    long = pd.DataFrame(rows)
    long.to_csv(OUT / "ablation_metrics_long.csv", index=False, encoding="utf-8-sig")
    grouped = long.groupby(["variant", "condition", "output", "unit"], as_index=False)
    summary = grouped.agg(
        MSE_mean=("MSE", "mean"), MSE_sd=("MSE", "std"),
        RMSE_mean=("RMSE", "mean"), RMSE_sd=("RMSE", "std"),
        MAE_mean=("MAE", "mean"), MAE_sd=("MAE", "std"),
        MAPE_mean=("MAPE_percent", "mean"), MAPE_sd=("MAPE_percent", "std"),
        R2_mean=("R2", "mean"), R2_sd=("R2", "std"),
        fit_mean=("fit_score_percent", "mean"), fit_sd=("fit_score_percent", "std"),
        n_instances=("seed", "nunique"),
    )
    summary.to_csv(OUT / "ablation_metrics_mean_sd.csv", index=False, encoding="utf-8-sig")
    pd.DataFrame(audit).to_csv(OUT / "ablation_run_audit.csv", index=False, encoding="utf-8-sig")
    manifest = {"suite": "ablation_window4_20260908", "variants": list(VARIANTS),
                "seeds": list(SEEDS), "window": 4, "epochs": 50,
                "test_policy": "complete chronological test trajectories; no test selection",
                "std_definition": "sample standard deviation across five independent instances",
                "files": [p.name for p in OUT.glob("*.csv")], "status": "complete"}
    (OUT / "ablation_aggregate_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print(f"wrote {len(long)} run-condition-output rows and {len(summary)} mean/std rows", flush=True)


if __name__ == "__main__":
    main()
