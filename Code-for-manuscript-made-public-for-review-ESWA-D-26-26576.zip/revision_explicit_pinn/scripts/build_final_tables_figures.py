import json, shutil, re
from pathlib import Path
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

HERE=Path(__file__).resolve(); PACKAGE=HERE.parents[3]
ROOT=PACKAGE/'04_图表与CSV结果'/'complete_code_tests_20260830'
OUT=ROOT/'figures_and_tables'; FIG=OUT/'figures'; TAB=OUT/'tables'; FIG.mkdir(parents=True,exist_ok=True); TAB.mkdir(parents=True,exist_ok=True)

def main():
    rows=[]
    # Main two models, five seeds, all conditions/outputs, one-step and rollout.
    for d in sorted((ROOT/'phase3_full_evaluation').iterdir()):
        if not d.is_dir(): continue
        model='PINN-KAN' if 'pinn' in d.name else 'Transformer'; seed=int(d.name[4:8])
        for mode,fn in [('one_step','one_step_metrics_by_condition.csv'),('rollout','rollout_metrics_by_condition.csv')]:
            p=d/fn
            if p.exists():
                x=pd.read_csv(p); x['model']=model; x['seed']=seed; x['mode']=mode; rows.append(x)
    # Baseline run summaries (all have full test CSVs).
    for d in sorted((ROOT/'phase10_baselines').iterdir()):
        p=d/'test_metrics.csv'
        if p.exists():
            x=pd.read_csv(p); x['model']=d.name.split('_seed',1)[0].upper(); x['seed']=int(re.search(r'seed(\d+)',d.name).group(1)); x['mode']='one_step'; rows.append(x)
    allm=pd.concat(rows,ignore_index=True)
    allm.to_csv(TAB/'all_results_long.csv',index=False,encoding='utf-8-sig')
    summary=allm.groupby(['model','mode','condition','output'],as_index=False).agg(MSE=('MSE','mean'),RMSE=('RMSE','mean'),MAE=('MAE','mean'),MAPE_percent=('MAPE_percent','mean'),R2=('R2','mean'),seeds=('seed','nunique'))
    summary.to_csv(TAB/'all_results_mean.csv',index=False,encoding='utf-8-sig')
    # Main comparison by condition, pressure output.
    q=summary[(summary.output=='P_c') & (summary.model.isin(['PINN-KAN','Transformer']))]
    pivot=q.pivot_table(index='condition',columns=['model','mode'],values='RMSE')
    pivot.to_csv(TAB/'main_pinn_transformer_rmse_by_condition.csv',encoding='utf-8-sig')
    ax=pivot.plot(kind='bar',figsize=(9,5),rot=20,color=['#1f77b4','#d62728','#6baed6','#ef8a62'])
    ax.set_ylabel('RMSE'); ax.set_xlabel('Test condition'); ax.set_title('PINN-KAN versus Transformer on complete test sets'); ax.grid(axis='y',alpha=.25)
    ax.figure.tight_layout(); ax.figure.savefig(FIG/'main_pinn_transformer_rmse_by_condition.png',dpi=300); plt.close(ax.figure)
    # Noise robustness aggregate.
    n=[]
    for d in sorted((ROOT/'phase8_noise').iterdir()):
        p=d/'noise_metrics_by_condition.csv'
        if p.exists():
            x=pd.read_csv(p); x['model']=d.name.split('_seed',1)[0].upper(); x['seed']=int(re.search(r'seed(\d+)',d.name).group(1)); n.append(x)
    if n:
        nf=pd.concat(n,ignore_index=True); nf.to_csv(TAB/'noise_all_seeds_long.csv',index=False,encoding='utf-8-sig')
        ns=nf.groupby(['model','noise_level'],as_index=False).agg(RMSE=('RMSE','mean'),MAE=('MAE','mean'))
        ns.to_csv(TAB/'noise_mean_all_seeds.csv',index=False,encoding='utf-8-sig')
        fig,ax=plt.subplots(figsize=(7,5))
        for model,g in ns.groupby('model'): ax.plot(g.noise_level*100,g.RMSE,'-o',label=model)
        ax.set_xlabel('Input noise (% training scale)'); ax.set_ylabel('Mean RMSE'); ax.set_title('Noise robustness, complete test sets'); ax.legend(); ax.grid(alpha=.25); fig.tight_layout(); fig.savefig(FIG/'noise_robustness_all_seeds.png',dpi=300); plt.close(fig)
    (OUT/'figure_table_manifest.json').write_text(json.dumps({'tables':[p.name for p in TAB.glob('*')],'figures':[p.name for p in FIG.glob('*')],'test_rows_per_prediction':41855,'conditions':['startup','load_change','shutdown']},indent=2),encoding='utf-8')

if __name__=='__main__': main()
