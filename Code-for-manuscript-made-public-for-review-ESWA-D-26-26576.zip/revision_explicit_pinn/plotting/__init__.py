from .paper_style import PALETTE, apply_paper_style, save_figure, style_axes

__all__ = ["PALETTE", "apply_paper_style", "save_figure", "style_axes"]
