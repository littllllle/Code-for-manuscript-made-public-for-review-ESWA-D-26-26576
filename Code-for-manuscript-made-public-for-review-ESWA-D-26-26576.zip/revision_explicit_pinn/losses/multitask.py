import torch


class StaticTaskWeighting(torch.nn.Module):
    def __init__(self, data_weight=1.0, mass_weight=1.0, energy_weight=1.0):
        super().__init__()
        self.weights = (float(data_weight), float(mass_weight), float(energy_weight))

    def forward(self, data_loss, mass_loss, energy_loss):
        losses = (data_loss, mass_loss, energy_loss)
        total = sum(weight * loss for weight, loss in zip(self.weights, losses))
        return total, {"data": self.weights[0], "mass": self.weights[1], "energy": self.weights[2]}


class KendallTaskWeighting(torch.nn.Module):
    """Task-level homoscedastic uncertainty weighting, initialized to equal weights."""

    def __init__(self):
        super().__init__()
        self.log_variances = torch.nn.Parameter(torch.zeros(3))

    def forward(self, data_loss, mass_loss, energy_loss):
        losses = torch.stack([data_loss, mass_loss, energy_loss])
        weights = 0.5 * torch.exp(-self.log_variances)
        total = torch.sum(weights * losses + 0.5 * self.log_variances)
        names = ("data", "mass", "energy")
        return total, {name: weights[i].detach() for i, name in enumerate(names)}

