import argparse
import csv
import gc
import json
from pathlib import Path
import time

import torch

from revision_explicit_pinn.data import build_datasets
from revision_explicit_pinn.models import BaselineConfig, BaselinePredictor, ExplicitPhysicsPINN, ModelConfig
from revision_explicit_pinn.training import TrainConfig, Trainer, set_seed


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--data-dir", default="data/999")
    parser.add_argument("--output-root", required=True)
    parser.add_argument("--window", type=int, required=True)
    parser.add_argument("--batch-size", type=int, required=True)
    parser.add_argument("--epochs", type=int, default=5)
    parser.add_argument("--train-steps", type=int, default=100)
    parser.add_argument("--validation-steps", type=int, default=50)
    args = parser.parse_args()
    with Path(args.manifest).open("r", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    output_root = Path(args.output_root)
    output_root.mkdir(parents=True, exist_ok=True)
    results = []
    for index, row in enumerate(rows, start=1):
        run_dir = output_root / row["run_id"]
        summary_path = run_dir / "summary.json"
        if summary_path.exists():
            with summary_path.open("r", encoding="utf-8") as handle:
                results.append(json.load(handle))
            continue
        seed = int(row["seed"])
        use_physics = row["use_physics"].lower() == "true"
        set_seed(seed)
        bundle = build_datasets(args.data_dir, args.window, include_test=False)
        if row["model_type"] == "transformer":
            model = ExplicitPhysicsPINN(ModelConfig(closure=row["closure"]))
        else:
            model = BaselinePredictor(BaselineConfig(
                model_type=row["model_type"], hidden_dim=64, layers=2,
            ))
        started = time.time()
        static_weight = 0.1 if row["weighting"] == "static" else 1.0
        trainer = Trainer(
            model, bundle, run_dir,
            TrainConfig(
                epochs=args.epochs, batch_size=args.batch_size, patience=args.epochs,
                weighting=row["weighting"], seed=seed, use_physics=use_physics,
                static_mass_weight=static_weight, static_energy_weight=static_weight,
                max_train_steps_per_epoch=args.train_steps,
                max_validation_steps=args.validation_steps,
            ),
        )
        checkpoint = trainer.fit()
        summary = dict(row)
        summary.update({
            "best_epoch": checkpoint["epoch"],
            "best_validation_data_loss": checkpoint["validation_data_loss"],
            "elapsed_seconds": time.time() - started,
            "test_evaluated": False,
        })
        with summary_path.open("w", encoding="utf-8") as handle:
            json.dump(summary, handle, indent=2)
        results.append(summary)
        print("[ablation {}/{}] {} validation={:.8g}".format(
            index, len(rows), row["run_id"], checkpoint["validation_data_loss"]
        ), flush=True)
        del model, bundle, trainer
        gc.collect()
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
    fields = sorted({key for row in results for key in row})
    with (output_root / "ablation_results.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(results)


if __name__ == "__main__":
    main()
