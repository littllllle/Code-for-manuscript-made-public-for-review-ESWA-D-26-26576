"""Equal-budget validation-only random search for PINN and Transformer.

Both methods see the same sampled architecture configurations. Each method is
selected independently by validation data loss, and test data are never loaded.
Completed run directories are reused so the search can be resumed safely.
"""
import argparse
import csv
import gc
import itertools
import json
import random
import time
from pathlib import Path

import torch

from revision_explicit_pinn.data import build_datasets
from revision_explicit_pinn.models import ExplicitPhysicsPINN, ModelConfig
from revision_explicit_pinn.training import TrainConfig, Trainer, set_seed


WINDOWS = [2, 4, 8, 12, 16, 24, 30]
BATCH_SIZES = [8, 16, 32, 64]
D_MODELS = [32, 48, 64]
LAYERS = [1, 2]
FEEDFORWARD_DIMS = [64, 96, 128]


def sampled_configs(count, sampling_seed):
    population = [
        dict(window=w, batch_size=b, d_model=d, layers=l, feedforward_dim=f)
        for w, b, d, l, f in itertools.product(
            WINDOWS, BATCH_SIZES, D_MODELS, LAYERS, FEEDFORWARD_DIMS
        )
    ]
    rng = random.Random(sampling_seed)
    rng.shuffle(population)
    return population[:count]


def run_id(model_name, index, config, seed):
    return (
        "{}_{:03d}_w{}_b{}_d{}_l{}_f{}_s{}".format(
            model_name, index, config["window"], config["batch_size"],
            config["d_model"], config["layers"], config["feedforward_dim"], seed
        )
    )


def write_progress(path, rows):
    fields = [
        "model", "candidate_index", "run_id", "window", "batch_size",
        "d_model", "layers", "feedforward_dim", "seed", "status",
        "best_epoch", "validation_data_loss", "validation_mass",
        "validation_energy", "elapsed_seconds", "test_evaluated", "error",
    ]
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows([{key: row.get(key, "") for key in fields} for row in rows])


def collect_completed(root):
    rows = []
    for path in sorted(root.glob("*/*/tuning_summary.json")):
        rows.append(json.loads(path.read_text(encoding="utf-8")))
    return rows


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", required=True)
    parser.add_argument("--output-root", required=True)
    parser.add_argument("--models", nargs="+", choices=("pinn", "transformer"), default=["pinn", "transformer"])
    parser.add_argument("--candidate-count", type=int, default=60)
    parser.add_argument("--sampling-seed", type=int, default=20260813)
    parser.add_argument("--training-seed", type=int, default=2026)
    parser.add_argument("--epochs", type=int, default=50)
    parser.add_argument("--patience", type=int, default=50)
    parser.add_argument("--start-index", type=int, default=1)
    parser.add_argument("--end-index", type=int, default=0, help="Inclusive; zero means all candidates")
    parser.add_argument("--manifest-only", action="store_true")
    args = parser.parse_args()

    root = Path(args.output_root)
    root.mkdir(parents=True, exist_ok=True)
    configs = sampled_configs(args.candidate_count, args.sampling_seed)
    manifest = {
        "protocol": "equal-budget validation-only independent tuning",
        "candidate_space_size": len(WINDOWS) * len(BATCH_SIZES) * len(D_MODELS) * len(LAYERS) * len(FEEDFORWARD_DIMS),
        "sampled_candidate_count": len(configs),
        "sampling_seed": args.sampling_seed,
        "training_seed": args.training_seed,
        "epochs": args.epochs,
        "test_data_loaded": False,
        "space": {
            "window": WINDOWS, "batch_size": BATCH_SIZES, "d_model": D_MODELS,
            "encoder_layers": LAYERS, "feedforward_dim": FEEDFORWARD_DIMS,
        },
        "candidates": [dict(candidate_index=i, **cfg) for i, cfg in enumerate(configs, 1)],
    }
    (root / "search_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    if args.manifest_only:
        print(str(root / "search_manifest.json"), flush=True)
        return

    end_index = args.end_index or len(configs)
    rows = []
    for model_name in args.models:
        for index, config in enumerate(configs, 1):
            if index < args.start_index or index > end_index:
                continue
            identifier = run_id(model_name, index, config, args.training_seed)
            run_dir = root / model_name / identifier
            summary_path = run_dir / "tuning_summary.json"
            if summary_path.exists():
                rows.append(json.loads(summary_path.read_text(encoding="utf-8")))
                print("[tuning] skipped {}".format(identifier), flush=True)
                continue
            started = time.time()
            base = dict(
                model=model_name, candidate_index=index, run_id=identifier,
                seed=args.training_seed, test_evaluated=False, **config
            )
            try:
                set_seed(args.training_seed)
                bundle = build_datasets(args.data_dir, window=config["window"], include_test=False)
                use_physics = model_name == "pinn"
                model = ExplicitPhysicsPINN(ModelConfig(
                    d_model=config["d_model"], nhead=4,
                    encoder_layers=config["layers"],
                    feedforward_dim=config["feedforward_dim"],
                    max_window=max(30, config["window"]),
                    closure="kan" if use_physics else "fixed",
                ))
                trainer = Trainer(model, bundle, run_dir, TrainConfig(
                    epochs=args.epochs, patience=args.patience,
                    batch_size=config["batch_size"], learning_rate=1e-4,
                    weighting="kendall" if use_physics else "equal",
                    use_physics=use_physics, seed=args.training_seed,
                ))
                checkpoint = trainer.fit()
                best = next(row for row in trainer.history if row["epoch"] == checkpoint["epoch"])
                summary = dict(
                    base, status="completed", best_epoch=checkpoint["epoch"],
                    validation_data_loss=best["validation_data"],
                    validation_mass=best["validation_mass"],
                    validation_energy=best["validation_energy"],
                    elapsed_seconds=time.time() - started,
                )
                summary_path.write_text(json.dumps(summary, indent=2), encoding="utf-8")
                rows.append(summary)
                print("[tuning] {} val={:.8g}".format(identifier, summary["validation_data_loss"]), flush=True)
            except Exception as exc:
                rows.append(dict(
                    base, status="failed", elapsed_seconds=time.time() - started,
                    error="{}: {}".format(type(exc).__name__, exc),
                ))
                print("[tuning] FAILED {}: {}".format(identifier, exc), flush=True)
            write_progress(root / "tuning_progress.csv", rows)
            gc.collect()
            if torch.cuda.is_available():
                torch.cuda.empty_cache()

    completed = collect_completed(root)
    write_progress(root / "tuning_progress.csv", completed)
    selections = {}
    for model_name in args.models:
        pool = [row for row in completed if row["model"] == model_name]
        if pool:
            selections[model_name] = min(pool, key=lambda row: float(row["validation_data_loss"]))
    (root / "current_selections.json").write_text(json.dumps({
        "selection_metric": "validation_data_loss",
        "test_data_loaded": False,
        "total_completed": len(completed),
        "selections": selections,
    }, indent=2), encoding="utf-8")
    print(json.dumps(selections, indent=2), flush=True)


if __name__ == "__main__":
    main()
