import tempfile
import unittest
from pathlib import Path

import numpy as np

from revision_explicit_pinn.data.pipeline import build_datasets


class DataPipelineTest(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        root = Path(self.temp.name)
        base = np.arange(140 * 7, dtype=np.float64).reshape(140, 7)
        np.savetxt(str(root / "data_train1.csv"), base, delimiter=",")
        np.savetxt(str(root / "data_test_1.csv"), base + 10000.0, delimiter=",")
        self.root = root

    def tearDown(self):
        self.temp.cleanup()

    def test_scaler_uses_training_segment_only(self):
        bundle = build_datasets(self.root, window=4, validation_fraction=0.2, purge=4)
        self.assertLess(float(bundle.scaler.maximum.max()), 10000.0)

    def test_target_output_never_appears_in_inputs(self):
        bundle = build_datasets(self.root, window=4, validation_fraction=0.2, purge=4)
        self.assertEqual(bundle.train.audit(), [])
        features, target, metadata = bundle.train[0]
        self.assertEqual(tuple(features.shape), (4, 7))
        self.assertEqual(tuple(target.shape), (5,))
        self.assertEqual(metadata["previous_output_rows"][-1], metadata["target_row"] - 1)
        self.assertNotIn(metadata["target_row"], metadata["previous_output_rows"])
        self.assertEqual(metadata["token_rows"][-1], metadata["target_row"])

    def test_purge_separates_train_and_validation(self):
        bundle = build_datasets(self.root, window=4, validation_fraction=0.2, purge=4)
        train = bundle.segments["train"][0]
        validation = bundle.segments["validation"][0]
        self.assertGreaterEqual(validation.start - train.stop, 8)

    def test_real_bundle_uses_all_five_training_and_three_test_files(self):
        candidates = [
            Path(__file__).resolve().parents[2] / "data" / "999",
            Path(__file__).resolve().parents[7] / "data" / "999",
        ]
        root = next((candidate for candidate in candidates if candidate.exists()), None)
        if root is None:
            self.skipTest("real data directory is not included in this source checkout")
        bundle = build_datasets(root, window=2)
        self.assertEqual(len(bundle.segments["train"]), 5)
        self.assertEqual(len(bundle.segments["validation"]), 5)
        self.assertEqual(len(bundle.segments["test"]), 3)
        self.assertEqual(
            {segment.condition for segment in bundle.segments["train"]},
            {"startup", "load_change", "shutdown"},
        )

    def test_selection_bundle_does_not_load_test(self):
        candidates = [
            Path(__file__).resolve().parents[2] / "data" / "999",
            Path(__file__).resolve().parents[7] / "data" / "999",
        ]
        root = next((candidate for candidate in candidates if candidate.exists()), None)
        if root is None:
            self.skipTest("real data directory is not included in this source checkout")
        bundle = build_datasets(root, window=2, include_test=False)
        self.assertIsNone(bundle.test)
        self.assertEqual(bundle.segments["test"], [])


if __name__ == "__main__":
    unittest.main()
