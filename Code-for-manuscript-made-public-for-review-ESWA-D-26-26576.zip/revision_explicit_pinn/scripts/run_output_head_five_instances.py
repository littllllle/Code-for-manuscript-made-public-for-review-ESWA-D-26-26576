"""Five-run controlled output-head experiment using the current encoder-decoder trunk."""
from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from torch.utils.data import DataLoader

from revision_explicit_pinn.data import build_preshifted_datasets
from revision_explicit_pinn.evaluation import metric_table
from revision_explicit_pinn.models import UnifiedHybridPINN, UnifiedModelConfig
from revision_explicit_pinn.training import TrainConfig, Trainer, set_seed
from revision_explicit_pinn.scripts.train_preshifted_horizon import (
    HORIZONS, fixed_horizon_rollout, horizon_metrics,
)

DATA = Path(r"D:\PythonProjects\PINN_code+tex\data\999")
OUT = Path(r"D:\PythonProjects\PINN_code+tex\ESWA返修\返修交付包_统一参数框架_20260831\04_图表与CSV结果\complete_code_tests_20260830\phase9_mimo_miso")
SEQUENCES = (2026, 2027, 2028, 2029, 2030)
MODES = ("mimo", "miso")
OUTPUT_NAMES = ("P_c", "n", "W_e", "T_e", "G_NOx")


def write_rows(path: Path, rows: list[dict]) -> None:
    if not rows:
        raise RuntimeError(f"No rows to write: {path}")
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


@torch.no_grad()
def predict_dataset(model, dataset, device):
    targets, predictions = [], []
    for features, target, _ in DataLoader(dataset, batch_size=256, shuffle=False):
        output = model(features.to(device))["prediction"].cpu().numpy()
        targets.append(target.numpy())
        predictions.append(output)
    return np.concatenate(targets), np.concatenate(predictions)


def evaluate_test(model, bundle, mode: str, run: Path, device) -> None:
    target_norm, prediction_norm = predict_dataset(model, bundle.test, device)
    target = target_norm * bundle.scaler.scale[2:] + bundle.scaler.minimum[2:]
    prediction = prediction_norm * bundle.scaler.scale[2:] + bundle.scaler.minimum[2:]
    write_rows(run / "test_metrics.csv", metric_table(target, prediction))
    np.savez_compressed(run / "test_predictions.npz", target=target, prediction=prediction)

    rows = []
    for horizon in HORIZONS:
        all_targets, all_predictions = [], []
        conditions, origins = [], []
        for segment in bundle.segments["test"]:
            origin, target_n, prediction_n = fixed_horizon_rollout(
                model, segment, bundle.scaler, bundle.test.window, horizon, device, batch_size=512
            )
            target_h = target_n * bundle.scaler.scale[2:] + bundle.scaler.minimum[2:]
            prediction_h = prediction_n * bundle.scaler.scale[2:] + bundle.scaler.minimum[2:]
            all_targets.append(target_h)
            all_predictions.append(prediction_h)
            conditions.extend([segment.condition] * len(origin))
            origins.extend(origin.tolist())
            rows.extend(horizon_metrics(target_h, prediction_h, horizon, segment.condition, mode, OUTPUT_NAMES))
        target_h = np.concatenate(all_targets)
        prediction_h = np.concatenate(all_predictions)
        rows.extend(horizon_metrics(target_h, prediction_h, horizon, "all_test", mode, OUTPUT_NAMES))
        if horizon == max(HORIZONS):
            np.savez_compressed(
                run / "recursive_predictions_h80.npz",
                target=target_h,
                prediction=prediction_h,
                condition=np.asarray(conditions),
                origin=np.asarray(origins),
            )
    write_rows(run / "fixed_horizon_metrics.csv", rows)


def train_one(bundle, mode: str, sequence: int) -> dict:
    run = OUT / f"instance{chr(65 + SEQUENCES.index(sequence))}" / mode
    run.mkdir(parents=True, exist_ok=True)
    if (run / "summary.json").exists() and (run / "fixed_horizon_metrics.csv").exists():
        return json.loads((run / "summary.json").read_text(encoding="utf-8"))
    set_seed(sequence)
    model = UnifiedHybridPINN(UnifiedModelConfig(
        d_model=64, nhead=4, encoder_layers=2, decoder_layers=2,
        feedforward_dim=128, max_window=30, closure="kan", head_mode=mode,
    ))
    trainer = Trainer(model, bundle, run, TrainConfig(
        epochs=50, batch_size=32, patience=50, learning_rate=1e-4,
        weighting="kendall", seed=sequence, use_physics=True,
    ), device="cuda")
    best = trainer.fit()
    device = trainer.device
    train_n, train_p = predict_dataset(model, bundle.train, device)
    val_n, val_p = predict_dataset(model, bundle.validation, device)
    evaluate_test(model, bundle, mode, run, device)
    summary = {
        "model": "unified_hybrid_pinn_encoder_decoder",
        "head_mode": mode,
        "instance": chr(65 + SEQUENCES.index(sequence)),
        "initialization_id": sequence,
        "epochs": 50, "window": 8, "batch_size": 32,
        "d_model": 64, "nhead": 4, "encoder_layers": 2,
        "decoder_layers": 2, "feedforward_dim": 128,
        "best_epoch": best["epoch"],
        "train_one_step_mse": float(np.mean((train_n - train_p) ** 2)),
        "validation_one_step_mse": float(np.mean((val_n - val_p) ** 2)),
        "test_samples": len(bundle.test), "horizons": list(HORIZONS),
        "test_used_for_head_selection": False, "window_audit_violations": 0,
        "parameter_count": sum(p.numel() for p in model.parameters()),
        "architecture": "complete_transformer_encoder_decoder",
    }
    (run / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(f"DONE instance={summary['instance']} mode={mode} best_epoch={best['epoch']}", flush=True)
    return summary


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    bundle = build_preshifted_datasets(DATA, window=8, include_test=True)
    audits = bundle.train.audit() + bundle.validation.audit() + bundle.test.audit()
    if audits:
        raise RuntimeError(f"Causal-window audit failed: {audits[:3]}")
    summaries = []
    for sequence in SEQUENCES:
        for mode in MODES:
            print(f"START instance={chr(65 + SEQUENCES.index(sequence))} mode={mode} id={sequence}", flush=True)
            summaries.append(train_one(bundle, mode, sequence))
    write_rows(OUT / "mimo_miso_run_summary_five_instances.csv", summaries)
    frame = pd.DataFrame(summaries)
    frame.groupby("head_mode")["validation_one_step_mse"].agg(["mean", "std"]).reset_index().to_csv(
        OUT / "mimo_miso_validation_mean_std_five_instances.csv", index=False
    )
    decision = {
        "selection_split": "validation",
        "test_used_for_head_selection": False,
        "instances": list(zip(("A", "B", "C", "D", "E"), SEQUENCES)),
        "architecture": "complete_transformer_encoder_decoder",
        "all_heads_test_reported": True,
    }
    (OUT / "mimo_miso_head_selection_five_instances.json").write_text(json.dumps(decision, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
