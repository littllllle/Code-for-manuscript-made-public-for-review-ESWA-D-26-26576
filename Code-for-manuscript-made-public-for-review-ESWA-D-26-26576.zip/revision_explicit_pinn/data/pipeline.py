"""Leakage-resistant loading, scaling, splitting, and causal window construction."""

from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Sequence, Tuple

import torch
import numpy as np
import pandas as pd
from torch.utils.data import Dataset

from .schema import COLUMN_NAMES, SECOND_UNIT_CONDITIONS, condition_for_file, validate_array


@dataclass(frozen=True)
class Segment:
    source: str
    condition: str
    split: str
    start: int
    stop: int
    values: np.ndarray


class MinMaxScaler:
    """Column-wise scaler fitted only from training segments."""

    def __init__(self, epsilon=1e-12):
        self.epsilon = float(epsilon)
        self.minimum = None
        self.maximum = None
        self.scale = None

    def fit(self, arrays):
        values = np.concatenate(list(arrays), axis=0).astype(np.float64, copy=False)
        validate_array(values)
        self.minimum = values.min(axis=0)
        self.maximum = values.max(axis=0)
        self.scale = np.maximum(self.maximum - self.minimum, self.epsilon)
        return self

    def _check_fitted(self):
        if self.scale is None:
            raise RuntimeError("Scaler must be fitted on training data before use")

    def transform(self, values):
        self._check_fitted()
        return (np.asarray(values) - self.minimum) / self.scale

    def inverse_transform(self, values):
        self._check_fitted()
        return np.asarray(values) * self.scale + self.minimum

    def state_dict(self):
        self._check_fitted()
        return {
            "columns": list(COLUMN_NAMES),
            "minimum": self.minimum.tolist(),
            "maximum": self.maximum.tolist(),
        }


def read_csv(path):
    path = Path(path)
    values = pd.read_csv(str(path), header=None).values.astype(np.float64)
    validate_array(values)
    if not np.isfinite(values).all():
        raise ValueError("Non-finite value found in {}".format(path))
    return values


def chronological_train_validation_segments(paths, validation_fraction=0.2, purge=30):
    """Split every source trajectory chronologically and leave a purge on both sides."""
    train_segments = []
    validation_segments = []
    for path in sorted(Path(p) for p in paths):
        values = read_csv(path)
        boundary = int(np.floor(len(values) * (1.0 - validation_fraction)))
        train_stop = boundary - int(purge)
        validation_start = boundary + int(purge)
        if train_stop < 2 or validation_start >= len(values) - 1:
            raise ValueError("Trajectory {} is too short for the requested split/purge".format(path))
        condition = condition_for_file(path.name)
        train_segments.append(Segment(path.name, condition, "train", 0, train_stop, values[:train_stop]))
        validation_segments.append(
            Segment(path.name, condition, "validation", validation_start, len(values), values[validation_start:])
        )
    return train_segments, validation_segments


def complete_test_segments(paths):
    return [
        Segment(Path(path).name, condition_for_file(Path(path).name), "test", 0, len(values), values)
        for path in sorted(Path(p) for p in paths)
        for values in [read_csv(path)]
    ]


class WindowedGasTurbineDataset(Dataset):
    """Construct x=[u(t), y(t-1)] histories and predict y(k).

    The final input token for target time k contains u(k) and y(k-1). It never
    contains y(k). Windows never cross a source trajectory or split boundary.
    """

    def __init__(self, segments, scaler, window):
        if int(window) < 1:
            raise ValueError("window must be positive")
        self.window = int(window)
        self.scaler = scaler
        self.samples = []
        for segment in segments:
            normalized = scaler.transform(segment.values).astype(np.float32)
            for target_local in range(self.window, len(normalized)):
                token_times = np.arange(target_local - self.window + 1, target_local + 1)
                previous_times = token_times - 1
                controls = normalized[token_times, :2]
                previous_outputs = normalized[previous_times, 2:]
                features = np.concatenate([controls, previous_outputs], axis=1)
                target = normalized[target_local, 2:]
                metadata = {
                    "source": segment.source,
                    "condition": segment.condition,
                    "split": segment.split,
                    "target_row": segment.start + target_local,
                    "token_rows": (segment.start + token_times).tolist(),
                    "previous_output_rows": (segment.start + previous_times).tolist(),
                }
                self.samples.append((features, target, metadata))

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, index):
        features, target, metadata = self.samples[index]
        return torch.from_numpy(features), torch.from_numpy(target), metadata

    def audit(self):
        violations = []
        for _, _, metadata in self.samples:
            target_row = metadata["target_row"]
            previous_rows = metadata["previous_output_rows"]
            token_rows = metadata["token_rows"]
            if previous_rows[-1] != target_row - 1:
                violations.append((metadata, "last previous-output row is not k-1"))
            if target_row in previous_rows:
                violations.append((metadata, "target y(k) appears in input outputs"))
            if token_rows[-1] != target_row:
                violations.append((metadata, "last control row is not k"))
        return violations


@dataclass
class DatasetBundle:
    train: WindowedGasTurbineDataset
    validation: WindowedGasTurbineDataset
    test: object
    scaler: MinMaxScaler
    segments: Dict[str, Sequence[Segment]]


def build_datasets(data_dir, window, validation_fraction=0.2, purge=None, include_test=True):
    data_dir = Path(data_dir)
    train_paths = sorted(data_dir.glob("data_train*.csv"))
    test_paths = sorted(data_dir.glob("data_test*.csv"))
    if not train_paths or (include_test and not test_paths):
        raise FileNotFoundError("Expected required train/test CSV files in {}".format(data_dir))
    purge = max(int(window), 1) if purge is None else int(purge)
    train_segments, validation_segments = chronological_train_validation_segments(
        train_paths, validation_fraction=validation_fraction, purge=purge
    )
    test_segments = complete_test_segments(test_paths) if include_test else []
    scaler = MinMaxScaler().fit(segment.values for segment in train_segments)
    return DatasetBundle(
        train=WindowedGasTurbineDataset(train_segments, scaler, window),
        validation=WindowedGasTurbineDataset(validation_segments, scaler, window),
        test=WindowedGasTurbineDataset(test_segments, scaler, window) if include_test else None,
        scaler=scaler,
        segments={"train": train_segments, "validation": validation_segments, "test": test_segments},
    )


def second_unit_segments(data_dir):
    data_dir = Path(data_dir)
    segments = []
    for filename, condition in SECOND_UNIT_CONDITIONS.items():
        path = data_dir / filename
        values = read_csv(path)
        segments.append(Segment(filename, condition, "second_unit", 0, len(values), values))
    return segments
