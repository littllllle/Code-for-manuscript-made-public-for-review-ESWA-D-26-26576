"""Run the final five-model, five-instance one-step suite at the validated window."""
from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path


HERE = Path(__file__).resolve()
PACKAGE = HERE.parents[3]
CODE = PACKAGE / "03_代码"
RESULTS = PACKAGE / "04_图表与CSV结果"
DATA = Path(r"D:\PythonProjects\PINN_code+tex\data\999")
TRAIN = CODE / "revision_explicit_pinn" / "scripts" / "train.py"
PYTHON = Path(r"D:\Anaconda\envs\PINN-KAN\python.exe")
OUT = RESULTS / "primary_window4_20260907"
SEEDS = (2026, 2027, 2028, 2029, 2030)
MODELS = ("lstm", "tcn", "kan", "transformer", "tk_pinn")


def environment():
    env = os.environ.copy()
    env["PYTHONPATH"] = str(CODE) + os.pathsep + env.get("PYTHONPATH", "")
    env_root = PYTHON.parent
    env["PATH"] = os.pathsep.join(
        [str(env_root), str(env_root / "Scripts"), str(env_root / "Library" / "bin"), env.get("PATH", "")]
    )
    return env


def is_complete(path: Path) -> bool:
    return (path / "best.pt").exists() and (path / "test_metrics.csv").exists() and (path / "test_predictions.npz").exists()


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    manifest_path = OUT / "run_manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8")) if manifest_path.exists() else []
    seen = {(item.get("model"), item.get("seed")): item for item in manifest}
    env = environment()
    total = len(MODELS) * len(SEEDS)
    index = 0
    for model in MODELS:
        for seed in SEEDS:
            index += 1
            output = OUT / f"{model}_seed{seed}"
            if is_complete(output):
                print(f"[{index}/{total}] already complete {model} seed {seed}", flush=True)
                seen[(model, seed)] = {"model": model, "seed": seed, "status": "complete", "output": str(output)}
                continue
            command = [
                str(PYTHON), str(TRAIN), "--data-dir", str(DATA), "--output-dir", str(output),
                "--window", "4", "--batch-size", "32", "--epochs", "50", "--patience", "50",
                "--learning-rate", "0.0001", "--seed", str(seed), "--d-model", "64", "--layers", "2",
                "--decoder-layers", "2", "--nhead", "4", "--feedforward", "128", "--device", "cuda",
            ]
            if model in ("transformer", "tk_pinn"):
                command += ["--model-type", "transformer", "--closure", "kan" if model == "tk_pinn" else "fixed",
                            "--weighting", "kendall" if model == "tk_pinn" else "equal"]
                if model == "transformer":
                    command.append("--no-physics")
            else:
                command += ["--model-type", model, "--weighting", "equal", "--no-physics"]
            print(f"[{index}/{total}] start {model} seed {seed}", flush=True)
            completed = subprocess.run(command, env=env)
            status = "complete" if completed.returncode == 0 and is_complete(output) else "failed"
            seen[(model, seed)] = {"model": model, "seed": seed, "status": status, "output": str(output)}
            manifest_path.write_text(json.dumps(list(seen.values()), indent=2), encoding="utf-8")
            if status == "failed":
                raise SystemExit(f"failed: {model} seed {seed}")
    manifest_path.write_text(json.dumps(list(seen.values()), indent=2), encoding="utf-8")
    print("primary window-4 suite complete", flush=True)


if __name__ == "__main__":
    main()
