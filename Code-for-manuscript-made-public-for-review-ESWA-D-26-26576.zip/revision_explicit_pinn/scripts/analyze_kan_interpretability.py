"""Extract KAN interpretability evidence without loading plotting libraries.

Run ``render_kan_interpretability.py`` in a second process to fit symbolic
candidates and render the paper figure. Keeping the stages separate avoids
mixing the OpenMP runtimes used by PyTorch and the plotting stack on Windows.
"""
import argparse
import copy
import csv
import json
from pathlib import Path

import torch
from torch.utils.data import DataLoader

from revision_explicit_pinn.data import build_preshifted_datasets
from revision_explicit_pinn.data.schema import FEATURE_NAMES
from revision_explicit_pinn.losses import PhysicsLoss
from revision_explicit_pinn.models import ExplicitPhysicsPINN, ModelConfig


def write_csv(path, rows):
    rows = list(rows)
    if not rows:
        return
    with path.open("w", newline="", encoding="utf-8-sig") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def edge_importance(layer, values):
    with torch.no_grad():
        contributions = layer.edge_contributions(values)
    centered = contributions - contributions.mean(dim=0, keepdim=True)
    return torch.sqrt(torch.mean(centered ** 2, dim=0))


def closure_importance(model, features):
    with torch.no_grad():
        reference = model.flow_closure(features)
    rows = []
    generator = torch.Generator().manual_seed(2026)
    for index, name in enumerate(FEATURE_NAMES):
        permuted = features.clone()
        order = torch.randperm(len(features), generator=generator)
        permuted[:, index] = permuted[order, index]
        with torch.no_grad():
            difference = model.flow_closure(permuted) - reference
        rows.append({
            "feature": name,
            "air_effect_rmse": float(torch.sqrt(torch.mean(difference[:, 0] ** 2))),
            "accumulation_effect_rmse": float(torch.sqrt(torch.mean(difference[:, 1] ** 2))),
        })
    return sorted(rows, key=lambda row: row["air_effect_rmse"], reverse=True)


def physical_losses(model, physics, dataset, max_batches=30):
    totals = torch.zeros(2)
    count = 0
    with torch.no_grad():
        for step, (features, _, _) in enumerate(DataLoader(dataset, batch_size=256, shuffle=False)):
            output = model(features)
            result = physics(
                features, output["prediction"], output["flows"],
                output["previous_flows"], output["latent_delta"],
            )
            totals += torch.tensor([float(result["mass_loss"]), float(result["energy_loss"])]) * len(features)
            count += len(features)
            if step + 1 >= max_batches:
                break
    return totals / count


def prune_layer(layer, scores, threshold):
    mask = scores < threshold
    with torch.no_grad():
        layer.base_weight[mask] = 0.0
        layer.spline_weight[mask.unsqueeze(-1).expand_as(layer.spline_weight)] = 0.0
    return int(mask.sum())


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-dir", required=True)
    parser.add_argument("--data-dir", required=True)
    parser.add_argument("--output-dir", required=True)
    args = parser.parse_args()
    run_dir, output_dir = Path(args.run_dir), Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    config_path = run_dir / "run_config.json"
    if not config_path.exists():
        candidates = list(run_dir.parents[1].glob("seed2026/pinn/run_config.json"))
        if not candidates:
            raise FileNotFoundError("No frozen phase configuration available")
        config_path = candidates[0]
    config = json.loads(config_path.read_text(encoding="utf-8"))
    bundle = build_preshifted_datasets(args.data_dir, config["data"]["window"], include_test=False)
    model = ExplicitPhysicsPINN(ModelConfig(**config["model"]))
    model.load_state_dict(torch.load(str(run_dir / "best.pt"), map_location="cpu")["model"])
    model.eval()

    # Interpretation and all thresholds use validation data, never test data.
    features = torch.stack([bundle.validation[i][0][-1] for i in range(len(bundle.validation))])
    first_input = 2.0 * features - 1.0
    with torch.no_grad():
        second_input = torch.tanh(model.flow_closure.first(first_input))
    scores_by_layer = {
        "first": edge_importance(model.flow_closure.first, first_input),
        "second": edge_importance(model.flow_closure.second, second_input),
    }

    edge_rows = []
    for layer_name, scores in scores_by_layer.items():
        for output_index in range(scores.shape[0]):
            for input_index in range(scores.shape[1]):
                edge_rows.append({
                    "layer": layer_name,
                    "output_index": output_index,
                    "input_index": input_index,
                    "input_name": FEATURE_NAMES[input_index] if layer_name == "first" else "hidden_{}".format(input_index),
                    "importance_rms": float(scores[output_index, input_index]),
                })
    edge_rows.sort(key=lambda row: row["importance_rms"], reverse=True)
    write_csv(output_dir / "kan_edge_importance.csv", edge_rows)
    write_csv(output_dir / "kan_input_permutation_importance.csv", closure_importance(model, features))

    first_rows = [row for row in edge_rows if row["layer"] == "first"]
    # Retain the strongest edge for each measured feature, so the exported
    # diagnostic curves cover all inputs rather than only the dominant one.
    top = []
    for name in FEATURE_NAMES:
        candidates = [row for row in first_rows if row["input_name"] == name]
        if candidates:
            top.append(max(candidates, key=lambda row: row["importance_rms"]))
    grid = torch.linspace(-1.0, 1.0, 241)
    curves = []
    for row in top:
        layer = model.flow_closure.first
        values = torch.zeros(len(grid), layer.in_features)
        values[:, int(row["input_index"])] = grid
        with torch.no_grad():
            curve = layer.edge_contributions(values)[:, int(row["output_index"]), int(row["input_index"])]
        curves.append({**row, "x": grid.tolist(), "y": curve.tolist()})
    (output_dir / "kan_edge_curves.json").write_text(
        json.dumps({"curves": curves}, ensure_ascii=False), encoding="utf-8"
    )

    physics = PhysicsLoss(bundle.scaler.minimum, bundle.scaler.scale)
    baseline = physical_losses(model, physics, bundle.validation)
    pruning_rows = [{
        "pruned_percentile": 0, "pruned_edges": 0,
        "mass_loss": float(baseline[0]), "energy_loss": float(baseline[1]),
        "mass_loss_ratio": 1.0, "energy_loss_ratio": 1.0,
    }]
    all_scores = torch.cat([value.reshape(-1) for value in scores_by_layer.values()])
    for percentile in (25, 50, 75):
        pruned = copy.deepcopy(model)
        threshold = torch.quantile(all_scores, percentile / 100.0)
        count = prune_layer(pruned.flow_closure.first, scores_by_layer["first"], threshold)
        count += prune_layer(pruned.flow_closure.second, scores_by_layer["second"], threshold)
        losses = physical_losses(pruned, physics, bundle.validation)
        pruning_rows.append({
            "pruned_percentile": percentile, "pruned_edges": count,
            "mass_loss": float(losses[0]), "energy_loss": float(losses[1]),
            "mass_loss_ratio": float(losses[0] / baseline[0]),
            "energy_loss_ratio": float(losses[1] / baseline[1]),
        })
    write_csv(output_dir / "kan_pruning_physics_validation.csv", pruning_rows)

    torch.save({
        "first_grid": model.flow_closure.first.grid,
        "first_weight": model.flow_closure.first.spline_weight.detach(),
        "first_scale": model.flow_closure.first.spline_scale.detach(),
        "second_grid": model.flow_closure.second.grid,
        "second_weight": model.flow_closure.second.spline_weight.detach(),
        "second_scale": model.flow_closure.second.spline_scale.detach(),
    }, str(output_dir / "kan_spline_parameters.pt"))
    extraction = {
        "review_comment": "R2/Q2",
        "selection_data": "validation only",
        "first_layer_edges": scores_by_layer["first"].numel(),
        "second_layer_edges": scores_by_layer["second"].numel(),
        "interpretation_scope": "bounded closure functions; not recovered governing laws or physical coefficients",
    }
    (output_dir / "KAN_EXTRACTION_SUMMARY.json").write_text(
        json.dumps(extraction, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(json.dumps(extraction, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
