"""Plot measured versus frozen-model predictions for the three first-unit tests."""
import argparse
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from revision_explicit_pinn.data.schema import OUTPUT_NAMES, UNITS
from revision_explicit_pinn.plotting.paper_style import apply_paper_style, save_figure


MODELS = {
    "explicit_kan_static_s2026": ("Proposed explicit PINN-KAN", "#d62728"),
    "data_only_static_s2026": ("Data-only Transformer", "#1f77b4"),
    "baseline_mlp_s2027": ("MLP baseline", "#2ca02c"),
}
CONDITION_ORDER = ["startup", "load_change", "shutdown"]
CONDITION_LABELS = {"startup": "Test 1: Startup", "load_change": "Test 2: Load change", "shutdown": "Test 3: Shutdown"}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--evaluation-root", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    root, output = Path(args.evaluation_root), Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    apply_paper_style(font_size=9)
    records = []
    loaded = {}
    for run_id, (label, color) in MODELS.items():
        path = root / run_id / "evaluation_predictions.npz"
        if run_id == "explicit_kan_static_s2026" and not path.exists() and (root / "evaluation_predictions.npz").exists():
            path = root / "evaluation_predictions.npz"
        if not path.exists():
            continue
        data = np.load(str(path), allow_pickle=True)
        loaded[run_id] = (label, color, data["first_target"], data["first_prediction"], data["first_condition"])
    if not loaded:
        raise FileNotFoundError("No evaluation_predictions.npz found")
    target = next(iter(loaded.values()))[2]
    for condition in CONDITION_ORDER:
        mask = np.asarray(next(iter(loaded.values()))[4]).astype(str) == condition
        if not mask.any():
            continue
        fig, axes = plt.subplots(5, 1, figsize=(8.0, 9.2), sharex=True, constrained_layout=True)
        x = np.arange(int(mask.sum()))
        for j, (ax, name) in enumerate(zip(axes, OUTPUT_NAMES)):
            ax.plot(x, target[mask, j], color="#555555", linestyle="--", linewidth=1.0, label="Measured" if j == 0 else None)
            for run_id, (label, color, _, prediction, conditions) in loaded.items():
                pred_mask = np.asarray(conditions).astype(str) == condition
                ax.plot(x, prediction[pred_mask, j], color=color, linewidth=0.9, label=label if j == 0 else None)
                err = target[mask, j] - prediction[pred_mask, j]
                rmse = float(np.sqrt(np.mean(err ** 2)))
                mae = float(np.mean(np.abs(err)))
                records.append({"test_set": condition, "model": label, "output": name, "RMSE": rmse, "MAE": mae, "samples": int(mask.sum())})
            ax.set_ylabel("{}\n({})".format(name, UNITS[name]))
            ax.grid(alpha=0.2, linewidth=0.6)
            ax.tick_params(direction="in")
        axes[0].set_title(CONDITION_LABELS[condition])
        axes[0].legend(loc="best", ncol=2, frameon=False)
        axes[-1].set_xlabel("Sample")
        save_figure(fig, output / "{}_fit_comparison.png".format(condition))
    metrics = pd.DataFrame(records)
    metrics.to_csv(str(output / "three_test_fit_metrics.csv"), index=False, encoding="utf-8-sig")
    summary = metrics.pivot_table(index=["test_set", "output"], columns="model", values=["RMSE", "MAE"])
    summary.columns = ["{}_{}".format(metric, model.replace(" ", "_")) for metric, model in summary.columns]
    summary.reset_index().to_csv(str(output / "three_test_fit_metrics_wide.csv"), index=False, encoding="utf-8-sig")
    with (output / "README.md").open("w", encoding="utf-8") as f:
        f.write("# Three-test-set fitting comparisons\n\n")
        f.write("Measured trajectories are shown with dashed gray lines; frozen-model predictions use colored solid lines.\n")
        f.write("Models available in the completed archive: explicit PINN-KAN, data-only Transformer, and MLP baseline.\n")
    print("Generated {} figures and metrics in {}".format(len(CONDITION_ORDER), output))


if __name__ == "__main__":
    main()
