import argparse
import json
from pathlib import Path

import numpy as np

from revision_explicit_pinn.plotting.revision_plots import plot_prediction, plot_training_history


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-dir", required=True)
    args = parser.parse_args()
    run_dir = Path(args.run_dir)
    arrays = np.load(str(run_dir / "test_predictions.npz"))
    with (run_dir / "history.json").open("r", encoding="utf-8") as handle:
        history = json.load(handle)
    plot_prediction(
        arrays["target"], arrays["prediction"], run_dir / "one_step_prediction.png"
    )
    plot_training_history(history, run_dir / "training_history.png")
    print(str(run_dir))


if __name__ == "__main__":
    main()
