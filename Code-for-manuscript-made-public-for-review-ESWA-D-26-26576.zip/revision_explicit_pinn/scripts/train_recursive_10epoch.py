"""Train unchanged model architectures with differentiable multi-step rollout loss."""
import argparse
import csv
import json
import math
import time
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import DataLoader

from revision_explicit_pinn.data import build_datasets
from revision_explicit_pinn.evaluation import grouped_metric_table, metric_table, one_step_predictions_with_metadata, rollout_predictions
from revision_explicit_pinn.losses import KendallTaskWeighting, PhysicsLoss, StaticTaskWeighting
from revision_explicit_pinn.models import ExplicitPhysicsPINN, ModelConfig
from revision_explicit_pinn.training import set_seed


def recursive_batch(model, segments, starts, scaler, window, horizon, device):
    """Return one-step and H-step losses for starts from one contiguous segment."""
    values = scaler.transform(segments.values).astype(np.float32)
    controls = torch.as_tensor(values[:, :2], device=device)
    true_outputs = torch.as_tensor(values[:, 2:], device=device)
    one_preds, one_targets = [], []
    rollout_preds, rollout_targets, rollout_features = [], [], []
    for start in starts:
        history = [true_outputs[index] for index in range(start - window, start)]
        for step in range(horizon):
            target_time = start + step
            token_times = range(target_time - window + 1, target_time + 1)
            tokens = []
            for token_time in token_times:
                previous_time = token_time - 1
                previous = history[previous_time - (start - window)] if previous_time < start else history[previous_time - (start - window)]
                tokens.append(torch.cat([controls[token_time], previous], dim=-1))
            features = torch.stack(tokens, dim=0).unsqueeze(0)
            output = model(features)
            prediction = output["prediction"].squeeze(0)
            if step == 0:
                one_preds.append(prediction)
                one_targets.append(true_outputs[target_time])
            history.append(prediction)
            rollout_preds.append(prediction)
            rollout_targets.append(true_outputs[target_time])
            rollout_features.append((features.squeeze(0), output))
    return (
        torch.stack(one_preds), torch.stack(one_targets),
        torch.stack(rollout_preds), torch.stack(rollout_targets), rollout_features,
    )


def physics_for_output(physics, features, output):
    return physics(
        features.unsqueeze(0), output["prediction"], output["flows"],
        output["previous_flows"], output.get("latent_delta"),
    )


def train_model(model_name, bundle, output_dir, args):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    use_physics = model_name == "pinn"
    model = ExplicitPhysicsPINN(ModelConfig(
        d_model=64, nhead=4, encoder_layers=2, feedforward_dim=128,
        # Preserve the exact architecture stored by both paired checkpoints.
        max_window=30, closure="kan",
    )).to(device)
    initial_checkpoint = args.pinn_init if use_physics else args.transformer_init
    if initial_checkpoint:
        checkpoint = torch.load(initial_checkpoint, map_location=device)
        model.load_state_dict(checkpoint["model"])
        print("[{}] initialized from {}".format(model_name, initial_checkpoint), flush=True)
    physics = PhysicsLoss(bundle.scaler.minimum, bundle.scaler.scale).to(device)
    weighting = KendallTaskWeighting().to(device) if use_physics else StaticTaskWeighting().to(device)
    optimizer = torch.optim.Adam(list(model.parameters()) + list(weighting.parameters()), lr=1e-4)
    output_dir.mkdir(parents=True, exist_ok=True)
    best = None
    history = []
    # Use contiguous chunks from each training file; no chunk crosses a file.
    for epoch in range(1, args.epochs + 1):
        set_seed(args.seed + epoch)
        model.train()
        train_total = 0.0
        train_count = 0
        for segment in bundle.segments["train"]:
            max_start = len(segment.values) - args.horizon - 1
            candidates = np.arange(args.window, max_start)
            rng = np.random.RandomState(args.seed + epoch)
            count = min(args.starts_per_segment, len(candidates))
            starts = sorted(rng.choice(candidates, size=count, replace=False).tolist())
            for offset in range(0, len(starts), args.batch_starts):
                batch_starts = starts[offset:offset + args.batch_starts]
                if not batch_starts:
                    continue
                optimizer.zero_grad()
                one_pred, one_target, roll_pred, roll_target, roll_records = recursive_batch(
                    model, segment, batch_starts, bundle.scaler, args.window, args.horizon, device
                )
                one_loss = torch.mean((one_pred - one_target) ** 2)
                roll_loss = torch.mean((roll_pred - roll_target) ** 2)
                data_loss = 0.5 * one_loss + 0.5 * roll_loss
                if use_physics:
                    mass_terms, energy_terms = [], []
                    for features, output in roll_records:
                        values = physics_for_output(physics, features, output)
                        mass_terms.append(values["mass_loss"])
                        energy_terms.append(values["energy_loss"])
                    mass_loss = torch.stack(mass_terms).mean()
                    energy_loss = torch.stack(energy_terms).mean()
                    # Reuse the train-only frozen scales from the paired run.
                    total, weights = weighting(
                        data_loss / 0.01010331988800317,
                        mass_loss / 26.355130672454834,
                        energy_loss / 56.17887234687805,
                    )
                else:
                    mass_loss = torch.zeros_like(data_loss)
                    energy_loss = torch.zeros_like(data_loss)
                    total, weights = weighting(data_loss, mass_loss, energy_loss)
                kan = model.flow_closure.regularization_loss()
                objective = total + 1.0e-5 * kan
                if not torch.isfinite(objective):
                    raise FloatingPointError("non-finite recursive objective")
                objective.backward()
                torch.nn.utils.clip_grad_norm_(list(model.parameters()) + list(weighting.parameters()), 1.0)
                optimizer.step()
                train_total += float(data_loss.detach()) * len(batch_starts)
                train_count += len(batch_starts)

        # Validation uses the same recursive objective, but no optimizer update.
        model.eval()
        with torch.no_grad():
            val_roll_errors = []
            for segment in bundle.segments["validation"]:
                max_start = len(segment.values) - args.horizon - 1
                candidates = np.arange(args.window, max_start)
                count = min(args.validation_starts_per_segment, len(candidates))
                validation_starts = np.linspace(args.window, max_start - 1, count, dtype=int)
                for start in validation_starts:
                    _, _, pred, target, _ = recursive_batch(model, segment, [start], bundle.scaler, args.window, args.horizon, device)
                    val_roll_errors.append(torch.mean((pred - target) ** 2).item())
            val_roll = float(np.mean(val_roll_errors))
        row = {"epoch": epoch, "train_data": train_total / max(train_count, 1), "validation_rollout_data": val_roll}
        history.append(row)
        print("[{}] epoch {} train={:.6g} val_rollout={:.6g}".format(model_name, epoch, row["train_data"], val_roll), flush=True)
        if best is None or val_roll < best["validation_rollout_data"]:
            best = {"model": {key: value.detach().cpu() for key, value in model.state_dict().items()}, "weighting": weighting.state_dict(), "epoch": epoch, "validation_rollout_data": val_roll}
            torch.save(best, str(output_dir / "best.pt"))
    model.load_state_dict(best["model"])
    with (output_dir / "history.json").open("w", encoding="utf-8") as handle:
        json.dump(history, handle, indent=2)
    return model, device, best, history


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", default="data/999")
    parser.add_argument("--output-root", required=True)
    parser.add_argument("--epochs", type=int, default=10)
    parser.add_argument("--horizon", type=int, default=16)
    parser.add_argument("--batch-starts", type=int, default=4)
    parser.add_argument("--starts-per-segment", type=int, default=16)
    parser.add_argument("--validation-starts-per-segment", type=int, default=16)
    parser.add_argument("--window", type=int, default=8)
    parser.add_argument("--seed", type=int, default=2026)
    parser.add_argument("--pinn-init", default="")
    parser.add_argument("--transformer-init", default="")
    args = parser.parse_args()
    set_seed(args.seed)
    bundle = build_datasets(args.data_dir, window=args.window, include_test=True)
    root = Path(args.output_root)
    root.mkdir(parents=True, exist_ok=True)
    for model_name in ("pinn", "transformer"):
        started = time.time()
        model, device, best, history = train_model(model_name, bundle, root / model_name, args)
        target_n, prediction_n, sources, conditions = one_step_predictions_with_metadata(model, bundle.test, device)
        target = target_n * bundle.scaler.scale[2:] + bundle.scaler.minimum[2:]
        prediction = prediction_n * bundle.scaler.scale[2:] + bundle.scaler.minimum[2:]
        roll_tn, roll_pn, roll_sources, roll_conditions = rollout_predictions(model, bundle.segments["test"], bundle.scaler, args.window, device)
        roll_target = roll_tn * bundle.scaler.scale[2:] + bundle.scaler.minimum[2:]
        roll_prediction = roll_pn * bundle.scaler.scale[2:] + bundle.scaler.minimum[2:]
        rows = grouped_metric_table(target, prediction, conditions)
        roll_rows = grouped_metric_table(roll_target, roll_prediction, roll_conditions)
        for path, values in ((root / model_name / "test_metrics.csv", rows), (root / model_name / "rollout_metrics.csv", roll_rows)):
            with path.open("w", newline="", encoding="utf-8") as handle:
                writer = csv.DictWriter(handle, fieldnames=list(values[0])); writer.writeheader(); writer.writerows(values)
        np.savez_compressed(root / model_name / "test_predictions.npz", target=target, prediction=prediction, condition=conditions)
        np.savez_compressed(root / model_name / "rollout_predictions.npz", target=roll_target, prediction=roll_prediction, condition=roll_conditions)
        (root / model_name / "run_config.json").write_text(json.dumps({"epochs": args.epochs, "horizon": args.horizon, "window": args.window, "batch_starts": args.batch_starts, "seed": args.seed, "model": model_name, "validation_selection": "recursive_data_loss", "test_evaluated_after_freezing": True, "elapsed_seconds": time.time() - started}, indent=2), encoding="utf-8")
    print(str(root))


if __name__ == "__main__":
    main()
