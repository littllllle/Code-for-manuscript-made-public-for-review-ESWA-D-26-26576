import argparse
import csv
import json
from pathlib import Path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="revision_explicit_pinn/configs/ablation_matrix.json")
    parser.add_argument("--output", default="revision_explicit_pinn/run_outputs/ablation_manifest.csv")
    args = parser.parse_args()
    with Path(args.config).open("r", encoding="utf-8") as handle:
        config = json.load(handle)
    rows = []
    for variant in config["physics_closure"]:
        for weighting in config["weighting"]:
            for seed in config["seeds"]:
                rows.append({
                    "run_id": "{}_{}_s{}".format(variant["name"], weighting, seed),
                    "variant": variant["name"], "weighting": weighting, "seed": seed,
                    "model_type": variant["model_type"], "closure": variant["closure"],
                    "use_physics": variant["use_physics"], "status": "pending",
                })
    for baseline in config["baselines"]:
        for seed in config["seeds"]:
            rows.append({
                "run_id": "baseline_{}_s{}".format(baseline, seed),
                "variant": "baseline", "weighting": "equal", "seed": seed,
                "model_type": baseline, "closure": "fixed", "use_physics": False,
                "status": "pending",
            })
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    print("{} ablation/baseline runs written to {}".format(len(rows), output))


if __name__ == "__main__":
    main()
