"""Plot full-test-set 10-step recursive fits for one seed."""
from pathlib import Path
import json

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch

from revision_explicit_pinn.data import build_preshifted_datasets
from revision_explicit_pinn.data.schema import OUTPUT_NAMES, UNITS
from revision_explicit_pinn.models import BaselineConfig, BaselinePredictor, ExplicitPhysicsPINN, ModelConfig
from revision_explicit_pinn.plotting.paper_style import apply_paper_style, save_figure
from revision_explicit_pinn.scripts.train_preshifted_horizon import fixed_horizon_rollout


PACKAGE = Path(r"D:\PythonProjects\PINN_code+tex\ESWA返修\返修交付包_统一参数框架_20260831")
CODE = PACKAGE / "03_代码"
ROOT = PACKAGE / "04_图表与CSV结果" / "final_simulation_20260831" / "04_recursive_finite_horizon"
DATA = CODE / "data" / "999"
MODELS = {"lstm": ("LSTM", "#2ca02c"), "tcn": ("TCN", "#9467bd"), "kan": ("KAN", "#ff7f0e"),
          "transformer": ("Transformer", "#1f77b4"), "pinn": ("TK-PINN", "#d62728")}
CONDITIONS = ("startup", "load_change", "shutdown")
LABELS = {"startup": "Test 1: Startup", "load_change": "Test 2: Load change", "shutdown": "Test 3: Shutdown"}


def load_model(model_name, seed, device):
    run = ROOT / "{}_seed{}".format(model_name, seed)
    config = json.loads((run / "run_config.json").read_text(encoding="utf-8"))["model"]
    if model_name in ("transformer", "pinn"):
        model = ExplicitPhysicsPINN(ModelConfig(**config))
    else:
        model = BaselinePredictor(BaselineConfig(**config))
    checkpoint = torch.load(str(run / "best.pt"), map_location=device)
    model.load_state_dict(checkpoint["model"])
    return model.to(device).eval()


def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--seed", type=int, default=2026)
    parser.add_argument("--horizon", type=int, default=10)
    parser.add_argument("--output-dir", default=str(ROOT / "summary_figures" / "full_test_single_seed"))
    args = parser.parse_args()
    out = Path(args.output_dir); out.mkdir(parents=True, exist_ok=True)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    bundle = build_preshifted_datasets(DATA, window=8, include_test=True)
    loaded = {}
    for model_name, style in MODELS.items():
        try:
            loaded[model_name] = (style, load_model(model_name, args.seed, device))
        except (FileNotFoundError, RuntimeError, KeyError):
            continue
    if not loaded:
        raise RuntimeError("No completed checkpoints found")
    all_data = {}
    for condition in CONDITIONS:
        segments = [s for s in bundle.segments["test"] if s.condition == condition]
        if not segments:
            continue
        target_parts = []; pred_parts = {name: [] for name in loaded}
        for segment in segments:
            _, target, _ = fixed_horizon_rollout(next(iter(loaded.values()))[1], segment, bundle.scaler, 8, args.horizon, device)
            target_parts.append(target[:, -1])
            for name, (_, model) in loaded.items():
                _, _, pred = fixed_horizon_rollout(model, segment, bundle.scaler, 8, args.horizon, device)
                pred_parts[name].append(pred[:, -1])
        target = np.concatenate(target_parts) * bundle.scaler.scale[2:] + bundle.scaler.minimum[2:]
        all_data[condition] = {"target": target}
        for name in loaded:
            all_data[condition][name] = np.concatenate(pred_parts[name]) * bundle.scaler.scale[2:] + bundle.scaler.minimum[2:]
        apply_paper_style(font_size=9)
        fig, axes = plt.subplots(5, 1, figsize=(8.0, 9.2), sharex=True, constrained_layout=True)
        x = np.arange(len(target))
        for j, (ax, output_name) in enumerate(zip(axes, OUTPUT_NAMES)):
            ax.plot(x, target[:, j], color="#555555", linestyle="--", linewidth=0.9, label="Measured" if j == 0 else None)
            for name, (label, color) in MODELS.items():
                if name in loaded:
                    ax.plot(x, all_data[condition][name][:, j], color=color, linewidth=0.8, label=label if j == 0 else None)
            ax.set_ylabel("{}\n({})".format(output_name, UNITS[output_name]))
            ax.grid(alpha=0.2, linewidth=0.6); ax.tick_params(direction="in")
        axes[0].set_title("{} | seed={} | full test set | 10-step recursive prediction".format(LABELS[condition], args.seed))
        axes[0].legend(loc="best", ncol=3, frameon=False)
        axes[-1].set_xlabel("Test-set recursive origin (chronological)")
        save_figure(fig, out / "{}_seed{}_full_test_h10_fit.png".format(condition, args.seed), dpi=300)
        plt.close(fig)
    np.savez_compressed(out / "seed{}_full_test_h10_predictions.npz".format(args.seed), **{k: v for c, d in all_data.items() for k, v in []})
    (out / "README.txt").write_text("Full test-set 10-step recursive fits for seed {}. Each curve uses the 10th recursive lead at every valid test origin.\n".format(args.seed), encoding="utf-8")
    print("saved", out)


if __name__ == "__main__":
    main()
