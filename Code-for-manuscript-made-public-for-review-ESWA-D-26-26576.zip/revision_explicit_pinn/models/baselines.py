from dataclasses import dataclass

import torch

from .explicit_pinn import FixedFlowClosure
from .kan import KANLinear


@dataclass(frozen=True)
class BaselineConfig:
    model_type: str
    input_dim: int = 7
    output_dim: int = 5
    hidden_dim: int = 64
    layers: int = 2
    dropout: float = 0.1
    max_window: int = 30
    closure: str = "fixed"


class BaselinePredictor(torch.nn.Module):
    def __init__(self, config):
        super().__init__()
        self.config = config
        cfg = config
        if cfg.model_type == "mlp":
            modules = [torch.nn.Flatten(), torch.nn.LazyLinear(cfg.hidden_dim), torch.nn.GELU()]
            for _ in range(max(0, cfg.layers - 1)):
                modules.extend([torch.nn.Linear(cfg.hidden_dim, cfg.hidden_dim), torch.nn.GELU(), torch.nn.Dropout(cfg.dropout)])
            modules.append(torch.nn.Linear(cfg.hidden_dim, cfg.output_dim))
            self.network = torch.nn.Sequential(*modules)
        elif cfg.model_type in ("gru", "lstm"):
            recurrent_class = torch.nn.GRU if cfg.model_type == "gru" else torch.nn.LSTM
            self.recurrent = recurrent_class(
                cfg.input_dim, cfg.hidden_dim, num_layers=cfg.layers,
                batch_first=True, dropout=cfg.dropout if cfg.layers > 1 else 0.0,
            )
            self.head = torch.nn.Linear(cfg.hidden_dim, cfg.output_dim)
        elif cfg.model_type == "kan":
            self.kan_first = KANLinear(cfg.input_dim, cfg.hidden_dim)
            self.kan_second = KANLinear(cfg.hidden_dim, cfg.output_dim)
        elif cfg.model_type == "tcn":
            # Depthwise-separable temporal blocks keep the same causal,
            # equal-length interface while substantially reducing the
            # convolution cost of the previous dense TCN on CPU.
            channels = []
            in_channels = cfg.input_dim
            for layer_index in range(cfg.layers):
                dilation = 2 ** layer_index
                channels.extend([
                    torch.nn.Conv1d(
                        in_channels, in_channels, kernel_size=3, padding=dilation,
                        dilation=dilation, groups=in_channels, bias=False,
                    ),
                    torch.nn.Conv1d(in_channels, cfg.hidden_dim, kernel_size=1),
                    torch.nn.GELU(),
                ])
                in_channels = cfg.hidden_dim
            self.network = torch.nn.Sequential(*channels)
            self.head = torch.nn.Linear(cfg.hidden_dim, cfg.output_dim)
        else:
            raise ValueError("Unknown baseline {}".format(cfg.model_type))
        self.flow_closure = FixedFlowClosure()

    def forward(self, features):
        if self.config.model_type == "mlp":
            prediction = self.network(features)
        elif self.config.model_type in ("gru", "lstm"):
            encoded, _ = self.recurrent(features)
            prediction = self.head(encoded[:, -1])
        elif self.config.model_type == "kan":
            hidden = torch.tanh(self.kan_first(2.0 * features[:, -1] - 1.0))
            prediction = self.kan_second(hidden)
        else:
            encoded = self.network(features.transpose(1, 2))
            prediction = self.head(encoded[:, :, -1])
        current = self.flow_closure(features[:, -1])
        previous = self.flow_closure(features[:, -2] if features.shape[1] > 1 else features[:, -1])
        return {"prediction": prediction, "flows": current, "previous_flows": previous}
