"""Aggregate completed window-4 primary runs into long and mean/std CSV files."""
from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd


OUTPUTS = ["P_c", "n", "W_e", "T_e", "G_NOx"]
CONDITIONS = ("startup", "load_change", "shutdown")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    root, out = Path(args.root), Path(args.output)
    out.mkdir(parents=True, exist_ok=True)
    rows = []
    for run in sorted(root.glob("*_seed*")):
        pred_path = run / "test_predictions.npz"
        config_path = run / "run_config.json"
        if not pred_path.exists() or not config_path.exists():
            continue
        model, seed = run.name.rsplit("_seed", 1)
        z = np.load(pred_path)
        target, prediction, conditions = z["target"], z["prediction"], z["condition"]
        for cname in CONDITIONS:
            mask = conditions.astype(str) == cname
            if not np.any(mask):
                continue
            for qi, output_name in enumerate(OUTPUTS):
                err = prediction[mask, qi] - target[mask, qi]
                y = target[mask, qi]
                mse = float(np.mean(err ** 2))
                fit_den = float(np.sqrt(np.sum(y ** 2)))
                fit_score = float(100.0 * (1.0 - np.sqrt(np.sum(err ** 2)) / fit_den)) if fit_den > 1e-8 else np.nan
                valid = np.abs(y) > 1e-8
                mape = float(np.mean(np.abs(err[valid] / y[valid])) * 100.0) if np.any(valid) else np.nan
                rows.append({
                    "model": model, "seed": int(seed), "condition": cname,
                    "output": output_name, "n_samples": int(mask.sum()),
                    "MSE": mse, "RMSE": float(np.sqrt(mse)),
                    "MAE": float(np.mean(np.abs(err))),
                    "MAPE_percent": mape,
                    "fit_score_percent": fit_score,
                })
    long = pd.DataFrame(rows)
    long.to_csv(out / "primary_window4_metrics_long.csv", index=False, encoding="utf-8-sig")
    if not long.empty:
        summary = (long.groupby(["model", "condition", "output"], as_index=False)
                   .agg(MSE_mean=("MSE", "mean"), MSE_sd=("MSE", "std"),
                        RMSE_mean=("RMSE", "mean"), RMSE_sd=("RMSE", "std"),
                        MAE_mean=("MAE", "mean"), MAE_sd=("MAE", "std"),
                        MAPE_mean=("MAPE_percent", "mean"), MAPE_sd=("MAPE_percent", "std"),
                        Fs_mean=("fit_score_percent", "mean"), Fs_sd=("fit_score_percent", "std"),
                        n_instances=("seed", "nunique")))
        summary.to_csv(out / "primary_window4_metrics_mean_sd.csv", index=False, encoding="utf-8-sig")
    print(f"aggregated {len(long)} condition-output rows")


if __name__ == "__main__":
    main()
