"""Fit held-out symbolic candidates and render extracted KAN edge functions."""
import argparse
import csv
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from revision_explicit_pinn.plotting.paper_style import apply_paper_style, save_figure


def candidate_fits(x, y):
    # Every fourth grid point is held out from symbolic fitting.
    fit_mask = np.arange(len(x)) % 4 != 0
    train_x, train_y = x[fit_mask], y[fit_mask]
    val_x, val_y = x[~fit_mask], y[~fit_mask]
    rows = []
    for degree in (1, 2, 3):
        coefficients = np.polyfit(train_x, train_y, degree)
        prediction = np.polyval(coefficients, val_x)
        denominator = max(float(np.sum((val_y - np.mean(val_y)) ** 2)), 1e-12)
        rmse = float(np.sqrt(np.mean((val_y - prediction) ** 2)))
        r2 = float(1.0 - np.sum((val_y - prediction) ** 2) / denominator)
        rows.append((degree, coefficients, rmse, r2))
    return sorted(rows, key=lambda item: (-item[3], item[2]))


def expression(coefficients):
    degree = len(coefficients) - 1
    return " + ".join(
        "{:.8g}*x^{}".format(value, degree - index)
        for index, value in enumerate(coefficients)
    )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input-dir", required=True)
    args = parser.parse_args()
    output_dir = Path(args.input_dir)
    curves = json.loads((output_dir / "kan_edge_curves.json").read_text(encoding="utf-8"))["curves"]

    apply_paper_style(9)
    fig, axes = plt.subplots(4, 2, figsize=(8.0, 9.0), constrained_layout=True)
    symbolic_rows = []
    for axis, row in zip(axes.ravel(), curves):
        x, y = np.asarray(row["x"]), np.asarray(row["y"])
        degree, coefficients, rmse, r2 = candidate_fits(x, y)[0]
        axis.plot(x, y, color="#1f77b4", label="Learned spline")
        axis.plot(x, np.polyval(coefficients, x), "--", color="#d62728", label="Symbolic candidate")
        axis.set_title("h{} <- {}".format(row["output_index"], row["input_name"]))
        axis.set_xlabel("Normalized input")
        axis.set_ylabel("Edge contribution")
        axis.grid(alpha=0.2)
        symbolic_rows.append({
            "layer": "first", "output_index": row["output_index"],
            "input_name": row["input_name"], "candidate": "polynomial_{}".format(degree),
            "validation_R2": r2, "validation_RMSE": rmse,
            "expression": expression(coefficients),
        })
    axes[0, 0].legend(frameon=False)
    save_figure(fig, output_dir / "kan_top_edge_functions.png")
    with (output_dir / "kan_symbolic_approximations.csv").open("w", newline="", encoding="utf-8-sig") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(symbolic_rows[0]))
        writer.writeheader()
        writer.writerows(symbolic_rows)

    best_r2 = max(row["validation_R2"] for row in symbolic_rows)
    stable_count = sum(row["validation_R2"] >= 0.95 for row in symbolic_rows)
    summary = {
        "review_comment": "R2/Q2",
        "symbolic_validation": "every fourth spline-grid point held out",
        "top_symbolic_validation_R2": best_r2,
        "edges_with_validation_R2_ge_0.95": stable_count,
        "claim_gate": "explicit symbolic candidate" if stable_count else "inspectable spline closure only",
        "interpretation_scope": "bounded closure functions; not recovered governing laws or physical coefficients",
    }
    (output_dir / "KAN_INTERPRETABILITY_SUMMARY.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
