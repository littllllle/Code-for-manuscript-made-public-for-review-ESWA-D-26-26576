"""Evaluate frozen five-model checkpoints on noise and second-unit data.

This is inference only: no optimizer, fitting, fine-tuning, or test-based
selection is performed. Results are saved per model/seed for auditability.
"""
from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

import numpy as np
import torch

PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from revision_explicit_pinn.data import WindowedGasTurbineDataset, build_datasets
from revision_explicit_pinn.data.pipeline import Segment, read_csv
from revision_explicit_pinn.evaluation import grouped_metric_table, one_step_predictions_with_metadata
from revision_explicit_pinn.evaluation.noise import add_training_scale_gaussian_noise
from revision_explicit_pinn.models import BaselineConfig, BaselinePredictor, ExplicitPhysicsPINN, ModelConfig


MODELS = ("lstm", "tcn", "kan", "transformer", "pinn")
SEEDS = (2026, 2027, 2028, 2029, 2030)
SECOND_FILES = (("test3升.csv", "load_increase"), ("test2降.csv", "load_decrease"))


def run_directory(results: Path, model: str, seed: int) -> Path:
    if model in {"pinn", "transformer"}:
        return results / "final_simulation_20260831" / "03_one_step_encoder_decoder" / f"{model}_seed{seed}"
    name = "tcn_seed2026_cpu_retry" if model == "tcn" and seed == 2026 else f"{model}_seed{seed}"
    return results / "complete_code_tests_20260830" / "phase10_baselines" / name


def build_model(config: dict):
    model_config = config["model"]
    if "model_type" in model_config:
        return BaselinePredictor(BaselineConfig(**model_config))
    return ExplicitPhysicsPINN(ModelConfig(**model_config))


class LegacyDenseTCN(torch.nn.Module):
    """Exact architecture used by the archived dense-TCN checkpoints."""

    def __init__(self, config: BaselineConfig):
        super().__init__()
        channels = []
        in_channels = config.input_dim
        for layer_index in range(config.layers):
            dilation = 2 ** layer_index
            channels.extend([torch.nn.Conv1d(in_channels, config.hidden_dim, 3, padding=dilation, dilation=dilation),
                             torch.nn.GELU()])
            in_channels = config.hidden_dim
        self.network = torch.nn.Sequential(*channels)
        self.head = torch.nn.Linear(config.hidden_dim, config.output_dim)
        from revision_explicit_pinn.models.explicit_pinn import FixedFlowClosure
        self.flow_closure = FixedFlowClosure()

    def forward(self, features):
        encoded = self.network(features.transpose(1, 2))
        prediction = self.head(encoded[:, :, -1])
        current = self.flow_closure(features[:, -1])
        previous = self.flow_closure(features[:, -2] if features.shape[1] > 1 else features[:, -1])
        return {"prediction": prediction, "flows": current, "previous_flows": previous}


def build_checkpoint_compatible_model(config: dict, state: dict):
    model_config = config["model"]
    if model_config.get("model_type") == "tcn" and "network.0.bias" in state:
        return LegacyDenseTCN(BaselineConfig(**model_config))
    return build_model(config)


def write_rows(path: Path, rows: list[dict]) -> None:
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def second_segments(directory: Path) -> list[Segment]:
    segments = []
    for filename, condition in SECOND_FILES:
        path = directory / filename
        values = read_csv(path)
        segments.append(Segment(filename, condition, "second_unit", 0, len(values), values))
    return segments


def evaluate_noise(model, bundle, device, levels: tuple[float, ...]) -> list[dict]:
    targets_n = np.asarray([sample[1] for sample in bundle.test.samples])
    conditions = [sample[2]["condition"] for sample in bundle.test.samples]
    rows = []
    for level in levels:
        noisy = np.stack([add_training_scale_gaussian_noise(sample[0], level, seed=202600 + index)
                          for index, sample in enumerate(bundle.test.samples)])
        predictions = []
        for start in range(0, len(noisy), 256):
            batch = torch.tensor(noisy[start:start + 256], dtype=torch.float32, device=device)
            with torch.no_grad():
                predictions.append(model(batch)["prediction"].cpu().numpy())
        predictions_n = np.concatenate(predictions)
        target = targets_n * bundle.scaler.scale[2:] + bundle.scaler.minimum[2:]
        prediction = predictions_n * bundle.scaler.scale[2:] + bundle.scaler.minimum[2:]
        for row in grouped_metric_table(target, prediction, conditions):
            row["noise_level"] = level
            rows.append(row)
    return rows


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--results-root", type=Path, required=True)
    parser.add_argument("--data-dir", type=Path, required=True)
    parser.add_argument("--second-unit-dir", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--models", default=",".join(MODELS))
    parser.add_argument("--seeds", default=",".join(map(str, SEEDS)))
    parser.add_argument("--levels", default="0,0.01,0.03,0.05")
    args = parser.parse_args()
    models = tuple(item.strip() for item in args.models.split(","))
    seeds = tuple(int(item) for item in args.seeds.split(","))
    levels = tuple(float(item) for item in args.levels.split(","))
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    args.output_dir.mkdir(parents=True, exist_ok=True)
    audit = []
    for model_name in models:
        for seed in seeds:
            run_dir = run_directory(args.results_root, model_name, seed)
            output = args.output_dir / f"{model_name}_seed{seed}"
            output.mkdir(parents=True, exist_ok=True)
            config = json.loads((run_dir / "run_config.json").read_text(encoding="utf-8"))
            bundle = build_datasets(args.data_dir, config["data"]["window"], include_test=True)
            checkpoint = torch.load(str(run_dir / "best.pt"), map_location="cpu")
            model = build_checkpoint_compatible_model(config, checkpoint["model"])
            model.load_state_dict(checkpoint["model"])
            model.to(device).eval()
            noise_rows = evaluate_noise(model, bundle, device, levels)
            write_rows(output / "noise_metrics_by_condition.csv", noise_rows)
            segments = second_segments(args.second_unit_dir)
            dataset = WindowedGasTurbineDataset(segments, bundle.scaler, config["data"]["window"])
            target_n, prediction_n, _, conditions = one_step_predictions_with_metadata(model, dataset, device)
            target = target_n * bundle.scaler.scale[2:] + bundle.scaler.minimum[2:]
            prediction = prediction_n * bundle.scaler.scale[2:] + bundle.scaler.minimum[2:]
            write_rows(output / "second_unit_zero_shot_one_step.csv", grouped_metric_table(target, prediction, conditions))
            np.savez_compressed(output / "second_unit_predictions.npz", target=target, prediction=prediction,
                                condition=np.asarray(conditions))
            audit.append({"model": model_name, "seed": seed, "run_dir": str(run_dir),
                          "noise_rows": len(noise_rows), "second_unit_samples": len(target), "device": str(device)})
            print(f"complete model={model_name} seed={seed} noise_rows={len(noise_rows)} second_samples={len(target)}", flush=True)
    (args.output_dir / "audit.json").write_text(json.dumps({"status": "complete", "runs": audit}, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
