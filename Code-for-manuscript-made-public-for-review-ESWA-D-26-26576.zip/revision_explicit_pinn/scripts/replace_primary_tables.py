from pathlib import Path
import re
import pandas as pd

PACKAGE = Path(__file__).resolve().parents[3]
TEX = PACKAGE / "01_手稿" / "Manuscript_restructured.tex"
CSV = PACKAGE / "04_图表与CSV结果" / "primary_window4_20260907" / "aggregated" / "primary_window4_metrics_mean_sd.csv"
DF = pd.read_csv(CSV)
UNITS = {"P_c": r"kg$\cdot$cm$^{-2}$", "n": "rpm", "W_e": "MW", "T_e": r"$^{\circ}$C", "G_NOx": r"mg$\cdot$Nm$^{-3}$"}
OUTPUTS = ["P_c", "n", "W_e", "T_e", "G_NOx"]
MODELS = ["lstm", "tcn", "kan", "transformer", "tk_pinn"]
LABELS = {"lstm": "LSTM", "tcn": "TCN", "kan": "KAN", "transformer": "Transformer", "tk_pinn": "TK-PINN"}

def fmt(value, scientific=False):
    if pd.isna(value):
        return "--"
    value = float(value)
    if scientific or abs(value) >= 1000 or (0 < abs(value) < 0.01):
        return f"{value:.3e}"
    return f"{value:.3f}"

def make_table(condition, caption, label):
    frame = DF[DF["condition"] == condition].set_index(["output", "model"])
    lines = [r"\begin{table*}[pos=!htbp]", r"\centering", r"\scriptsize", f"\\caption{{{caption}}}", f"\\label{{{label}}}", r"\resizebox{\textwidth}{!}{%", r"\begin{tabular}{llccccc}", r"\toprule", r"Output (unit) & Method & MSE & RMSE & MAE & $\mathrm{MAPE}_{active}$ (\%) & $F_s$ (\%) \\", r"\midrule"]
    for output_index, output in enumerate(OUTPUTS):
        for model_index, model in enumerate(MODELS):
            row = frame.loc[(output, model)]
            output_label = f"${output}$ ({UNITS[output]})" if model_index == 0 else ""
            values = [f"${fmt(row.MSE_mean, True)}\\pm{fmt(row.MSE_sd, True)}$", f"${fmt(row.RMSE_mean)}\\pm{fmt(row.RMSE_sd)}$", f"${fmt(row.MAE_mean)}\\pm{fmt(row.MAE_sd)}$", f"${fmt(row.MAPE_mean)}\\pm{fmt(row.MAPE_sd)}$", f"${fmt(row.Fs_mean)}\\pm{fmt(row.Fs_sd)}$"]
            lines.append(f"{output_label} & {LABELS[model]} & {' & '.join(values)} \\")
        if output_index < len(OUTPUTS) - 1:
            lines.append(r"\midrule")
    lines.extend([r"\bottomrule", r"\end{tabular}}", r"\end{table*}", ""])
    return "\n".join(lines)

text = TEX.read_text(encoding="utf-8")
for condition, caption, label in [("startup", r"Startup one-step metrics by output and model, mean $\pm$ sample SD over five independent runs.", "tab:startup_metrics"), ("load_change", r"Load-change one-step metrics by output and model, mean $\pm$ sample SD over five independent runs.", "tab:load_metrics"), ("shutdown", r"Shutdown one-step metrics by output and model, mean $\pm$ sample SD over five independent runs.", "tab:shutdown_metrics")]:
    pattern = rf"\\begin\{{table\*\}}.*?\\label\{{{re.escape(label)}\}}.*?\\end\{{table\*\}}"
    text, count = re.subn(pattern, lambda _match, b=make_table(condition, caption, label): b, text, count=1, flags=re.S)
    if count != 1:
        raise RuntimeError(f"Could not replace {label}")
TEX.write_text(text, encoding="utf-8")
print("replaced primary tables")
