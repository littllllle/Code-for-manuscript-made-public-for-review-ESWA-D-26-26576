import argparse
import csv
import json
from pathlib import Path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="revision_explicit_pinn/configs/grid_search.json")
    parser.add_argument("--output", default="revision_explicit_pinn/run_outputs/grid_manifest.csv")
    parser.add_argument("--epochs", type=int, default=30)
    args = parser.parse_args()
    with Path(args.config).open("r", encoding="utf-8") as handle:
        config = json.load(handle)
    rows = []
    for batch_size in config["batch_sizes"]:
        for window in config["windows"]:
            for seed in config["seeds"]:
                run_id = "bs{}_w{}_s{}".format(batch_size, window, seed)
                rows.append(
                    {
                        "run_id": run_id,
                        "batch_size": batch_size,
                        "window": window,
                        "seed": seed,
                        "epochs": args.epochs,
                        "status": "pending",
                        "uses_isga": False,
                    }
                )
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    print("{} runs written to {}".format(len(rows), output))


if __name__ == "__main__":
    main()

