from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


OUTPUTS = ["P_c", "n", "W_e", "T_e", "G_NOx"]
CONDITIONS = ["startup", "load_change", "shutdown"]
CONDITION_LABELS = {
    "startup": "Startup",
    "load_change": "Load change",
    "shutdown": "Shutdown",
}
COLORS = {"pinn": "#C43C39", "transformer": "#276FBF"}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Plot one-step and recursive fits by condition")
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--data-dir", type=Path, required=True)
    parser.add_argument("--window", type=int, default=8)
    return parser.parse_args()


def configure_style() -> None:
    plt.rcParams.update(
        {
            "font.family": "Times New Roman",
            "font.size": 11,
            "mathtext.fontset": "stix",
            "axes.linewidth": 0.8,
            "axes.grid": True,
            "grid.alpha": 0.18,
            "grid.linewidth": 0.6,
            "savefig.dpi": 300,
        }
    )


def csv_rows(path: Path) -> int:
    # The operating CSVs have no header, matching the training loader.
    return len(pd.read_csv(path, header=None))


def metrics(target: np.ndarray, prediction: np.ndarray, condition: str, model: str, mode: str):
    rows = []
    for column, output in enumerate(OUTPUTS):
        error = prediction[:, column] - target[:, column]
        denominator = np.sum((target[:, column] - target[:, column].mean()) ** 2)
        rows.append(
            {
                "mode": mode,
                "condition": condition,
                "model": model,
                "output": output,
                "samples": len(target),
                "RMSE": float(np.sqrt(np.mean(error**2))),
                "MAE": float(np.mean(np.abs(error))),
                "R2": float(1.0 - np.sum(error**2) / denominator) if denominator > 1e-12 else np.nan,
            }
        )
    return rows


def plot_fit(
    path: Path,
    x: np.ndarray,
    target: np.ndarray,
    pinn: np.ndarray,
    transformer: np.ndarray,
    condition: str,
    mode_label: str,
) -> None:
    fig, axes = plt.subplots(5, 1, figsize=(13.2, 10.8), sharex=True, constrained_layout=True)
    for column, (axis, output) in enumerate(zip(axes, OUTPUTS)):
        axis.plot(x, target[:, column], color="#151515", linewidth=1.15, label="Measured", zorder=3)
        axis.plot(x, pinn[:, column], color=COLORS["pinn"], linewidth=0.95, label="PINN-KAN", alpha=0.95)
        axis.plot(
            x,
            transformer[:, column],
            color=COLORS["transformer"],
            linewidth=0.9,
            linestyle="--",
            label="Transformer",
            alpha=0.95,
        )
        axis.set_ylabel(output)
        axis.margins(x=0)
    axes[0].legend(ncol=3, frameon=False, loc="upper right")
    axes[0].set_title(f"{CONDITION_LABELS[condition]}: {mode_label}", fontsize=13)
    axes[-1].set_xlabel("Test sample")
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)


def one_step_series(root: Path, data_dir: Path, window: int):
    archives = {
        model: np.load(root / model / "test_predictions.npz", allow_pickle=True)
        for model in ("pinn", "transformer")
    }
    paths = sorted(data_dir.glob("data_test_*.csv"))
    if len(paths) != 3:
        raise ValueError(f"Expected exactly three test files, found {len(paths)}")
    lengths = [csv_rows(path) - window for path in paths]
    if sum(lengths) != len(archives["pinn"]["target"]):
        raise ValueError("Per-file sample lengths do not match the saved one-step archive")
    result = {}
    offset = 0
    for condition, length in zip(CONDITIONS, lengths):
        selection = slice(offset, offset + length)
        target = archives["pinn"]["target"][selection]
        if not np.allclose(target, archives["transformer"]["target"][selection]):
            raise ValueError(f"One-step targets disagree for {condition}")
        result[condition] = {
            "target": target,
            "pinn": archives["pinn"]["prediction"][selection],
            "transformer": archives["transformer"]["prediction"][selection],
        }
        offset += length
    return result


def recursive_endpoint_series(root: Path):
    archives = {
        model: np.load(root / model / "recursive_predictions_h80.npz", allow_pickle=True)
        for model in ("pinn", "transformer")
    }
    result = {}
    for condition in CONDITIONS:
        masks = {model: archives[model]["condition"] == condition for model in archives}
        origins = archives["pinn"]["origin"][masks["pinn"]]
        transformer_origins = archives["transformer"]["origin"][masks["transformer"]]
        if not np.array_equal(origins, transformer_origins):
            raise ValueError(f"Recursive origins disagree for {condition}")
        target = archives["pinn"]["target"][masks["pinn"], -1, :]
        transformer_target = archives["transformer"]["target"][masks["transformer"], -1, :]
        if not np.allclose(target, transformer_target):
            raise ValueError(f"Recursive targets disagree for {condition}")
        result[condition] = {
            "x": origins + 80,
            "target": target,
            "pinn": archives["pinn"]["prediction"][masks["pinn"], -1, :],
            "transformer": archives["transformer"]["prediction"][masks["transformer"], -1, :],
        }
    return result


def main() -> None:
    args = parse_args()
    root = args.root.resolve()
    figure_dir = root / "report" / "condition_fit_curves"
    figure_dir.mkdir(parents=True, exist_ok=True)
    configure_style()

    metric_rows = []
    one_step = one_step_series(root, args.data_dir.resolve(), args.window)
    for condition, series in one_step.items():
        x = np.arange(len(series["target"]))
        plot_fit(
            figure_dir / f"one_step_fit_{condition}.png",
            x,
            series["target"],
            series["pinn"],
            series["transformer"],
            condition,
            "one-step prediction",
        )
        for model in ("pinn", "transformer"):
            metric_rows.extend(metrics(series["target"], series[model], condition, model, "one_step"))

    recursive = recursive_endpoint_series(root)
    for condition, series in recursive.items():
        plot_fit(
            figure_dir / f"recursive_h80_endpoint_fit_{condition}.png",
            series["x"],
            series["target"],
            series["pinn"],
            series["transformer"],
            condition,
            "80-step recursive endpoint prediction",
        )
        for model in ("pinn", "transformer"):
            metric_rows.extend(
                metrics(series["target"], series[model], condition, model, "recursive_h80_endpoint")
            )

    pd.DataFrame(metric_rows).to_csv(figure_dir / "condition_fit_metrics.csv", index=False)
    (figure_dir / "README.md").write_text(
        """# 三种工况拟合曲线说明

- `one_step_fit_*.png`：完整测试集的一步预测。每个时刻都使用 CSV 中已有的真实历史窗口。
- `recursive_h80_endpoint_fit_*.png`：固定起点递归回测的第 80 步终点预测。横轴上的每一点对应一个新的滚动起点，起点使用真实历史初始化，随后在块内递归 80 步。
- 递归图不是把多个重叠预测块拼接成单起点自由运行曲线，也不会在测试过程中更新模型参数。
- `condition_fit_metrics.csv`：与六张图对应的逐工况、逐变量 RMSE、MAE 和 R2。
""",
        encoding="utf-8",
    )
    print(f"Wrote condition plots to {figure_dir}")


if __name__ == "__main__":
    main()
