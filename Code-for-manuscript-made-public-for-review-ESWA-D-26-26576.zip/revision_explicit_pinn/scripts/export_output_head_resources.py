"""Audit resource use for the five-run encoder-decoder output-head study."""
from __future__ import annotations

import csv
import time
from pathlib import Path

import numpy as np
import torch

from revision_explicit_pinn.models import UnifiedHybridPINN, UnifiedModelConfig


ROOT = Path(
    r"D:\PythonProjects\PINN_code+tex\ESWA返修\返修交付包_统一参数框架_20260831"
    r"\04_图表与CSV结果\complete_code_tests_20260830\phase9_mimo_miso"
)
INSTANCES = "ABCDE"
MODES = {
    "mimo": "joint_vector_head",
    "miso": "separate_scalar_heads",
}
WARMUP = 100
REPETITIONS = 500


def build_model(mode: str) -> UnifiedHybridPINN:
    return UnifiedHybridPINN(
        UnifiedModelConfig(
            d_model=64,
            nhead=4,
            encoder_layers=2,
            decoder_layers=2,
            feedforward_dim=128,
            max_window=30,
            closure="kan",
            head_mode=mode,
        )
    )


def latency_ms(model: UnifiedHybridPINN, device: torch.device) -> tuple[float, float]:
    sample = torch.zeros(1, 8, 7, device=device)
    model.eval()
    with torch.no_grad():
        for _ in range(WARMUP):
            model(sample)
        if device.type == "cuda":
            torch.cuda.synchronize(device)
        values = []
        for _ in range(REPETITIONS):
            started = time.perf_counter()
            model(sample)
            if device.type == "cuda":
                torch.cuda.synchronize(device)
            values.append((time.perf_counter() - started) * 1000.0)
    return float(np.mean(values)), float(np.std(values, ddof=1))


def write_rows(path: Path, rows: list[dict]) -> None:
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    raw = []
    for mode, label in MODES.items():
        for instance in INSTANCES:
            checkpoint_path = ROOT / f"instance{instance}" / mode / "best.pt"
            if not checkpoint_path.exists():
                raise FileNotFoundError(checkpoint_path)
            checkpoint = torch.load(str(checkpoint_path), map_location=device)
            model = build_model(mode).to(device)
            model.load_state_dict(checkpoint["model"])
            mean_ms, std_ms = latency_ms(model, device)
            raw.append(
                {
                    "model": label,
                    "instance": instance,
                    "parameters": sum(parameter.numel() for parameter in model.parameters()),
                    "checkpoint_bytes": checkpoint_path.stat().st_size,
                    "latency_mean_ms": mean_ms,
                    "latency_std_ms": std_ms,
                    "device": str(device),
                    "batch": 1,
                    "window": 8,
                    "warmup": WARMUP,
                    "repetitions": REPETITIONS,
                }
            )
    write_rows(ROOT / "output_head_resource_metrics_by_instance.csv", raw)

    summary = []
    for label in MODES.values():
        rows = [row for row in raw if row["model"] == label]
        summary.append(
            {
                "model": label,
                "parameters": rows[0]["parameters"],
                "checkpoint_bytes": float(np.mean([row["checkpoint_bytes"] for row in rows])),
                "latency_mean_ms": float(np.mean([row["latency_mean_ms"] for row in rows])),
                "latency_std_ms": float(np.std([row["latency_mean_ms"] for row in rows], ddof=1)),
                "device": str(device),
                "batch": 1,
                "window": 8,
                "independent_runs": len(rows),
                "warmup": WARMUP,
                "repetitions_per_run": REPETITIONS,
            }
        )
    write_rows(ROOT / "output_head_resource_metrics_five_instances.csv", summary)


if __name__ == "__main__":
    main()
