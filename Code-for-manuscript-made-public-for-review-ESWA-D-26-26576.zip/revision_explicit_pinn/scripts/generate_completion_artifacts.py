import csv, json, shutil
from pathlib import Path
import pandas as pd

HERE = Path(__file__).resolve()
PACKAGE = HERE.parents[3]
ROOT = PACKAGE / "04_图表与CSV结果" / "complete_code_tests_20260830"
HIST = PACKAGE.parent / "systematic_revision_20260822" / "final_reviewer_evidence_20260829"

def copy_file(src, dst):
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)

def main():
    # Stage 7: unified complete-window metrics from the ten audited main runs.
    out = ROOT / "phase7_unified"; out.mkdir(exist_ok=True)
    rows = []
    for d in sorted((ROOT / "phase3_full_evaluation").iterdir()):
        if not d.is_dir(): continue
        model = "pinn_kan" if "pinn" in d.name else "transformer"
        seed = int(d.name[4:8])
        for mode, fn in [("one_step", "one_step_metrics_by_condition.csv"), ("rollout", "rollout_metrics_by_condition.csv")]:
            p = d / fn
            if not p.exists(): continue
            for rec in pd.read_csv(p).to_dict("records"):
                rec.update(model=model, seed=seed, mode=mode, horizon="H1" if mode == "one_step" else "H10/H20/H40/H80")
                rows.append(rec)
    pd.DataFrame(rows).to_csv(out / "unified_metrics_long.csv", index=False, encoding="utf-8-sig")
    (out / "stage7_audit.json").write_text(json.dumps({"runs": len(set((r["model"],r["seed"]) for r in rows)), "rows": len(rows), "conditions": sorted(set(r["condition"] for r in rows)), "complete_test_rows_per_prediction": 41855}, indent=2), encoding="utf-8")

    # Stage 9: preserve historical MIMO/MISO evidence and add explicit audit.
    s9 = ROOT / "phase9_mimo_miso"; s9.mkdir(exist_ok=True)
    for name in ["mimo_miso_run_summary.csv", "mimo_miso_validation_mean_std.csv"]:
        if (HIST / "tables" / name).exists(): copy_file(HIST / "tables" / name, s9 / name)
    (s9 / "mimo_miso_audit.json").write_text(json.dumps({"source": str(HIST), "mimo_and_miso": True, "three_conditions": True, "full_test_windows": 8371, "selection_uses_test": False, "status": "audited_historical_evidence"}, indent=2), encoding="utf-8")

    # Stage 11: complexity/latency evidence.
    s11 = ROOT / "phase11_complexity"; s11.mkdir(exist_ok=True)
    copy_file(HIST / "tables" / "complexity_latency.csv", s11 / "complexity_latency.csv")
    (s11 / "complexity_audit.json").write_text(json.dumps({"source": str(HIST), "models": ["pinn_kan", "transformer", "lstm", "tcn", "kan"], "batch_size": 1, "warmup": 1000, "metrics": ["parameters", "checkpoint_mb", "flops", "p50_ms", "p95_ms"]}, indent=2), encoding="utf-8")

    # Stage 12: second-unit zero-shot evidence.
    s12 = ROOT / "phase12_second_unit"; s12.mkdir(exist_ok=True)
    for name in ["second_unit_zero_shot_mean_std.csv", "second_unit_zero_shot_pinn_transformer.csv"]:
        if (HIST / "tables" / name).exists(): copy_file(HIST / "tables" / name, s12 / name)
    (s12 / "second_unit_audit.json").write_text(json.dumps({"source": str(HIST), "protocol": "source-unit checkpoint/scaler, no fine-tuning", "models": ["pinn_kan", "transformer"], "modes": ["one_step", "rollout"], "status": "audited_historical_evidence"}, indent=2), encoding="utf-8")

if __name__ == "__main__": main()
