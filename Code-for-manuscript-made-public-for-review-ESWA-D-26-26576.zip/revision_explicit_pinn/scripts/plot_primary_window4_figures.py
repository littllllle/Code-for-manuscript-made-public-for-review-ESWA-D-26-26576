from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

PACKAGE = Path(__file__).resolve().parents[3]
ROOT = PACKAGE / "04_图表与CSV结果" / "primary_window4_20260907"
FIG = PACKAGE / "01_手稿" / "figures_revision"
MODELS = ["lstm", "tcn", "kan", "transformer", "tk_pinn"]
LABELS = {"lstm": "LSTM", "tcn": "TCN", "kan": "KAN", "transformer": "Transformer", "tk_pinn": "TK-PINN"}
COLORS = {"lstm": "#3F8F72", "tcn": "#6F4AA8", "kan": "#D18F3B", "transformer": "#1F5A7A", "tk_pinn": "#C1121F"}
OUTPUTS = ["P_c", "n", "W_e", "T_e", "G_NOx"]
UNITS = {"P_c": r"kg$\cdot$cm$^{-2}$", "n": r"r$\cdot$min$^{-1}$", "W_e": "MW", "T_e": r"$^{\circ}$C", "G_NOx": r"mg$\cdot$Nm$^{-3}$"}
CONDITIONS = ["startup", "load_change", "shutdown"]
COND_LABELS = {"startup": "Startup", "load_change": "Load change", "shutdown": "Shutdown"}

plt.rcParams.update({
    "font.family": "serif", "font.serif": ["Times New Roman", "DejaVu Serif"],
    "font.size": 8.5, "mathtext.fontset": "stix", "axes.linewidth": 0.7,
    "xtick.direction": "in", "ytick.direction": "in", "savefig.dpi": 600,
})

def save(fig, path):
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path, dpi=600, bbox_inches="tight", facecolor="white")
    fig.savefig(path.with_suffix(".pdf"), bbox_inches="tight", facecolor="white")
    plt.close(fig)

def load(seed=2027):
    data = {}
    for model in MODELS:
        data[model] = pd.read_csv(ROOT / f"{model}_seed{seed}" / "test_predictions.csv")
    return data

def fit_figures(data):
    for condition in CONDITIONS:
        fig, axes = plt.subplots(5, 1, figsize=(6.45, 5.35), sharex=False)
        for oi, output in enumerate(OUTPUTS):
            ax = axes[oi]
            ref = data["tk_pinn"][(data["tk_pinn"].condition == condition) & (data["tk_pinn"].output_index == oi)].sort_values("sample_index")
            x = np.arange(len(ref), dtype=float)
            ax.plot(x, ref.target.to_numpy(), color="#222222", lw=0.65, ls="--", label="Measured" if oi == 0 else None, zorder=1)
            for model in MODELS:
                sub = data[model][(data[model].condition == condition) & (data[model].output_index == oi)].sort_values("sample_index")
                style = "--" if model == "tk_pinn" else "-"
                ax.plot(x, sub.prediction.to_numpy(), color=COLORS[model], lw=0.72, ls=style, alpha=0.92,
                        label=LABELS[model] if oi == 0 else None, zorder=3 if model == "tk_pinn" else 2)
            ax.set_ylabel(f"{output}\\n({UNITS[output]})", labelpad=2)
            ax.margins(x=0)
            ax.grid(alpha=0.16, lw=0.4)
            ax.tick_params(pad=1.5, length=2.5)
        axes[0].legend(ncol=3, frameon=False, loc="upper center", bbox_to_anchor=(0.5, 1.27), handlelength=1.8, columnspacing=1.0)
        axes[-1].set_xlabel("Time (s)")
        axes[-1].set_xlim(0, max(1, len(ref) - 1))
        fig.suptitle(f"Measured-feedback one-step prediction: {COND_LABELS[condition]}", y=0.995, fontsize=9.5)
        fig.subplots_adjust(left=0.10, right=0.995, top=0.89, bottom=0.08, hspace=0.28)
        save(fig, FIG / ({"startup": "Fig08_one_step_startup", "load_change": "Fig09_one_step_load_change", "shutdown": "Fig10_one_step_shutdown"}[condition] + ".png"))

def distribution_and_radar():
    long = pd.read_csv(ROOT / "aggregated" / "primary_window4_metrics_long.csv")
    summary = pd.read_csv(ROOT / "aggregated" / "primary_window4_metrics_mean_sd.csv")
    # The scaler is fitted on development rows only; these ranges are reused
    # to place errors from different physical outputs on a common axis.
    scaler = __import__("json").loads((ROOT / "tk_pinn_seed2027" / "run_config.json").read_text())
    ranges = np.asarray(scaler["scaler"]["maximum"], dtype=float)[2:] - np.asarray(scaler["scaler"]["minimum"], dtype=float)[2:]
    fig, axes = plt.subplots(1, 3, figsize=(6.45, 2.55), sharey=False)
    for ax, condition in zip(axes, CONDITIONS):
        values = []
        for model in MODELS:
            vals = []
            for seed in range(2026, 2031):
                frame = pd.read_csv(ROOT / f"{model}_seed{seed}" / "test_predictions.csv")
                frame = frame[frame.condition == condition]
                vals.append(np.abs(frame.prediction.to_numpy() - frame.target.to_numpy()) / ranges[frame.output_index.to_numpy(dtype=int)])
            values.append(np.concatenate(vals))
        bp = ax.boxplot(values, patch_artist=True, widths=0.58, showfliers=False)
        for patch, model in zip(bp["boxes"], MODELS):
            patch.set_facecolor(COLORS[model]); patch.set_alpha(0.72); patch.set_linewidth(0.5)
        ax.set_title(COND_LABELS[condition], fontsize=8.5)
        ax.set_xticks(range(1, 6), [LABELS[m] for m in MODELS], rotation=32, ha="right", fontsize=7)
        ax.set_yscale("log")
        ax.grid(axis="y", alpha=0.16, lw=0.4)
        ax.tick_params(pad=1.5, length=2.5)
    axes[0].set_ylabel("Absolute error / training range")
    fig.subplots_adjust(left=0.09, right=0.995, bottom=0.28, top=0.86, wspace=0.24)
    save(fig, FIG / "Fig11_one_step_error_boxplots.png")

    fig, axes = plt.subplots(1, 3, figsize=(6.45, 2.75), subplot_kw={"projection": "polar"})
    angles = np.linspace(0, 2*np.pi, len(OUTPUTS), endpoint=False)
    closed = np.r_[angles, angles[0]]
    for ax, condition in zip(axes, CONDITIONS):
        panel = summary[summary.condition == condition]
        best = panel.groupby("output").RMSE_mean.min()
        for model in MODELS:
            vals = panel[panel.model == model].set_index("output").RMSE_mean
            score = np.array([best[o] / vals[o] for o in OUTPUTS])
            ax.plot(closed, np.r_[score, score[0]], color=COLORS[model], lw=0.85, marker="o", ms=2.0, label=LABELS[model])
        ax.set_xticks(angles, [r"$P_c$", r"$n$", r"$W_e$", r"$T_e$", r"$G_{NOx}$"], fontsize=7)
        ax.set_ylim(0, 1.02); ax.set_yticks([0.25, 0.5, 0.75, 1.0]); ax.set_yticklabels([".25", ".50", ".75", "1"], fontsize=6)
        ax.set_title(COND_LABELS[condition], pad=9, fontsize=8.5)
        ax.grid(alpha=0.22, lw=0.4)
    axes[-1].legend(loc="center left", bbox_to_anchor=(1.10, 0.5), frameon=False, fontsize=7)
    fig.suptitle("Relative one-step RMSE (best model = 1)", y=0.98, fontsize=9.5)
    fig.subplots_adjust(left=0.01, right=0.82, top=0.82, bottom=0.08, wspace=0.24)
    save(fig, FIG / "Fig12_one_step_relative_rmse_radar.png")

def main():
    FIG.mkdir(parents=True, exist_ok=True)
    fit_figures(load())
    distribution_and_radar()
    print("wrote refreshed Fig08--Fig12 to", FIG)

if __name__ == "__main__":
    main()
