"""Render Fig. 17--19 from the unified five-instance ablation archive."""
from __future__ import annotations

import sys
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

HERE = Path(__file__).resolve()
PACKAGE = HERE.parents[3]
ROOT = PACKAGE / "04_图表与CSV结果" / "ablation_window4_20260908"
AGG = ROOT / "aggregated" / "ablation_metrics_long.csv"
FIG = PACKAGE / "01_手稿" / "figures_revision"
STYLE = PACKAGE.parent / "03_代码" / "plotting_参照"
sys.path.insert(0, str(STYLE))
from paper_plot_style import apply_paper_style, format_axis  # noqa: E402

CONDITIONS = ("startup", "load_change", "shutdown")
CONDITION_LABELS = {"startup": "Startup", "load_change": "Load change", "shutdown": "Shutdown"}
OUTPUTS = ("P_c", "n", "W_e", "T_e", "G_NOx")
VARIANT_LABELS = {
    "full_tk_pinn": "Full TK-PINN", "no_physics": "No physics", "no_kan": "No KAN",
    "equal_weighting": "Equal weighting", "fixed_weighting": "Fixed weighting",
    "separate_scalar": "Separate scalar heads",
}
COLORS = {"full_tk_pinn": "#C1121F", "no_physics": "#3F8F72", "no_kan": "#6F4AA8",
          "equal_weighting": "#D18F3B", "fixed_weighting": "#1F5A7A", "separate_scalar": "#777777"}


def normalized_rmse(frame):
    # Normalize each output by its training-range proxy before pooling outputs.
    ranges = frame.groupby("output").target_range.first().to_dict()
    frame = frame.copy()
    frame["nrmse"] = frame["RMSE"] / frame["output"].map(ranges)
    return frame.groupby(["variant", "condition"], as_index=False).nrmse.mean()


def save(fig, stem):
    FIG.mkdir(parents=True, exist_ok=True)
    fig.savefig(FIG / (stem + ".png"), dpi=600, bbox_inches="tight", facecolor="white")
    fig.savefig(FIG / (stem + ".pdf"), bbox_inches="tight", facecolor="white")
    plt.close(fig)


def bar_figure(variants, stem, ylabel):
    frame = pd.read_csv(AGG)
    # The range is reconstructed from the archived target values per output.
    # RMSE is already in physical units; obtain stable output scales from the
    # corresponding primary scaler serialized in the final archive.
    config = json.loads((PACKAGE / "04_图表与CSV结果" / "primary_window4_20260907" /
                         "tk_pinn_seed2026" / "run_config.json").read_text(encoding="utf-8"))
    scaler = config["scaler"]
    output_ranges = {o: float(mx - mn) for o, mn, mx in zip(OUTPUTS, scaler["minimum"][2:], scaler["maximum"][2:])}
    frame["nrmse"] = frame["RMSE"] / frame["output"].map(output_ranges)
    values = frame[frame.variant.isin(variants)].groupby(["variant", "condition"]).nrmse.mean().unstack("condition")
    fig, ax = plt.subplots(figsize=(3.55, 2.75))
    x = np.arange(len(CONDITIONS))
    width = 0.8 / len(variants)
    for i, variant in enumerate(variants):
        vals = [values.loc[variant, c] for c in CONDITIONS]
        ax.bar(x + (i - (len(variants)-1)/2) * width, vals, width=width * 0.92,
               color=COLORS[variant], edgecolor="#333333", linewidth=0.45,
               label=VARIANT_LABELS[variant])
    ax.set_xticks(x, [CONDITION_LABELS[c] for c in CONDITIONS])
    ax.set_ylabel(ylabel)
    ax.legend(fontsize=6.2, frameon=False, ncol=2, loc="upper left")
    format_axis(ax)
    ax.grid(axis="y", alpha=0.22)
    fig.subplots_adjust(left=0.18, right=0.98, bottom=0.2, top=0.96)
    save(fig, stem)


def main():
    apply_paper_style()
    if not AGG.exists():
        raise FileNotFoundError("Run aggregate_final_ablation_window4.py first")
    bar_figure(("full_tk_pinn", "no_physics", "no_kan"), "Fig17_physics_kan_ablation",
               "Mean normalized RMSE")
    bar_figure(("full_tk_pinn", "equal_weighting", "fixed_weighting"), "Fig18_kendall_weighting",
               "Mean normalized RMSE")
    bar_figure(("full_tk_pinn", "separate_scalar"), "Fig19_mimo_miso_tradeoff",
               "Mean normalized RMSE")
    print("rendered Fig. 17--19 from the unified ablation CSV", flush=True)


if __name__ == "__main__":
    main()
