import csv
from pathlib import Path


def main():
    parser_root = Path("revision_explicit_pinn/run_outputs/completed_experiments_20260812")
    out = parser_root / "completed_result_index.csv"
    rows = []
    for path in parser_root.rglob("*.csv"):
        if path.name == out.name:
            continue
        rows.append({"relative_file": str(path.relative_to(parser_root)), "bytes": path.stat().st_size})
    with out.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=["relative_file", "bytes"])
        writer.writeheader()
        writer.writerows(sorted(rows, key=lambda row: row["relative_file"]))
    print("indexed {} result files".format(len(rows)))


if __name__ == "__main__":
    main()
