from dataclasses import asdict, dataclass
from pathlib import Path
import copy
import json
import random
import time

import torch
import numpy as np
from torch.utils.data import DataLoader

from revision_explicit_pinn.losses import KendallTaskWeighting, PhysicsLoss, StaticTaskWeighting


def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


@dataclass(frozen=True)
class TrainConfig:
    epochs: int = 100
    batch_size: int = 16
    learning_rate: float = 1e-4
    weight_decay: float = 0.0
    patience: int = 15
    gradient_clip: float = 1.0
    weighting: str = "kendall"
    static_mass_weight: float = 1.0
    static_energy_weight: float = 1.0
    kan_regularization: float = 1e-5
    seed: int = 2026
    num_workers: int = 0
    use_physics: bool = True
    max_train_steps_per_epoch: int = 0
    max_validation_steps: int = 0
    kendall_scale_batches: int = 8


class Trainer:
    def __init__(self, model, bundle, output_dir, config=None, physics_config=None, device=None):
        self.model = model
        self.bundle = bundle
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.config = config or TrainConfig()
        self.device = torch.device(device or ("cuda" if torch.cuda.is_available() else "cpu"))
        self.model.to(self.device)
        self.physics = PhysicsLoss(
            bundle.scaler.minimum, bundle.scaler.scale, physics_config
        ).to(self.device)
        if self.config.weighting == "kendall":
            self.weighting = KendallTaskWeighting().to(self.device)
        elif self.config.weighting == "equal":
            self.weighting = StaticTaskWeighting().to(self.device)
        elif self.config.weighting == "static":
            self.weighting = StaticTaskWeighting(
                mass_weight=self.config.static_mass_weight,
                energy_weight=self.config.static_energy_weight,
            ).to(self.device)
        else:
            raise ValueError("Unknown weighting mode {}".format(self.config.weighting))
        self.loss_scales = self._estimate_kendall_scales()
        parameters = list(self.model.parameters()) + list(self.weighting.parameters())
        self.optimizer = torch.optim.Adam(
            parameters, lr=self.config.learning_rate, weight_decay=self.config.weight_decay
        )
        self.history = []

    def _estimate_kendall_scales(self):
        """Freeze task scales from initial training batches before optimization.

        Kendall weighting balances task difficulty after scale normalization; it
        must not be asked to compensate for raw-unit differences between data,
        mass, and energy losses.  The scale estimate never reads validation or
        test samples and is kept fixed for the complete run.
        """
        if self.config.weighting != "kendall" or not self.config.use_physics:
            return {"data": 1.0, "mass": 1.0, "energy": 1.0}
        model_mode = self.model.training
        self.model.eval()
        totals = {"data": 0.0, "mass": 0.0, "energy": 0.0}
        count = 0
        with torch.no_grad():
            for step, (features, target, _) in enumerate(self._loader(self.bundle.train, True), start=1):
                features, target = features.to(self.device), target.to(self.device)
                output = self.model(features)
                physics = self.physics(
                    features, output["prediction"], output["flows"],
                    output["previous_flows"], output.get("latent_delta"),
                )
                values = {
                    "data": torch.mean((output["prediction"] - target) ** 2),
                    "mass": physics["mass_loss"], "energy": physics["energy_loss"],
                }
                batch_size = len(features)
                for name, value in values.items():
                    totals[name] += float(value) * batch_size
                count += batch_size
                if step >= self.config.kendall_scale_batches:
                    break
        self.model.train(model_mode)
        if count == 0:
            raise RuntimeError("Cannot estimate Kendall loss scales from empty training data")
        scales = {name: max(value / count, 1.0e-12) for name, value in totals.items()}
        print("[train] frozen Kendall loss scales {}".format(scales), flush=True)
        return scales

    def _loader(self, dataset, training):
        generator = torch.Generator()
        generator.manual_seed(self.config.seed)
        return DataLoader(
            dataset,
            batch_size=self.config.batch_size,
            shuffle=training,
            drop_last=training,
            num_workers=self.config.num_workers,
            generator=generator,
        )

    def _epoch(self, dataset, training):
        self.model.train(training)
        self.weighting.train(training)
        totals = {key: 0.0 for key in ("total", "data", "mass", "energy", "kan", "scaled_data", "scaled_mass", "scaled_energy")}
        weight_totals = {key: 0.0 for key in ("data", "mass", "energy")}
        count = 0
        context = torch.enable_grad() if training else torch.no_grad()
        with context:
            for step, (features, target, _) in enumerate(self._loader(dataset, training), start=1):
                features = features.to(self.device)
                target = target.to(self.device)
                output = self.model(features)
                data_loss = torch.mean((output["prediction"] - target) ** 2)
                if self.config.use_physics:
                    physics = self.physics(
                        features,
                        output["prediction"],
                        output["flows"],
                        output["previous_flows"],
                        output.get("latent_delta"),
                    )
                    mass_loss = physics["mass_loss"]
                    energy_loss = physics["energy_loss"]
                    scaled_data = data_loss / self.loss_scales["data"]
                    scaled_mass = mass_loss / self.loss_scales["mass"]
                    scaled_energy = energy_loss / self.loss_scales["energy"]
                    total, weights = self.weighting(scaled_data, scaled_mass, scaled_energy)
                else:
                    mass_loss = torch.zeros_like(data_loss)
                    energy_loss = torch.zeros_like(data_loss)
                    scaled_data, scaled_mass, scaled_energy = data_loss, mass_loss, energy_loss
                    total = data_loss
                    weights = {"data": 1.0, "mass": 0.0, "energy": 0.0}
                kan_loss = self.model.flow_closure.regularization_loss()
                objective = total + self.config.kan_regularization * kan_loss
                if not torch.isfinite(objective):
                    raise FloatingPointError("Non-finite training objective")
                if training:
                    self.optimizer.zero_grad()
                    objective.backward()
                    torch.nn.utils.clip_grad_norm_(
                        list(self.model.parameters()) + list(self.weighting.parameters()),
                        self.config.gradient_clip,
                    )
                    self.optimizer.step()
                batch_count = features.shape[0]
                values = {
                    "total": objective,
                    "data": data_loss,
                    "mass": mass_loss,
                    "energy": energy_loss,
                    "kan": kan_loss,
                    "scaled_data": scaled_data,
                    "scaled_mass": scaled_mass,
                    "scaled_energy": scaled_energy,
                }
                for key, value in values.items():
                    totals[key] += float(value.detach()) * batch_count
                for key, value in weights.items():
                    weight_totals[key] += float(value) * batch_count
                count += batch_count
                step_limit = (
                    self.config.max_train_steps_per_epoch if training
                    else self.config.max_validation_steps
                )
                if step_limit > 0 and step >= step_limit:
                    break
        metrics = {key: value / count for key, value in totals.items()}
        metrics.update({"weight_{}".format(key): value / count for key, value in weight_totals.items()})
        return metrics

    def fit(self):
        set_seed(self.config.seed)
        best_loss = float("inf")
        best_state = None
        stale = 0
        started = time.time()
        for epoch in range(1, self.config.epochs + 1):
            print("[train] epoch {} start".format(epoch), flush=True)
            train_metrics = self._epoch(self.bundle.train, training=True)
            print("[train] epoch {} training batches complete".format(epoch), flush=True)
            validation_metrics = self._epoch(self.bundle.validation, training=False)
            print("[train] epoch {} validation complete".format(epoch), flush=True)
            row = {"epoch": epoch}
            row.update({"train_{}".format(k): v for k, v in train_metrics.items()})
            row.update({"validation_{}".format(k): v for k, v in validation_metrics.items()})
            if hasattr(self.weighting, "log_variances"):
                values = self.weighting.log_variances.detach().cpu().tolist()
                for name, value in zip(("data", "mass", "energy"), values):
                    row["log_variance_{}".format(name)] = float(value)
                    row["effective_weight_{}".format(name)] = float(0.5 * np.exp(-value))
            self.history.append(row)
            if validation_metrics["data"] < best_loss:
                best_loss = validation_metrics["data"]
                stale = 0
                best_state = {
                    "model": copy.deepcopy(self.model.state_dict()),
                    "weighting": copy.deepcopy(self.weighting.state_dict()),
                    "optimizer": copy.deepcopy(self.optimizer.state_dict()),
                    "epoch": epoch,
                    "validation_data_loss": best_loss,
                }
                torch.save(best_state, str(self.output_dir / "best.pt"))
                print("[train] checkpoint saved", flush=True)
            else:
                stale += 1
            if stale >= self.config.patience:
                break
        if best_state is None:
            raise RuntimeError("Training produced no valid checkpoint")
        self.model.load_state_dict(best_state["model"])
        self.weighting.load_state_dict(best_state["weighting"])
        with (self.output_dir / "history.json").open("w", encoding="utf-8") as handle:
            json.dump(self.history, handle, indent=2)
        with (self.output_dir / "run_config.json").open("w", encoding="utf-8") as handle:
            json.dump(
                {
                    "train": asdict(self.config),
                    "model": asdict(self.model.config),
                    "data": {"window": self.bundle.train.window},
                    "scaler": self.bundle.scaler.state_dict(),
                    "physics_runtime": asdict(self.physics.config),
                    "kendall_loss_scales": self.loss_scales,
                    "device": str(self.device),
                    "elapsed_seconds": time.time() - started,
                },
                handle,
                indent=2,
            )
        return best_state
