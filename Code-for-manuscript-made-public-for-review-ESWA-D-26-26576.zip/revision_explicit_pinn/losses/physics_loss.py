"""Observation mapping and non-dimensionalized explicit combustor residual loss."""

from dataclasses import dataclass

import torch

from revision_explicit_pinn.physics import CombustorParameters, combustor_rhs, trapezoidal_residual


@dataclass(frozen=True)
class PhysicsRuntimeConfig:
    gas_constant: float = 287.0
    effective_volume: float = 20.0
    # Training-identifiable ratio Q_eff/C_pg = 6.5661e4 K. Q_eff is anchored
    # at 49.5 MJ/kg and C_pg is the corresponding effective heat capacity.
    specific_heat: float = 753.869
    lower_heating_value: float = 4.95e7
    combustion_efficiency: float = 1.0
    pressure_retention: float = 0.98
    turbine_efficiency: float = 0.90
    gamma: float = 1.33
    exhaust_back_pressure_pa: float = 101350.0
    ambient_pressure_pa: float = 101350.0
    compressor_inlet_temperature_k: float = 288.0
    dt: float = 1.0

    def combustor_parameters(self):
        return CombustorParameters(
            gas_constant=self.gas_constant,
            effective_volume=self.effective_volume,
            specific_heat=self.specific_heat,
            lower_heating_value=self.lower_heating_value,
            combustion_efficiency=self.combustion_efficiency,
            energy_coefficient=1.0,
        )


class PhysicsLoss(torch.nn.Module):
    """Compute Eqs. (2)+(3) from y(k-1), predicted y(k), and bounded KAN flows.

    Defaults are documented pilot assumptions, not claimed device-calibrated values.
    Final experiments must provide a cited runtime configuration and sensitivity run.
    """

    def __init__(self, scaler_minimum, scaler_scale, config=None):
        super().__init__()
        self.config = config or PhysicsRuntimeConfig()
        self.register_buffer("minimum", torch.as_tensor(scaler_minimum, dtype=torch.float32))
        self.register_buffer("scale", torch.as_tensor(scaler_scale, dtype=torch.float32))

    def inverse_outputs(self, normalized):
        return normalized * self.scale[2:] + self.minimum[2:]

    def inverse_fuel(self, normalized):
        return normalized * self.scale[0] + self.minimum[0]

    def observation_to_combustor_state(self, physical_outputs):
        config = self.config
        # The source figures identify P_c as kgf/cm2 gauge and T_e as degree C.
        # Eqs. (2)+(3) require absolute Pa and K.
        compressor_pressure_pa = (
            physical_outputs[..., 0] * 98066.5 + config.ambient_pressure_pa
        )
        compressor_pressure_pa = torch.clamp(compressor_pressure_pa, min=1000.0)
        exhaust_temperature = torch.clamp(physical_outputs[..., 3] + 273.15, min=250.0)
        combustor_pressure = config.pressure_retention * compressor_pressure_pa
        pressure_ratio = torch.clamp(
            combustor_pressure / config.exhaust_back_pressure_pa, min=1.0001
        )
        expansion = 1.0 - config.turbine_efficiency * (
            1.0 - pressure_ratio ** (-(config.gamma - 1.0) / config.gamma)
        )
        combustor_temperature = exhaust_temperature / torch.clamp(expansion, min=0.1)
        return torch.stack([combustor_pressure, combustor_temperature], dim=-1)

    def forward(self, features, normalized_prediction, closure_flows, previous_closure_flows=None, latent_delta=None):
        previous_outputs = self.inverse_outputs(features[:, -1, 2:])
        previous_state = self.observation_to_combustor_state(previous_outputs)
        if latent_delta is None:
            current_outputs = self.inverse_outputs(normalized_prediction)
            current_state = self.observation_to_combustor_state(current_outputs)
        else:
            latent_state = previous_state + latent_delta
            # The latent update is bounded in magnitude by the model, but a
            # bounded decrement can still cross the thermodynamic domain near
            # startup. Enforce the same positive state domain used by the
            # observation mapping before evaluating the governing equations.
            current_state = torch.stack(
                [
                    torch.clamp(latent_state[:, 0], min=1000.0),
                    torch.clamp(latent_state[:, 1], min=250.0),
                ],
                dim=-1,
            )

        fuel_previous = self.inverse_fuel(features[:, -2, 0] if features.shape[1] > 1 else features[:, -1, 0])
        fuel_current = self.inverse_fuel(features[:, -1, 0])
        air_current, accumulation_current = closure_flows.unbind(dim=-1)
        if previous_closure_flows is None:
            previous_closure_flows = closure_flows
        air_previous, accumulation_previous = previous_closure_flows.unbind(dim=-1)
        gas_current = air_current + fuel_current - accumulation_current
        gas_previous = air_previous + fuel_previous - accumulation_previous

        cp = self.config.specific_heat
        h_air = torch.full_like(fuel_current, cp * self.config.compressor_inlet_temperature_k)
        h_fuel = torch.zeros_like(fuel_current)
        previous_enthalpies = torch.stack(
            [h_air, h_fuel, cp * previous_state[:, 1]], dim=-1
        )
        current_enthalpies = torch.stack(
            [h_air, h_fuel, cp * current_state[:, 1]], dim=-1
        )
        previous_flows = torch.stack([air_previous, fuel_previous, gas_previous], dim=-1)
        current_flows = torch.stack([air_current, fuel_current, gas_current], dim=-1)
        params = self.config.combustor_parameters()
        rhs_previous = combustor_rhs(previous_state, previous_flows, previous_enthalpies, params)
        rhs_current = combustor_rhs(current_state, current_flows, current_enthalpies, params)
        residual = trapezoidal_residual(
            previous_state, current_state, rhs_previous, rhs_current, self.config.dt
        )
        state_scales = torch.stack(
            [torch.clamp(previous_state[:, 0].abs(), min=1.0), torch.clamp(previous_state[:, 1].abs(), min=1.0)],
            dim=-1,
        ) / self.config.dt
        normalized_residual = residual / state_scales
        return {
            "mass_loss": torch.mean(normalized_residual[:, 0] ** 2),
            "energy_loss": torch.mean(normalized_residual[:, 1] ** 2),
            "residual": normalized_residual,
            "previous_state": previous_state,
            "current_state": current_state,
        }
